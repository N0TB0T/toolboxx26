var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/anonymize.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithHoles.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithHoles.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}
module.exports = _arrayWithHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArrayLimit.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArrayLimit.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}
module.exports = _iterableToArrayLimit, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableRest.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableRest.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
module.exports = _nonIterableRest, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/slicedToArray.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/slicedToArray.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithHoles = __webpack_require__(/*! ./arrayWithHoles.js */ "./node_modules/@babel/runtime/helpers/arrayWithHoles.js");
var iterableToArrayLimit = __webpack_require__(/*! ./iterableToArrayLimit.js */ "./node_modules/@babel/runtime/helpers/iterableToArrayLimit.js");
var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");
var nonIterableRest = __webpack_require__(/*! ./nonIterableRest.js */ "./node_modules/@babel/runtime/helpers/nonIterableRest.js");
function _slicedToArray(r, e) {
  return arrayWithHoles(r) || iterableToArrayLimit(r, e) || unsupportedIterableToArray(r, e) || nonIterableRest();
}
module.exports = _slicedToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? arrayLikeToArray(r, a) : void 0;
  }
}
module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./src/anonymize.js":
/*!**************************!*\
  !*** ./src/anonymize.js ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _anonymize_panel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./anonymize/panel */ "./src/anonymize/panel.js");
/* harmony import */ var _anonymize_scan__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./anonymize/scan */ "./src/anonymize/scan.js");
/* harmony import */ var _anonymize_apply__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./anonymize/apply */ "./src/anonymize/apply.js");


/**
 * Anonymize — command entry.
 * Flow: config panel → scan scope → (if ambiguous units) review panel → apply.
 * In-place; revert with Sketch undo (cmd+z).
 */
var sketch = __webpack_require__(/*! sketch */ "sketch");
var _require = __webpack_require__(/*! sketch/dom */ "sketch/dom"),
  Document = _require.Document;



/* harmony default export */ __webpack_exports__["default"] = (function () {
  var document = Document.getSelectedDocument();
  if (!document) {
    sketch.UI.message('Kein Dokument geöffnet.');
    return;
  }
  Object(_anonymize_panel__WEBPACK_IMPORTED_MODULE_0__["showAnonymizePanel"])(function (opts) {
    if (opts.scope === 'selection') {
      var sel = document.selectedLayers && document.selectedLayers.layers || [];
      if (!sel.length) {
        sketch.UI.message('Anonymize: nichts ausgewählt.');
        return;
      }
    }
    var result = Object(_anonymize_scan__WEBPACK_IMPORTED_MODULE_1__["scan"])(document, opts.scope);
    if (!result.textLayers.length && !result.imageLayers.length) {
      sketch.UI.message('Anonymize: keine Text-/Bild-Layer im Bereich.');
      return;
    }
    var run = function run(preserve) {
      var r = Object(_anonymize_apply__WEBPACK_IMPORTED_MODULE_2__["apply"])(result, {
        level: opts.level,
        style: opts.style,
        source: opts.source,
        preserve: preserve
      });
      sketch.UI.message("Anonymize: ".concat(r.textCount, " Text, ").concat(r.imageCount, " Bild").concat(r.imageCount === 1 ? '' : 'er', " bearbeitet (cmd+z f\xFCr undo)."));
    };
    var needsReview = opts.level !== 'wipe' && opts.style !== 'blackout' && result.ambiguous.length > 0;
    if (needsReview) Object(_anonymize_panel__WEBPACK_IMPORTED_MODULE_0__["showReviewPanel"])(result.ambiguous, document, function (preserve) {
      return run(preserve);
    });else run(new Set());
  });
});

/***/ }),

/***/ "./src/anonymize/apply.js":
/*!********************************!*\
  !*** ./src/anonymize/apply.js ***!
  \********************************/
/*! exports provided: apply */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "apply", function() { return apply; });
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core */ "./src/anonymize/core.js");


/**
 * Sketch adapter: mutate layers in place per the chosen level.
 * Levels: 'labels' (text only) | 'labelsData' (text + images) | 'wipe' (clear all).
 * In-place; relies on Sketch undo (cmd+z) to revert.
 */

var PLACEHOLDER_GRAY = '#CCCCCCFF';
function grayOut(layer) {
  try {
    layer.style.fills = [{
      color: PLACEHOLDER_GRAY,
      fillType: 'Color',
      enabled: true
    }];
  } catch (e) {}
}

/**
 * @param scanResult from scan()
 * @param opts { level, style, source, preserve: Set<string> }  preserve = ambiguous tokens to keep as units
 * @returns { textCount, imageCount }
 */
function apply(scanResult, opts) {
  var preserve = opts.preserve;
  var decide = preserve ? function (tok) {
    return preserve.has(tok);
  } : function () {
    return false;
  };
  var anon = function anon(s) {
    return Object(_core__WEBPACK_IMPORTED_MODULE_0__["anonymizeString"])(s, {
      style: opts.style,
      source: opts.source,
      decideAmbiguous: decide
    });
  };
  var textCount = 0;
  var imageCount = 0;

  // read current value / write new value uniformly for Text layers and overrides
  var get = function get(item) {
    return String((item.isOverride ? item.ov.value : item.layer.text) || '');
  };
  var put = function put(item, v) {
    if (item.isOverride) item.ov.value = v;else item.layer.text = v;
  };
  var targets = scanResult.textLayers.map(function (layer) {
    return {
      layer: layer,
      isOverride: false
    };
  }).concat((scanResult.textOverrides || []).map(function (o) {
    return {
      ov: o.ov,
      isOverride: true
    };
  }));
  targets.forEach(function (item) {
    try {
      var orig = get(item);
      if (opts.level === 'wipe') {
        if (orig !== '') {
          put(item, ' ');
          textCount++;
        }
      } else {
        if (!orig.trim()) return;
        put(item, anon(orig));
        textCount++;
      }
    } catch (e) {}
  });
  if (opts.level === 'labelsData' || opts.level === 'wipe') {
    scanResult.imageLayers.forEach(function (l) {
      grayOut(l);
      imageCount++;
    });
  }
  return {
    textCount: textCount,
    imageCount: imageCount
  };
}

/***/ }),

/***/ "./src/anonymize/core.js":
/*!*******************************!*\
  !*** ./src/anonymize/core.js ***!
  \*******************************/
/*! exports provided: KNOWN_UNITS, normalizeUnitToken, tokenize, classifyAlpha, classifyTokens, casePattern, applyCase, randomizeNumber, anonymizeWord, anonymizeString, collectAmbiguous */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KNOWN_UNITS", function() { return KNOWN_UNITS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "normalizeUnitToken", function() { return normalizeUnitToken; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tokenize", function() { return tokenize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "classifyAlpha", function() { return classifyAlpha; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "classifyTokens", function() { return classifyTokens; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "casePattern", function() { return casePattern; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyCase", function() { return applyCase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "randomizeNumber", function() { return randomizeNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "anonymizeWord", function() { return anonymizeWord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "anonymizeString", function() { return anonymizeString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collectAmbiguous", function() { return collectAmbiguous; });
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/slicedToArray.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Pure anonymization logic — NO Sketch dependencies, node-testable.
 *
 * Anonymizes text while PRESERVING format:
 *  - case pattern (UPPER / lower / Title / per-char)
 *  - number shape (digit count, separators, sign, leading zeros)
 *  - units are detected and KEPT (configurable per ambiguous token)
 *
 * Styles: 'xx00' | 'lorem' | 'blackout' | 'fromString'
 */

// --- unit knowledge ----------------------------------------------------------

// normalized (lowercase, superscript→digit) known unit tokens.

function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
var KNOWN_UNITS = new Set([
// length
'm', 'cm', 'mm', 'km', 'um', 'nm', 'ft', 'in', 'yd', 'mi',
// volume (plain "m2"/"m3"/"cm3" forms are intentionally NOT here — they are
// ambiguous with labels like "M2"/"A4" and handled by the ambiguity heuristic;
// superscript forms (m², cm³) are caught as units separately)
'l', 'ml', 'cl', 'dl', 'gal',
// mass
'g', 'kg', 'mg', 'ug', 't', 'lb', 'oz',
// time
's', 'ms', 'us', 'ns', 'min', 'h', 'hr', 'd',
// frequency
'hz', 'khz', 'mhz', 'ghz',
// data
'b', 'kb', 'mb', 'gb', 'tb', 'kib', 'mib', 'gib', 'bit', 'bps',
// speed
'mph', 'kn', 'kmh', 'mps',
// temperature
'k', '°c', '°f', '°',
// electrical
'a', 'ma', 'v', 'mv', 'kv', 'w', 'kw', 'mw', 'wh', 'kwh', 'mwh', 'ohm', 'va',
// angle
'deg', 'rad',
// typography / web
'px', 'pt', 'pc', 'em', 'rem', 'vw', 'vh', 'vmin', 'vmax', 'ch', 'dpi', 'ppi',
// misc
'%']);

// units that are also common words → only treat as unit when adjacent to a number
var UNIT_ALSO_WORD = new Set(['in', 'a', 't', 'd', 'b', 'h', 'm', 's', 'g', 'l', 'k', 'v', 'w']);
var SUPERSCRIPT = {
  '²': '2',
  '³': '3',
  '¹': '1',
  '⁰': '0',
  '⁴': '4',
  '⁵': '5'
};
var SUBSCRIPT = {
  '₀': '0',
  '₁': '1',
  '₂': '2',
  '₃': '3',
  '₄': '4'
};
function hasSuperSub(s) {
  var _iterator = _createForOfIteratorHelper(s),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var ch = _step.value;
      if (SUPERSCRIPT[ch] || SUBSCRIPT[ch]) return true;
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return false;
}
function normalizeUnitToken(token) {
  var out = '';
  var _iterator2 = _createForOfIteratorHelper(token),
    _step2;
  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var ch = _step2.value;
      out += SUPERSCRIPT[ch] || SUBSCRIPT[ch] || ch;
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
  return out.toLowerCase();
}

// --- tokenization ------------------------------------------------------------
// Splits into runs: number | word(letters, may include super/sub) | other(sep/punct).

var RE_NUMBER = /^[+-]?\d[\d.,]*\d|^[+-]?\d/;
var LETTER = /[A-Za-zÀ-ÖØ-öø-ÿ²³¹⁰-₄]/;
function tokenize(text) {
  var tokens = [];
  var i = 0;
  while (i < text.length) {
    var rest = text.slice(i);
    var numMatch = rest.match(RE_NUMBER);
    if (numMatch && /\d/.test(text[i])) {
      tokens.push({
        type: 'number',
        value: numMatch[0]
      });
      i += numMatch[0].length;
      continue;
    }
    if (LETTER.test(text[i])) {
      var j = i;
      while (j < text.length && (LETTER.test(text[j]) || j > i && /\d/.test(text[j]) ||
      // keep an internal slash that sits between letters (compound units: m³/s, l/s, km/h)
      j > i && text[j] === '/' && j + 1 < text.length && LETTER.test(text[j + 1]))) j++;
      tokens.push({
        type: 'alpha',
        value: text.slice(i, j)
      });
      i = j;
      continue;
    }
    // separator / punctuation run (single char keeps positions simple)
    tokens.push({
      type: 'sep',
      value: text[i]
    });
    i++;
  }
  return tokens;
}

// --- classification ----------------------------------------------------------

/** Is this alpha token a unit? Returns 'unit' | 'word' | 'ambiguous'. */
// a unit part: a known unit, or a known base with an area/volume exponent (m³→m3, s²→s2)
function isUnitPart(p) {
  return KNOWN_UNITS.has(p) || /^.+[23]$/.test(p) && KNOWN_UNITS.has(p.replace(/[23]$/, ''));
}
function classifyAlpha(token) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$prevIsNumber = _ref.prevIsNumber,
    prevIsNumber = _ref$prevIsNumber === void 0 ? false : _ref$prevIsNumber;
  var norm = normalizeUnitToken(token);
  var hasDigit = /\d/.test(token);
  // compound unit (has a slash): every part must be unit-like (so "and/or", "TCP/IP"
  // stay words, but "m³/s", "l/s", "km/h", "W/m²" are units).
  var known = KNOWN_UNITS.has(norm) || norm.includes('/') && norm.split('/').every(isUnitPart);
  if (known) {
    if (UNIT_ALSO_WORD.has(norm)) return prevIsNumber ? 'unit' : 'ambiguous';
    return 'unit';
  }
  if (hasSuperSub(token)) return 'unit'; // m², cm³ → unit/math
  // letter(s) + trailing digit, e.g. "M2", "A4", "H2" → could be unit (m²) or label
  if (/^[A-Za-z]{1,2}\d{1,2}$/.test(token)) return prevIsNumber ? 'unit' : 'ambiguous';
  // short alpha next to a number, not in list → possible unit
  if (token.length <= 3 && prevIsNumber) return 'ambiguous';
  return 'word';
}

/**
 * Classify all tokens of a string. Returns array of
 * { value, kind: 'word'|'number'|'unit'|'ambiguous'|'sep' }.
 * Number-adjacency is computed left-to-right (also across a single space).
 */
function classifyTokens(text) {
  var toks = tokenize(text);
  var prevSignificant = null; // last non-sep token
  var out = toks.map(function (t) {
    if (t.type === 'sep') return {
      value: t.value,
      kind: 'sep'
    };
    if (t.type === 'number') {
      prevSignificant = 'number';
      return {
        value: t.value,
        kind: 'number'
      };
    }
    var prevIsNumber = prevSignificant === 'number';
    var kind = classifyAlpha(t.value, {
      prevIsNumber: prevIsNumber
    });
    prevSignificant = 'alpha';
    return {
      value: t.value,
      kind: kind,
      reason: kind === 'ambiguous' ? unitReason(t.value, prevIsNumber) : undefined
    };
  });
  return out;
}
function unitReason(token, prevIsNumber) {
  if (/^[A-Za-z]{1,2}\d{1,2}$/.test(token)) return "\"".concat(token, "\" k\xF6nnte Einheit (z.B. m\xB2/m\xB3) oder Label sein");
  if (prevIsNumber) return "\"".concat(token, "\" steht hinter einer Zahl \u2014 evtl. Einheit");
  return "\"".concat(token, "\" mehrdeutig");
}

// --- case + format preservation ---------------------------------------------

function casePattern(word) {
  if (word.length > 1 && word === word.toUpperCase() && /[a-z]/i.test(word)) return 'upper';
  if (word === word.toLowerCase()) return 'lower';
  if (word[0] === word[0].toUpperCase() && word.slice(1) === word.slice(1).toLowerCase()) return 'title';
  return 'mixed';
}
function applyCase(replacement, pattern) {
  switch (pattern) {
    case 'upper':
      return replacement.toUpperCase();
    case 'title':
      return replacement.charAt(0).toUpperCase() + replacement.slice(1).toLowerCase();
    case 'lower':
      return replacement.toLowerCase();
    default:
      return replacement;
  }
}

/** Replace digits with random digits, preserving separators, sign and leading-zero shape. */
function randomizeNumber(value, rng) {
  var r = rng || Math.random;
  var totalDigits = value.replace(/[^\d]/g, '').length;
  var seenSignificant = false;
  var out = '';
  for (var i = 0; i < value.length; i++) {
    var ch = value[i];
    if (!/\d/.test(ch)) {
      out += ch; // separators, sign, decimal point preserved
      continue;
    }
    if (ch === '0' && !seenSignificant) {
      out += '0'; // preserve leading zeros (e.g. "007")
      continue;
    }
    if (!seenSignificant && totalDigits > 1) {
      out += String(1 + Math.floor(r() * 9)); // keep no-leading-zero shape
    } else {
      out += String(Math.floor(r() * 10));
    }
    seenSignificant = true;
  }
  return out;
}
var LOREM = 'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore magna aliqua enim ad minim veniam quis nostrud'.split(' ');
function loremWord(len) {
  // pick the lorem word whose length is closest to len
  var best = LOREM[0];
  var bestDiff = Infinity;
  var _iterator3 = _createForOfIteratorHelper(LOREM),
    _step3;
  try {
    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
      var w = _step3.value;
      var diff = Math.abs(w.length - len);
      if (diff < bestDiff) {
        bestDiff = diff;
        best = w;
      }
    }
  } catch (err) {
    _iterator3.e(err);
  } finally {
    _iterator3.f();
  }
  return best;
}
function sourceWords(source) {
  return (source || '').split(/\s+/).map(function (w) {
    return w.replace(/[^A-Za-zÀ-ÿ]/g, '');
  }).filter(Boolean);
}
function pickFromSource(words, len, rng) {
  if (!words.length) return loremWord(len);
  var exact = words.filter(function (w) {
    return w.length === len;
  });
  var pool = exact.length ? exact : words;
  var r = rng || Math.random;
  return pool[Math.floor(r() * pool.length)];
}
function anonymizeWord(word, style, ctx) {
  var pattern = casePattern(word);
  switch (style) {
    case 'xx00':
      // per-char: letter→x (case-preserving), other letters handled char-wise
      return word.replace(/[A-Za-zÀ-ÿ]/g, function (c) {
        return c === c.toUpperCase() ? 'X' : 'x';
      });
    case 'blackout':
      return '█'.repeat(word.length);
    case 'lorem':
      return applyCase(loremWord(word.length), pattern);
    case 'fromString':
      return applyCase(pickFromSource(ctx.sourceWords, word.length, ctx.rng), pattern);
    default:
      return word;
  }
}

// --- main --------------------------------------------------------------------

/**
 * Anonymize a string.
 * @param {string} text
 * @param {object} opts
 *   style: 'xx00'|'lorem'|'blackout'|'fromString'
 *   source: string (for fromString)
 *   keepUnits: boolean (default true) — preserve tokens classified as 'unit'
 *   decideAmbiguous: (tokenValue) => boolean  — true = treat as unit (preserve)
 *   rng: () => number (testing)
 */
function anonymizeString(text) {
  var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var style = opts.style || 'xx00';
  var keepUnits = opts.keepUnits !== false;
  var decide = opts.decideAmbiguous || function () {
    return false;
  };
  var ctx = {
    sourceWords: sourceWords(opts.source),
    rng: opts.rng
  };
  var classified = classifyTokens(text);
  return classified.map(function (t) {
    if (t.kind === 'sep') return t.value;
    if (t.kind === 'number') return style === 'blackout' ? '█'.repeat(t.value.replace(/[^\d]/g, '').length) : randomizeNumber(t.value, opts.rng);
    if (t.kind === 'unit' && keepUnits) return t.value;
    if (t.kind === 'ambiguous' && decide(t.value)) return t.value; // user said: it's a unit
    return anonymizeWord(t.value, style, ctx);
  }).join('');
}

/** Collect distinct ambiguous tokens across many strings, for the review panel. */
function collectAmbiguous(strings) {
  var map = new Map();
  strings.forEach(function (s) {
    classifyTokens(s).forEach(function (t) {
      if (t.kind === 'ambiguous' && !map.has(t.value)) map.set(t.value, t.reason || 'mehrdeutig');
    });
  });
  return Array.from(map, function (_ref2) {
    var _ref3 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_ref2, 2),
      value = _ref3[0],
      reason = _ref3[1];
    return {
      value: value,
      reason: reason
    };
  });
}


/***/ }),

/***/ "./src/anonymize/panel.js":
/*!********************************!*\
  !*** ./src/anonymize/panel.js ***!
  \********************************/
/*! exports provided: showAnonymizePanel, showReviewPanel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showAnonymizePanel", function() { return showAnonymizePanel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showReviewPanel", function() { return showReviewPanel; });
/* harmony import */ var _utils_mocha__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/mocha */ "./src/utils/mocha.js");
/* harmony import */ var _ui_controls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../ui/controls */ "./src/ui/controls.js");


/**
 * Anonymize UI: config panel (scope / level / style radios + From-String field)
 * and a review panel for ambiguous unit tokens.
 *
 * NOTE: built against proven toolboxx AppKit patterns; needs an in-Sketch smoke test.
 */


function keepAround(on) {
  COScript.currentCOScript().setShouldKeepAround_(on);
}
function basePanel(identifier, title, width, height) {
  var td = NSThread.mainThread().threadDictionary();
  if (td[identifier]) {
    try {
      td[identifier].close();
    } catch (e) {}
    td.removeObjectForKey(identifier);
  }
  var panel = NSPanel.alloc().init();
  panel.setStyleMask(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable);
  // size the CONTENT (not the window frame) so layout against `height` isn't
  // clipped by the title bar at top/bottom.
  panel.setContentSize(NSMakeSize(width, height));
  panel.setBackgroundColor(NSColor.windowBackgroundColor());
  panel.title = title;
  panel.center();
  panel.makeKeyAndOrderFront(null);
  panel.setLevel(NSFloatingWindowLevel);
  keepAround(true);
  td[identifier] = panel;
  return {
    panel: panel,
    td: td
  };
}
function wireClose(panel, td, identifier, onClose) {
  var delegateKey = identifier + '.delegate';
  var cleanup = function cleanup() {
    try {
      td.removeObjectForKey(identifier);
      td.removeObjectForKey(delegateKey);
    } catch (e) {}
    keepAround(false);
    if (onClose) onClose();
  };
  var delegate = Object(_utils_mocha__WEBPACK_IMPORTED_MODULE_0__["MochaJSDelegate"])({
    'windowWillClose:': function windowWillClose() {
      return cleanup();
    }
  });
  panel.setDelegate_(delegate);
  td[delegateKey] = delegate;
  return cleanup;
}
function button(content, x, y, w, title, fn) {
  var b = NSButton.alloc().initWithFrame(NSMakeRect(x, y, w, 28));
  b.setTitle(title);
  b.setBezelStyle(NSBezelStyleRounded);
  b.setCOSJSTargetFunction(fn);
  content.addSubview(b);
  return b;
}
var SCOPE = [{
  label: 'Auswahl',
  value: 'selection'
}, {
  label: 'Artboard',
  value: 'artboard'
}, {
  label: 'Dokument',
  value: 'document'
}];
var LEVEL = [{
  label: 'Nur Labels (Text)',
  value: 'labels'
}, {
  label: 'Labels + Daten (Bilder)',
  value: 'labelsData'
}, {
  label: 'Alles leeren',
  value: 'wipe'
}];
var STYLE = [{
  label: 'Xxx 00 (zeichen-erhaltend)',
  value: 'xx00'
}, {
  label: 'Lorem Ipsum',
  value: 'lorem'
}, {
  label: 'Blackout ████',
  value: 'blackout'
}, {
  label: 'Aus Text…',
  value: 'fromString'
}];

/** Config panel. onApply({ scope, level, style, source }). */
function showAnonymizePanel(onApply) {
  var W = 360;
  var H = 470;
  var id = 'net.notbot.toolboxx.anonymize.config';
  var _basePanel = basePanel(id, 'Anonymize', W, H),
    panel = _basePanel.panel,
    td = _basePanel.td;
  var content = panel.contentView();
  var cleanup = wireClose(panel, td, id);
  var x = 20;
  var groupW = W - 40;
  var fromTop = 16;
  var headerH = 18;
  var rowH = 22;
  var section = function section(titleText, options, gapAfter) {
    content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(x, H - fromTop - headerH, groupW, headerH), titleText, {
      size: 11,
      bold: true
    }));
    fromTop += headerH + 2;
    var grp = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeRadioGroup"])(content, options, {
      x: x + 4,
      top: H - fromTop - (rowH - 2),
      rowH: rowH,
      width: groupW - 4
    }, gapAfter);
    fromTop += rowH * options.length + 8;
    return grp;
  };
  var scopeGrp = section('Bereich', SCOPE);
  var levelGrp = section('Umfang', LEVEL);

  // style group with onChange to toggle the source field
  content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(x, H - fromTop - headerH, groupW, headerH), 'Text-Stil', {
    size: 11,
    bold: true
  }));
  fromTop += headerH + 2;
  var sourceField = null;
  var styleGrp = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeRadioGroup"])(content, STYLE, {
    x: x + 4,
    top: H - fromTop - (rowH - 2),
    rowH: rowH,
    width: groupW - 4
  }, function (val) {
    if (sourceField) sourceField.setEnabled(val === 'fromString');
  });
  fromTop += rowH * STYLE.length + 6;
  content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(x, H - fromTop - 14, groupW, 14), 'Quelltext (für „Aus Text…"):', {
    size: 10,
    color: NSColor.secondaryLabelColor()
  }));
  fromTop += 16;
  sourceField = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeField"])(NSMakeRect(x, H - fromTop - 24, groupW, 24), '');
  sourceField.setEnabled(false);
  content.addSubview(sourceField);
  fromTop += 30;
  button(content, x, 14, 150, 'Abbrechen', function () {
    panel.close();
    cleanup();
  });
  button(content, W - 20 - 150, 14, 150, 'Anonymisieren', function () {
    var opts = {
      scope: scopeGrp.get(),
      level: levelGrp.get(),
      style: styleGrp.get(),
      source: String(sourceField.stringValue())
    };
    panel.close();
    cleanup();
    onApply(opts);
  });
}

/**
 * Review panel for ambiguous tokens. ambiguous: [{value, reason, layers}].
 * Clicking a row's ↗ selects + centers its source layer(s) on the canvas; the
 * original selection is saved and restored when the panel closes.
 * onConfirm(preserveSet: Set<string>) — checked items are kept as units.
 */
function showReviewPanel(ambiguous, document, onConfirm) {
  var W = 460;
  var rowH = 26;
  var headH = 64;
  var footH = 54;
  var listH = Math.min(ambiguous.length * rowH + 8, 360);
  var H = headH + listH + footH;
  var id = 'net.notbot.toolboxx.anonymize.review';

  // save current selection so reveal-clicks can be undone on close
  var original = [];
  try {
    original = document.selectedLayers && document.selectedLayers.layers ? document.selectedLayers.layers.slice() : [];
  } catch (e) {}
  var select = function select(layers, center) {
    try {
      document.selectedLayers.clear();
    } catch (e) {}
    (layers || []).forEach(function (l) {
      try {
        l.selected = true;
      } catch (e) {}
    });
    if (center && layers && layers[0]) {
      try {
        document.centerOnLayer(layers[0]);
      } catch (e) {}
    }
  };
  var _basePanel2 = basePanel(id, 'Anonymize — Einheiten prüfen', W, H),
    panel = _basePanel2.panel,
    td = _basePanel2.td;
  var content = panel.contentView();
  var cleanup = wireClose(panel, td, id, function () {
    return select(original, false);
  }); // restore on any close

  content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(20, H - 40, W - 40, 32), 'Mehrdeutig — ankreuzen = als Einheit behalten. ↗ zeigt die Fundstelle im Canvas:', {
    size: 11
  }));
  var scroll = NSScrollView.alloc().initWithFrame(NSMakeRect(16, footH, W - 32, listH));
  scroll.setHasVerticalScroller(true);
  scroll.setDrawsBackground(false);
  var docW = W - 48;
  var docView = NSView.alloc().initWithFrame(NSMakeRect(0, 0, docW, Math.max(listH, ambiguous.length * rowH + 8)));
  scroll.setDocumentView(docView);
  content.addSubview(scroll);
  var checks = ambiguous.map(function (item, i) {
    var y = docView.frame().size.height - (i + 1) * rowH;
    var n = item.layers && item.layers.length || 0;
    var cb = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeCheckbox"])(NSMakeRect(8, y, docW - 70, rowH - 4), "".concat(item.value, "   \u2014   ").concat(item.reason || ''), false);
    docView.addSubview(cb);
    var reveal = NSButton.alloc().initWithFrame(NSMakeRect(docW - 58, y - 1, 52, rowH - 2));
    reveal.setTitle(n > 1 ? "\u2197 ".concat(n) : '↗');
    reveal.setBezelStyle(NSBezelStyleRounded);
    reveal.setEnabled(n > 0);
    reveal.setCOSJSTargetFunction(function () {
      return select(item.layers, true);
    });
    docView.addSubview(reveal);
    return {
      cb: cb,
      value: item.value
    };
  });
  button(content, 16, 14, 120, 'Abbrechen', function () {
    panel.close();
    cleanup();
  });
  button(content, W - 16 - 160, 14, 160, 'Anonymisieren', function () {
    var preserve = new Set();
    checks.forEach(function (c) {
      if (c.cb.state() === NSOnState) preserve.add(c.value);
    });
    panel.close();
    cleanup();
    onConfirm(preserve);
  });
}

/***/ }),

/***/ "./src/anonymize/scan.js":
/*!*******************************!*\
  !*** ./src/anonymize/scan.js ***!
  \*******************************/
/*! exports provided: collectRoots, scan */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collectRoots", function() { return collectRoots; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scan", function() { return scan; });
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core */ "./src/anonymize/core.js");


/**
 * Sketch adapter: collect the layers in scope and the ambiguous unit tokens
 * that need user review before anonymizing. No mutation here.
 */

function collectByType(root, acc) {
  if (!root) return acc;
  try {
    if (root.type === 'Text') acc.text.push(root);
    if (root.type === 'Image') acc.image.push(root);else {
      var fills = root.style && root.style.fills;
      if (fills && fills.some(function (f) {
        return f.enabled && f.fillType === 'Pattern';
      })) acc.image.push(root);
    }
    // Symbol instances hold their visible text in OVERRIDES, not child layers.
    // The .overrides array is flat and includes nested-symbol overrides too
    // (same source smartSelect/equalize use). property 'stringValue' = text.
    if (root.type === 'SymbolInstance' && Array.isArray(root.overrides)) {
      root.overrides.forEach(function (ov) {
        try {
          if (ov && ov.property === 'stringValue' && ov.editable !== false && typeof ov.value === 'string' && ov.value.length) {
            acc.overrides.push({
              ov: ov,
              owner: root
            }); // owner = the SymbolInstance (selectable on canvas)
          }
        } catch (e) {}
      });
    }
  } catch (e) {}
  var kids = root.layers;
  if (kids && kids.length) kids.forEach(function (k) {
    return collectByType(k, acc);
  });
  return acc;
}
function enclosingArtboard(layer) {
  var p = layer;
  var guard = 0;
  while (p && guard++ < 60) {
    if (p.type === 'Artboard') return p;
    p = p.parent;
  }
  return null;
}

/** Root layers to walk for the chosen scope: 'selection' | 'artboard' | 'document'. */
function collectRoots(document, scope) {
  var sel = document.selectedLayers && document.selectedLayers.layers || [];
  if (scope === 'document') return document.pages || [];
  if (scope === 'artboard') {
    var abs = [];
    sel.forEach(function (l) {
      var ab = enclosingArtboard(l);
      if (ab && !abs.includes(ab)) abs.push(ab);
    });
    if (abs.length) return abs;
    var page = document.selectedPage || document.pages && document.pages[0];
    return page ? (page.layers || []).filter(function (l) {
      return l.type === 'Artboard';
    }) : [];
  }
  return sel; // selection
}

/** Add a string's ambiguous tokens to the map, recording the source layer per token. */
function addAmbiguous(map, text, source) {
  Object(_core__WEBPACK_IMPORTED_MODULE_0__["classifyTokens"])(text).forEach(function (t) {
    if (t.kind !== 'ambiguous') return;
    var e = map.get(t.value);
    if (!e) {
      e = {
        value: t.value,
        reason: t.reason || 'mehrdeutig',
        layers: []
      };
      map.set(t.value, e);
    }
    if (source && !e.layers.some(function (l) {
      return l.id === source.id;
    })) e.layers.push(source);
  });
}
function scan(document, scope) {
  var roots = collectRoots(document, scope);
  var acc = {
    text: [],
    image: [],
    overrides: []
  };
  roots.forEach(function (r) {
    return collectByType(r, acc);
  });

  // ambiguous tokens with their source layers (Text layer, or the SymbolInstance
  // owning an override) so the review panel can reveal where each was found.
  var map = new Map();
  acc.text.forEach(function (t) {
    return addAmbiguous(map, String(t.text || ''), t);
  });
  acc.overrides.forEach(function (o) {
    return addAmbiguous(map, String(o.ov.value || ''), o.owner);
  });
  return {
    roots: roots,
    textLayers: acc.text,
    imageLayers: acc.image,
    textOverrides: acc.overrides,
    ambiguous: Array.from(map.values())
  };
}

/***/ }),

/***/ "./src/ui/controls.js":
/*!****************************!*\
  !*** ./src/ui/controls.js ***!
  \****************************/
/*! exports provided: makeLabel, makeField, makeSwatch, makeCheckbox, makeRadioGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeLabel", function() { return makeLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeField", function() { return makeField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeSwatch", function() { return makeSwatch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeCheckbox", function() { return makeCheckbox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeRadioGroup", function() { return makeRadioGroup; });


/**
 * Shared native AppKit control builders (used by contrast & anonymize panels).
 * Bottom-left origin; system font / labelColor → auto light/dark.
 */
function makeLabel(frame, text) {
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var f = NSTextField.alloc().initWithFrame(frame);
  f.setEditable(false);
  f.setBordered(false);
  f.setBezeled(false);
  f.setDrawsBackground(false);
  f.setSelectable(opts.selectable || false);
  var size = opts.size || 12;
  f.setFont(opts.bold ? NSFont.boldSystemFontOfSize(size) : NSFont.systemFontOfSize(size));
  if (opts.align === 'center') f.setAlignment(NSTextAlignmentCenter);
  if (opts.color) f.setTextColor(opts.color);
  f.setStringValue(text || '');
  return f;
}
function makeField(frame, text) {
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var f = NSTextField.alloc().initWithFrame(frame);
  f.setEditable(true);
  f.setBezeled(true);
  f.setBezelStyle(NSTextFieldRoundedBezel);
  f.setFont(NSFont.systemFontOfSize(11));
  if (opts.align === 'center') f.setAlignment(NSTextAlignmentCenter);
  f.setStringValue(text || '');
  return f;
}
function makeSwatch(frame) {
  var v = NSView.alloc().initWithFrame(frame);
  v.setWantsLayer(true);
  v.layer().setCornerRadius(6);
  v.layer().setBorderWidth(1);
  v.layer().setBorderColor(NSColor.separatorColor().CGColor());
  return v;
}
function makeCheckbox(frame, title, checked) {
  var b = NSButton.alloc().initWithFrame(frame);
  b.setButtonType(NSButtonTypeSwitch);
  b.setTitle(title);
  b.setState(checked ? NSOnState : NSOffState);
  return b;
}

/**
 * Mutually-exclusive radio group. options: [{label, value}].
 * IMPORTANT: each group gets its OWN enclosing NSView — Cocoa groups
 * NSButtonTypeRadio buttons by superview, so groups sharing one superview would
 * act as a single group. The first option sits at parent-y `top`.
 * @returns { get(), set(value), view }
 */
function makeRadioGroup(parent, options, layout, onChange) {
  var x = layout.x,
    top = layout.top,
    rowH = layout.rowH,
    width = layout.width;
  var n = options.length;
  var height = n * rowH;
  var group = NSView.alloc().initWithFrame(NSMakeRect(x, top - (n - 1) * rowH, width, height));
  parent.addSubview(group);
  var buttons = [];
  var selected = options[0] && options[0].value;
  options.forEach(function (opt, idx) {
    var ly = height - (idx + 1) * rowH; // local y; option 0 at top
    var b = NSButton.alloc().initWithFrame(NSMakeRect(0, ly, width, rowH - 2));
    b.setButtonType(NSButtonTypeRadio);
    b.setTitle(opt.label);
    b.setState(idx === 0 ? NSOnState : NSOffState);
    b.setCOSJSTargetFunction(function () {
      selected = opt.value; // native radio handles visual exclusivity within this group
      if (onChange) onChange(opt.value);
    });
    group.addSubview(b);
    buttons.push(b);
  });
  return {
    get: function get() {
      return selected;
    },
    set: function set(v) {
      var i = options.findIndex(function (o) {
        return o.value === v;
      });
      if (i >= 0) {
        buttons[i].setState(NSOnState);
        selected = v;
      }
    },
    view: group
  };
}

/***/ }),

/***/ "./src/utils/mocha.js":
/*!****************************!*\
  !*** ./src/utils/mocha.js ***!
  \****************************/
/*! exports provided: MochaJSDelegate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MochaJSDelegate", function() { return MochaJSDelegate; });


/**
 * Create an NSObject delegate whose selectors are backed by JS functions.
 * Shared helper — avoids re-inlining MochaJSDelegate per command.
 * Existing inline copies (inspectSymbolOrigin.js etc.) can migrate to this later.
 */
function MochaJSDelegate(selectorHandlerDict) {
  var uniqueClassName = 'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString();
  var desc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, NSObject);
  desc.registerClass();
  Object.keys(selectorHandlerDict).forEach(function (selectorString) {
    desc.addInstanceMethodWithSelector_function_(NSSelectorFromString(selectorString), selectorHandlerDict[selectorString]);
  });
  return NSClassFromString(uniqueClassName).new();
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=anonymize.js.map