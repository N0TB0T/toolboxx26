var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/contrast.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var toPropertyKey = __webpack_require__(/*! ./toPropertyKey.js */ "./node_modules/@babel/runtime/helpers/toPropertyKey.js");
function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}
module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toPrimitive.js":
/*!************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toPrimitive.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/typeof.js")["default"];
function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toPropertyKey.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toPropertyKey.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/typeof.js")["default"];
var toPrimitive = __webpack_require__(/*! ./toPrimitive.js */ "./node_modules/@babel/runtime/helpers/toPrimitive.js");
function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(o) {
  "@babel/helpers - typeof";

  return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
}
module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./src/contrast.js":
/*!*************************!*\
  !*** ./src/contrast.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _contrast_resolve__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contrast/resolve */ "./src/contrast/resolve.js");
/* harmony import */ var _contrast_panel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contrast/panel */ "./src/contrast/panel.js");


/**
 * Contrast Measure — command entry.
 * Resolves a foreground/background pair from the current selection (if any) and
 * opens the contrast panel. Without a usable selection it opens with defaults;
 * the user can then use the eyedropper or type hex values.
 */
var sketch = __webpack_require__(/*! sketch */ "sketch");
var _require = __webpack_require__(/*! sketch/dom */ "sketch/dom"),
  Document = _require.Document;


/* harmony default export */ __webpack_exports__["default"] = (function () {
  var document = Document.getSelectedDocument();
  if (!document) {
    sketch.UI.message('Kein Dokument geöffnet.');
    return;
  }
  var resolved = Object(_contrast_resolve__WEBPACK_IMPORTED_MODULE_0__["resolveFromSelection"])(document);
  if (!resolved) {
    // nothing selected → open with defaults, let the user pick/eyedrop
    Object(_contrast_panel__WEBPACK_IMPORTED_MODULE_1__["showContrastPanel"])({
      document: document
    });
    return;
  }
  Object(_contrast_panel__WEBPACK_IMPORTED_MODULE_1__["showContrastPanel"])({
    document: document,
    fg: resolved.fg && resolved.fg.hex,
    bg: resolved.bg && resolved.bg.hex,
    largeText: resolved.largeText,
    warnings: resolved.warnings
  });
});

/***/ }),

/***/ "./src/contrast/collect.js":
/*!*********************************!*\
  !*** ./src/contrast/collect.js ***!
  \*********************************/
/*! exports provided: collectFromSelection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collectFromSelection", function() { return collectFromSelection; });
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js");
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_swatchResolve__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/swatchResolve */ "./src/utils/swatchResolve.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! util */ "util");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_2__);


/**
 * Collect candidate colors from the current selection for the two swatch rows.
 *
 * Colors are read from the NATIVE side (fill/border/text MSColor, override values)
 * so each carries its swatchID — names are then resolved by identity via
 * utils/swatchResolve (never by color value). Sources, in the order we walk them:
 *
 *   override → an override value on a SymbolInstance that is a color
 *   style    → the layer's / instance's OWN style (fills, borders, text)
 *   nested   → colors on the resolved symbol master's child layers
 *   master   → the master's own style (its default colors)
 *
 * Depth is intentionally full (up to master defaults) because other tools will
 * consume the same collector. Result is deduped by swatch identity (else hex):
 *   { overrides: Entry[], others: Entry[] }
 *   Entry = { key, hex, name, isImported, libraryName, swatchID, source, label }
 *
 * NOTE: needs validation against a real file with Library swatches — the override
 * value shape (overrideValues()/value()) is the part most likely to vary.
 */



var DEBUG = false; // set true to log what the collector sees (diagnosing empties)
function dbg(msg) {
  if (DEBUG) console.log('[collect] ' + msg);
}
function safe(fn) {
  try {
    return fn();
  } catch (e) {
    return null;
  }
}
function toEntry(resolved, source, label) {
  if (!resolved) return null;
  return {
    key: resolved.swatchID || resolved.hex,
    // swatch identity wins; else the value
    hex: resolved.hex,
    name: resolved.name,
    isImported: resolved.isImported,
    libraryName: resolved.libraryName,
    swatchID: resolved.swatchID,
    source: source,
    label: label || ''
  };
}
function pushDedup(list, entry) {
  if (!entry) return;
  if (list.some(function (x) {
    return x.key === entry.key;
  })) return;
  list.push(entry);
}

/** Native colors from a layer's OWN style: enabled color fills, borders, text.
 * docData is passed so swatch lookup works even for colors whose own
 * documentData() is null (detached/immutable colors). */
function styleEntries(layer, source, docData) {
  var out = [];
  var st = safe(function () {
    return layer.style;
  });
  if (!st) return out;
  var name = safe(function () {
    return String(layer.name);
  }) || '';
  (safe(function () {
    return st.fills;
  }) || []).forEach(function (f, i) {
    if (f && f.enabled && f.fillType === 'Color') {
      var c = safe(function () {
        return f.sketchObject.color();
      });
      var e = toEntry(Object(_utils_swatchResolve__WEBPACK_IMPORTED_MODULE_1__["resolveNativeColor"])(c, docData), source, "".concat(name, " \xB7 Fill ").concat(i));
      if (e) out.push(e);
    }
  });
  (safe(function () {
    return st.borders;
  }) || []).forEach(function (b, i) {
    if (b && b.enabled) {
      var c = safe(function () {
        return b.sketchObject.color();
      });
      var e = toEntry(Object(_utils_swatchResolve__WEBPACK_IMPORTED_MODULE_1__["resolveNativeColor"])(c, docData), source, "".concat(name, " \xB7 Border ").concat(i));
      if (e) out.push(e);
    }
  });
  if (safe(function () {
    return layer.type;
  }) === 'Text') {
    var c = safe(function () {
      return layer.sketchObject.textColor && layer.sketchObject.textColor();
    });
    var e = toEntry(Object(_utils_swatchResolve__WEBPACK_IMPORTED_MODULE_1__["resolveNativeColor"])(c, docData), source, "".concat(name, " \xB7 Text"));
    if (e) out.push(e);
  }
  return out;
}

/** Recursively gather style colors under a master layer (nested + master defaults). */
function walkTree(rootLayer, source, acc, depth, docData) {
  if (!rootLayer || depth > 12) return;
  styleEntries(rootLayer, source, docData).forEach(function (e) {
    return acc.push(e);
  });
  var kids = safe(function () {
    return rootLayer.layers;
  });
  if (kids && kids.length) kids.forEach(function (k) {
    return walkTree(k, source, acc, depth + 1, docData);
  });
}

/** Color-typed override values on a SymbolInstance (native MSOverrideValue list). */
function overrideEntries(instance, docData) {
  var out = [];
  var raw = safe(function () {
    return instance.sketchObject.overrideValues();
  });
  var list = Object(util__WEBPACK_IMPORTED_MODULE_2__["toArray"])(raw) || [];
  dbg("  overrideValues: ".concat(list.length));
  list.forEach(function (ov) {
    var val = safe(function () {
      return ov.value();
    });
    var cls = safe(function () {
      return String(val && val.className && val.className());
    }) || (val == null ? 'null' : _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default()(val));
    var isColor = val && (safe(function () {
      return typeof val.red === 'function';
    }) || cls.indexOf('Color') >= 0);
    var ovName = safe(function () {
      return String(ov.overrideName ? ov.overrideName() : '');
    }) || '';
    dbg("    ov \"".concat(ovName, "\" value=").concat(cls, " isColor=").concat(!!isColor));
    if (!isColor) return;
    var e = toEntry(Object(_utils_swatchResolve__WEBPACK_IMPORTED_MODULE_1__["resolveNativeColor"])(val, docData), 'override', ovName || 'Override');
    if (e) out.push(e);
  });
  return out;
}

/**
 * @returns { overrides: Entry[], others: Entry[] }
 */
function collectFromSelection(document) {
  var layers = safe(function () {
    return document.selectedLayers.layers;
  }) || [];
  var overrides = [];
  var others = [];
  // the document's data — the authoritative swatch registry for ID lookups
  var docData = safe(function () {
    return document.sketchObject.documentData();
  });
  dbg("selected layers: ".concat(layers.length, " [").concat(layers.map(function (l) {
    return safe(function () {
      return l.type;
    });
  }).join(', '), "] docData=").concat(!!docData));
  layers.forEach(function (L) {
    var type = safe(function () {
      return L.type;
    });
    if (type === 'SymbolInstance') {
      dbg("SymbolInstance \"".concat(safe(function () {
        return String(L.name);
      }), "\" master=").concat(safe(function () {
        return !!L.master;
      })));
      // 1) override colors
      overrideEntries(L, docData).forEach(function (e) {
        return pushDedup(overrides, e);
      });
      // 2) instance's own style (rare, but real)
      styleEntries(L, 'style', docData).forEach(function (e) {
        return pushDedup(others, e);
      });
      // 3+4) nested layers + master defaults
      var master = safe(function () {
        return L.master;
      });
      if (master) {
        var acc = [];
        walkTree(master, 'master', acc, 0, docData);
        acc.forEach(function (e) {
          return pushDedup(others, e);
        });
      }
    } else {
      // plain layer (or group/frame): its own style + descendants
      var _acc = [];
      walkTree(L, 'style', _acc, 0, docData);
      _acc.forEach(function (e) {
        return pushDedup(others, e);
      });
    }
  });
  dbg("result \u2192 overrides=".concat(overrides.length, " others=").concat(others.length));
  if (DEBUG) {
    overrides.forEach(function (e) {
      return dbg("  OVER  name=".concat(e.name, " swatchID=").concat(e.swatchID, " hex=").concat(e.hex, " lib=").concat(e.libraryName));
    });
    others.forEach(function (e) {
      return dbg("  OTHER name=".concat(e.name, " swatchID=").concat(e.swatchID, " hex=").concat(e.hex, " lib=").concat(e.libraryName));
    });
  }
  return {
    overrides: overrides,
    others: others
  };
}

/***/ }),

/***/ "./src/contrast/core.js":
/*!******************************!*\
  !*** ./src/contrast/core.js ***!
  \******************************/
/*! exports provided: parseHexColor, toHex8, compositeOver, flattenOnto, srgbToLinear, relativeLuminance, wcagContrastRatio, wcagAssessment, isLargeText, rgbToLab, deltaE2000, analyzePair */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseHexColor", function() { return parseHexColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toHex8", function() { return toHex8; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "compositeOver", function() { return compositeOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "flattenOnto", function() { return flattenOnto; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "srgbToLinear", function() { return srgbToLinear; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "relativeLuminance", function() { return relativeLuminance; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "wcagContrastRatio", function() { return wcagContrastRatio; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "wcagAssessment", function() { return wcagAssessment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isLargeText", function() { return isLargeText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rgbToLab", function() { return rgbToLab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deltaE2000", function() { return deltaE2000; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "analyzePair", function() { return analyzePair; });


/**
 * Pure color-contrast math. NO Sketch/Cocoa dependencies — node-testable.
 * WCAG 2.x ratio + alpha compositing + ΔE2000. (APCA removed — license excludes design tools.)
 * Colors are {r,g,b} in 0..255 with optional a in 0..1.
 */

// --- Hex parsing -------------------------------------------------------------
function parseHexColor(input) {
  if (input == null) return null;
  var s = String(input).trim().replace(/^#/, '');
  if (/^[0-9a-fA-F]{3}$/.test(s)) s = s.split('').map(function (c) {
    return c + c;
  }).join('') + 'ff';else if (/^[0-9a-fA-F]{4}$/.test(s)) s = s.split('').map(function (c) {
    return c + c;
  }).join('');else if (/^[0-9a-fA-F]{6}$/.test(s)) s = s + 'ff';else if (!/^[0-9a-fA-F]{8}$/.test(s)) return null;
  return {
    r: parseInt(s.slice(0, 2), 16),
    g: parseInt(s.slice(2, 4), 16),
    b: parseInt(s.slice(4, 6), 16),
    a: parseInt(s.slice(6, 8), 16) / 255
  };
}
function toHex8(c) {
  var h = function h(n) {
    var x = Math.max(0, Math.min(255, Math.round(n))).toString(16);
    return x.length === 1 ? '0' + x : x;
  };
  var a = c.a == null ? 1 : c.a;
  return ('#' + h(c.r) + h(c.g) + h(c.b) + h(a * 255)).toUpperCase();
}

// --- Alpha compositing (source-over, W3C Compositing L1) ----------------------

function compositeOver(fg, bg) {
  var fa = fg.a == null ? 1 : fg.a;
  var ba = bg.a == null ? 1 : bg.a;
  var outA = fa + ba * (1 - fa);
  var blend = function blend(f, b) {
    return outA === 0 ? 0 : (f * fa + b * ba * (1 - fa)) / outA;
  };
  return {
    r: blend(fg.r, bg.r),
    g: blend(fg.g, bg.g),
    b: blend(fg.b, bg.b),
    a: outA
  };
}

/** Flatten a (possibly translucent) color over an opaque backdrop → opaque rgb. */
function flattenOnto(color, backdrop) {
  var out = compositeOver(color, {
    r: backdrop.r,
    g: backdrop.g,
    b: backdrop.b,
    a: 1
  });
  return {
    r: out.r,
    g: out.g,
    b: out.b,
    a: 1
  };
}

// --- WCAG 2.x ----------------------------------------------------------------

function srgbToLinear(c8) {
  var cs = c8 / 255;
  return cs <= 0.04045 ? cs / 12.92 : Math.pow((cs + 0.055) / 1.055, 2.4);
}
function relativeLuminance(rgb) {
  return 0.2126 * srgbToLinear(rgb.r) + 0.7152 * srgbToLinear(rgb.g) + 0.0722 * srgbToLinear(rgb.b);
}
function wcagContrastRatio(rgbA, rgbB) {
  var l1 = relativeLuminance(rgbA);
  var l2 = relativeLuminance(rgbB);
  var hi = Math.max(l1, l2);
  var lo = Math.min(l1, l2);
  return (hi + 0.05) / (lo + 0.05);
}
function wcagAssessment(ratio) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$largeText = _ref.largeText,
    largeText = _ref$largeText === void 0 ? false : _ref$largeText;
  return {
    ratio: ratio,
    normalAA: ratio >= 4.5,
    normalAAA: ratio >= 7,
    largeAA: ratio >= 3,
    largeAAA: ratio >= 4.5,
    nonText: ratio >= 3,
    appliesLarge: !!largeText
  };
}

// NOTE: APCA was intentionally removed. Its license (Myndex/apca-w3) restricts
// use to web-delivered/web-based content within WCAG and explicitly excludes
// design tools — so it must not ship in this Sketch plugin. We keep the two
// freely-implementable metrics: WCAG 2.1 (W3C) and ΔE2000 (CIE).

// --- Large-text classification (WCAG 1.4.3): ≥24px, or ≥18.66px AND bold -----

function isLargeText(fontSizePx, bold) {
  if (fontSizePx == null) return false;
  return fontSizePx >= 24 || !!bold && fontSizePx >= 18.66;
}

// --- ΔE2000 (optional "how different" metric, distinct from contrast) ---------

function rgbToLab(rgb) {
  var r = srgbToLinear(rgb.r);
  var g = srgbToLinear(rgb.g);
  var b = srgbToLinear(rgb.b);
  // linear sRGB → XYZ (D65)
  var X = 0.4124564 * r + 0.3575761 * g + 0.1804375 * b;
  var Y = 0.2126729 * r + 0.7151522 * g + 0.0721750 * b;
  var Z = 0.0193339 * r + 0.1191920 * g + 0.9503041 * b;
  var xn = 0.95047;
  var yn = 1.0;
  var zn = 1.08883;
  var f = function f(t) {
    return t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
  };
  var fx = f(X / xn);
  var fy = f(Y / yn);
  var fz = f(Z / zn);
  return {
    L: 116 * fy - 16,
    a: 500 * (fx - fy),
    b: 200 * (fy - fz)
  };
}
function deltaE2000(lab1, lab2) {
  var rad = Math.PI / 180;
  var deg = 180 / Math.PI;
  var L1 = lab1.L,
    a1 = lab1.a,
    b1 = lab1.b;
  var L2 = lab2.L,
    a2 = lab2.a,
    b2 = lab2.b;
  var C1 = Math.hypot(a1, b1);
  var C2 = Math.hypot(a2, b2);
  var Cbar = (C1 + C2) / 2;
  var C7 = Math.pow(Cbar, 7);
  var G = 0.5 * (1 - Math.sqrt(C7 / (C7 + Math.pow(25, 7))));
  var a1p = (1 + G) * a1;
  var a2p = (1 + G) * a2;
  var C1p = Math.hypot(a1p, b1);
  var C2p = Math.hypot(a2p, b2);
  var hp = function hp(b, ap) {
    if (b === 0 && ap === 0) return 0;
    var h = Math.atan2(b, ap) * deg;
    return h < 0 ? h + 360 : h;
  };
  var h1p = hp(b1, a1p);
  var h2p = hp(b2, a2p);
  var dLp = L2 - L1;
  var dCp = C2p - C1p;
  var dhp;
  if (C1p * C2p === 0) dhp = 0;else if (Math.abs(h2p - h1p) <= 180) dhp = h2p - h1p;else if (h2p - h1p > 180) dhp = h2p - h1p - 360;else dhp = h2p - h1p + 360;
  var dHp = 2 * Math.sqrt(C1p * C2p) * Math.sin(dhp * rad / 2);
  var Lbarp = (L1 + L2) / 2;
  var Cbarp = (C1p + C2p) / 2;
  var hbarp;
  if (C1p * C2p === 0) hbarp = h1p + h2p;else if (Math.abs(h1p - h2p) <= 180) hbarp = (h1p + h2p) / 2;else if (h1p + h2p < 360) hbarp = (h1p + h2p + 360) / 2;else hbarp = (h1p + h2p - 360) / 2;
  var T = 1 - 0.17 * Math.cos((hbarp - 30) * rad) + 0.24 * Math.cos(2 * hbarp * rad) + 0.32 * Math.cos((3 * hbarp + 6) * rad) - 0.20 * Math.cos((4 * hbarp - 63) * rad);
  var dTheta = 30 * Math.exp(-Math.pow((hbarp - 275) / 25, 2));
  var Cbarp7 = Math.pow(Cbarp, 7);
  var RC = 2 * Math.sqrt(Cbarp7 / (Cbarp7 + Math.pow(25, 7)));
  var SL = 1 + 0.015 * Math.pow(Lbarp - 50, 2) / Math.sqrt(20 + Math.pow(Lbarp - 50, 2));
  var SC = 1 + 0.045 * Cbarp;
  var SH = 1 + 0.015 * Cbarp * T;
  var RT = -Math.sin(2 * dTheta * rad) * RC;
  return Math.sqrt(Math.pow(dLp / SL, 2) + Math.pow(dCp / SC, 2) + Math.pow(dHp / SH, 2) + RT * (dCp / SC) * (dHp / SH));
}

// --- High-level convenience --------------------------------------------------

/**
 * Analyze a foreground/background pair. Inputs may be hex strings or {r,g,b,a}.
 * Composites translucent colors before computing; collects warnings.
 */
function analyzePair(fgInput, bgInput) {
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var fg = typeof fgInput === 'string' ? parseHexColor(fgInput) : fgInput;
  var bg = typeof bgInput === 'string' ? parseHexColor(bgInput) : bgInput;
  if (!fg || !bg) return null;
  var warnings = [];
  var bgFlat = {
    r: bg.r,
    g: bg.g,
    b: bg.b,
    a: 1
  };
  if (bg.a != null && bg.a < 1) {
    warnings.push('Hintergrund halbtransparent — echter Backdrop unbekannt, Ergebnis ungenau');
  }
  var fgFlat;
  if (fg.a != null && fg.a < 1) {
    fgFlat = flattenOnto(fg, bgFlat);
    warnings.push('Vordergrund halbtransparent — über Hintergrund kompositiert');
  } else {
    fgFlat = {
      r: fg.r,
      g: fg.g,
      b: fg.b,
      a: 1
    };
  }
  var ratio = wcagContrastRatio(fgFlat, bgFlat);
  return {
    fg: fg,
    bg: bg,
    fgFlat: fgFlat,
    bgFlat: bgFlat,
    wcag: wcagAssessment(ratio, {
      largeText: !!opts.largeText
    }),
    deltaE2000: deltaE2000(rgbToLab(fgFlat), rgbToLab(bgFlat)),
    warnings: warnings
  };
}


/***/ }),

/***/ "./src/contrast/panel.js":
/*!*******************************!*\
  !*** ./src/contrast/panel.js ***!
  \*******************************/
/*! exports provided: showContrastPanel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showContrastPanel", function() { return showContrastPanel; });
/* harmony import */ var _utils_mocha__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/mocha */ "./src/utils/mocha.js");
/* harmony import */ var _ui_controls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../ui/controls */ "./src/ui/controls.js");
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core */ "./src/contrast/core.js");
/* harmony import */ var _sampler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sampler */ "./src/contrast/sampler.js");
/* harmony import */ var _collect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./collect */ "./src/contrast/collect.js");


/**
 * Native NSPanel for the contrast tool — compact view.
 * Renders from a small view-model recomputed via core.analyzePair on every change.
 * Looks native (system font, windowBackgroundColor, labelColor → auto light/dark).
 *
 * NOTE: UI is built against documented AppKit/Sketch patterns but needs an
 * in-Sketch smoke test (cannot run Sketch headless).
 */
var sketch = __webpack_require__(/*! sketch */ "sketch");






// Material Icons (24×24 path data) rendered as TEMPLATE NSImages — tint to the
// control's label color, adapt to light/dark, no background. Always Material.
var ICON = {
  swap_horiz: 'M6.99 11L3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z',
  content_copy: 'M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z',
  info: 'M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z'
};
function materialIcon(pathD, size) {
  try {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="' + pathD + '"/></svg>';
    var data = NSString.stringWithString(svg).dataUsingEncoding(4); // NSUTF8StringEncoding
    var img = NSImage.alloc().initWithData(data);
    if (img && img.isValid && img.isValid()) {
      img.setTemplate(true);
      img.setSize(NSMakeSize(size, size));
      return img;
    }
  } catch (e) {}
  return null;
}
var L = {
  width: 374,
  margin: 16,
  swatchW: 153,
  // two swatches + a narrow swap button between them
  swatchH: 46,
  fieldH: 22,
  swapW: 24,
  gap: 6
};
function cgFor(hex) {
  var c = Object(_core__WEBPACK_IMPORTED_MODULE_2__["parseHexColor"])(hex) || {
    r: 127,
    g: 127,
    b: 127,
    a: 1
  };
  return NSColor.colorWithSRGBRed_green_blue_alpha(c.r / 255, c.g / 255, c.b / 255, c.a == null ? 1 : c.a).CGColor();
}
var mark = function mark(ok) {
  return ok ? '✓' : '✗';
};

/**
 * @param {{fg?:string, bg?:string, largeText?:boolean, warnings?:string[]}} initial
 */
function showContrastPanel() {
  var initial = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var state = {
    fgHex: initial.fg && String(initial.fg) || '#000000FF',
    bgHex: initial.bg && String(initial.bg) || '#FFFFFFFF',
    largeText: !!initial.largeText,
    extraWarnings: initial.warnings || [],
    document: initial.document || null
  };

  // ---- layout plan (computed ONCE at open) --------------------------------
  // Override grid is capped at 2 rows; the panel height adapts to how many rows
  // are actually needed so few overrides don't leave a tall empty panel.
  var CHIP_RECT_H = 30;
  var CHIP_H = CHIP_RECT_H + 3 + 13 + 11; // color bar + name + hex
  var LIST_ROW = 30;
  var GRID_COLS = 3;
  var collected = state.document ? Object(_collect__WEBPACK_IMPORTED_MODULE_4__["collectFromSelection"])(state.document) : {
    overrides: [],
    others: []
  };
  var hasOver = collected.overrides.length > 0;
  var hasOthers = collected.others.length > 0;
  var hasAny = hasOver || hasOthers;
  var overRows = Math.min(2, Math.max(1, Math.ceil(collected.overrides.length / GRID_COLS)));
  var OVER_VP = overRows * (CHIP_H + 8);
  var LIST_VP = 4 * LIST_ROW;
  var Y_BOX = 294; // grey info box (ΔE2000), always visible
  var BOX_H = 28;
  // Stack the selection sections below the grey box — only present ones take
  // space, so an empty selection yields a short panel and it grows to fit.
  var _y = Y_BOX + BOX_H + 14;
  var Y_HINT = null;
  var Y_OVER_LABEL = null;
  var Y_OVER_GRID = null;
  var Y_OTHERS_LABEL = null;
  var Y_OTHERS_LIST = null;
  if (hasAny) {
    Y_HINT = _y;
    _y += 12 + 16;
  }
  if (hasOver) {
    Y_OVER_LABEL = _y;
    Y_OVER_GRID = _y + 15;
    _y = Y_OVER_GRID + OVER_VP + 12;
  }
  if (hasOthers) {
    Y_OTHERS_LABEL = _y;
    Y_OTHERS_LIST = _y + 15;
    _y = Y_OTHERS_LIST + LIST_VP + 12;
  }
  var H = _y + 36; // gap + 28px close-button row

  var threadDictionary = NSThread.mainThread().threadDictionary();
  var identifier = 'net.notbot.toolboxx.contrastMeasure';
  var delegateKey = identifier + '.delegate';

  // Close ANY existing contrast panels — including orphans from a prior run that
  // are no longer in this thread dictionary (opening the plugin twice can stack
  // duplicates under the same title, which looked like "close does nothing").
  var PANEL_TITLE = 'Kontrast';
  try {
    var wins = NSApp.windows();
    for (var i = wins.count() - 1; i >= 0; i--) {
      var w = wins.objectAtIndex(i);
      try {
        if (String(w.title()) === PANEL_TITLE) w.close();
      } catch (e) {}
    }
  } catch (e) {}
  try {
    threadDictionary.removeObjectForKey(identifier);
    threadDictionary.removeObjectForKey(delegateKey);
  } catch (e) {}
  var styleMask = NSWindowStyleMaskTitled | NSWindowStyleMaskClosable;
  var backing = typeof NSBackingStoreBuffered !== 'undefined' ? NSBackingStoreBuffered : 2;
  var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer_(NSMakeRect(0, 0, L.width, H), styleMask, backing, false);
  panel.setBackgroundColor(NSColor.windowBackgroundColor());
  panel.title = PANEL_TITLE;
  // The native traffic-light close is unreliable for these CocoaScript panels
  // (its action is not wired), so hide the buttons and use the "Schließen" button.
  [0, 1, 2].forEach(function (t) {
    try {
      var b = panel.standardWindowButton(t);
      if (b) b.setHidden(true);
    } catch (e) {}
  });
  panel.center();
  panel.makeKeyAndOrderFront(null);
  panel.setLevel(NSFloatingWindowLevel);

  // Notausgang, bevor Inhalt gezeichnet wird. Hier besonders wichtig: dieses
  // Panel versteckt die Fensterknoepfe absichtlich (ihre Aktion ist in
  // CocoaScript nicht verdrahtet), es gibt also NUR den eigenen Schliessen-
  // Button — wirft der Aufbau davor, bliebe das Fenster unschliessbar.
  //
  // applyPanelChrome wird hier NICHT verwendet: eine transparente Titelleiste
  // ergibt ohne sichtbare Fensterknoepfe keinen Sinn.
  Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["addEscapeHatch"])(panel, function (m) {
    return console.log("[contrast] ".concat(m));
  });
  COScript.currentCOScript().setShouldKeepAround_(true);
  var cleanupAndStop = function cleanupAndStop() {
    try {
      Object(_sampler__WEBPACK_IMPORTED_MODULE_3__["stopScreenColor"])(); // detach + hide the shared color panel
    } catch (e) {}
    try {
      threadDictionary.removeObjectForKey(identifier);
      threadDictionary.removeObjectForKey(delegateKey);
    } catch (e) {}
    COScript.currentCOScript().setShouldKeepAround_(false);
  };
  var content = panel.contentView();
  var topY = function topY(fromTop, h) {
    return H - fromTop - h;
  };

  // --- swatches + hex fields (swap button sits narrow between the swatches) ---
  var bgX = L.margin + L.swatchW + L.swapW + 2 * L.gap; // x of the HG column
  var swapX = L.margin + L.swatchW + L.gap;
  var swRowY = topY(L.margin, L.swatchH);
  var swFg = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeSwatch"])(NSMakeRect(L.margin, swRowY, L.swatchW, L.swatchH));
  var swBg = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeSwatch"])(NSMakeRect(bgX, swRowY, L.swatchW, L.swatchH));
  content.addSubview(swFg);
  content.addSubview(swBg);
  var swapBtn = NSButton.alloc().initWithFrame(NSMakeRect(swapX, swRowY, L.swapW, L.swatchH));
  swapBtn.setBordered(false); // no background
  swapBtn.setTitle('');
  swapBtn.setToolTip('VG/HG tauschen');
  var swapImg = materialIcon(ICON.swap_horiz, 22);
  if (swapImg) {
    swapBtn.setImage(swapImg);
    if (typeof NSImageOnly !== 'undefined') swapBtn.setImagePosition(NSImageOnly);
  } else {
    swapBtn.setTitle('Tauschen');
  }
  content.addSubview(swapBtn);
  var fieldY = topY(L.margin + L.swatchH + 6, L.fieldH);
  var fgField = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeField"])(NSMakeRect(L.margin, fieldY, L.swatchW, L.fieldH), state.fgHex, {
    align: 'center'
  });
  var bgField = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeField"])(NSMakeRect(bgX, fieldY, L.swatchW, L.fieldH), state.bgHex, {
    align: 'center'
  });
  content.addSubview(fgField);
  content.addSubview(bgField);
  content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(L.margin, fieldY - 18, L.swatchW, 16), 'Vordergrund', {
    size: 10,
    color: NSColor.secondaryLabelColor()
  }));
  content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(bgX, fieldY - 18, L.swatchW, 16), 'Hintergrund', {
    size: 10,
    align: 'right',
    color: NSColor.secondaryLabelColor()
  }));
  swapBtn.setCOSJSTargetFunction(function () {
    var t = state.fgHex;
    state.fgHex = state.bgHex;
    state.bgHex = t;
    fgField.setStringValue(state.fgHex);
    bgField.setStringValue(state.bgHex);
    render();
  });

  // --- WCAG big ratio (selectable) + copy button ---
  // The ratio label is left-aligned and repositioned in render() so it sits as a
  // centered cluster next to the copy button (no full-width selectable field under
  // the button → no I-beam cursor bleeding onto it).
  var RATIO_BAND_Y = topY(130, 34);
  var ratioLabel = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(0, RATIO_BAND_Y, L.width, 34), '', {
    size: 26,
    bold: true,
    selectable: true
  });
  content.addSubview(ratioLabel);
  content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(0, topY(166, 14), L.width, 14), 'WCAG 2.1 Kontrastverhältnis', {
    size: 10,
    align: 'center',
    color: NSColor.secondaryLabelColor()
  }));
  var copyRatioBtn = NSButton.alloc().initWithFrame(NSMakeRect(0, RATIO_BAND_Y + 3, 22, 26));
  copyRatioBtn.setBordered(false); // swap-look, just smaller
  copyRatioBtn.setToolTip('Kontrastverhältnis kopieren');
  var copyImg = materialIcon(ICON.content_copy, 15);
  if (copyImg) {
    copyRatioBtn.setImage(copyImg);
    if (typeof NSImageOnly !== 'undefined') copyRatioBtn.setImagePosition(NSImageOnly);
  } else {
    copyRatioBtn.setTitle('Kopieren');
  }
  copyRatioBtn.setCOSJSTargetFunction(function () {
    if (Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["copyToClipboard"])(state.ratioText || '')) sketch.UI.message('Kopiert: ' + (state.ratioText || ''));
  });
  content.addSubview(copyRatioBtn);

  // lay ratio text + copy button out as a horizontally centered cluster
  var RATIO_GAP = 8;
  var BTN_W = 22;
  var layoutRatioCluster = function layoutRatioCluster() {
    ratioLabel.sizeToFit();
    var tw = ratioLabel.frame().size.width;
    var th = ratioLabel.frame().size.height;
    var total = tw + RATIO_GAP + BTN_W;
    var startX = Math.max(L.margin, Math.round((L.width - total) / 2));
    ratioLabel.setFrameOrigin(NSMakePoint(startX, RATIO_BAND_Y + Math.round((34 - th) / 2)));
    copyRatioBtn.setFrameOrigin(NSMakePoint(startX + tw + RATIO_GAP, RATIO_BAND_Y + 3));
  };

  // --- WCAG pass/fail table (fixed columns: [dot][row] AA  AAA) ---------------
  var innerW = L.width - 2 * L.margin;
  // ✓ = green nudged toward blue, ✗ = red nudged toward magenta; both well-saturated.
  var OK_COLOR = NSColor.colorWithSRGBRed_green_blue_alpha(0.11, 0.74, 0.44, 1);
  var NO_COLOR = NSColor.colorWithSRGBRed_green_blue_alpha(0.92, 0.11, 0.42, 1);
  var LBL_X = L.margin;
  var LBL_W = 144;
  var COL_W = 46;
  var AA_X = L.margin + 148;
  var AAA_X = L.margin + 200;
  var rowH = 18;
  var cell = function cell(x, y, text, opts) {
    var l = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(x, topY(y, rowH), opts && opts.w ? opts.w : COL_W, rowH), text, {
      size: opts && opts.size ? opts.size : 13,
      bold: !(opts && opts.notBold),
      align: opts && opts.align ? opts.align : 'center',
      color: opts && opts.color,
      selectable: true
    });
    content.addSubview(l);
    return l;
  };
  // header row
  cell(AA_X, 202, 'AA', {
    size: 11,
    color: NSColor.secondaryLabelColor()
  });
  cell(AAA_X, 202, 'AAA', {
    size: 11,
    color: NSColor.secondaryLabelColor()
  });
  // data rows: name + AA + AAA
  cell(LBL_X, 218, 'Normaltext', {
    w: LBL_W,
    align: 'left',
    notBold: true,
    size: 12
  });
  var badgeNormalAA = cell(AA_X, 218, '', {});
  var badgeNormalAAA = cell(AAA_X, 218, '', {});
  cell(LBL_X, 236, 'Großtext', {
    w: LBL_W,
    align: 'left',
    notBold: true,
    size: 12
  });
  var badgeLargeAA = cell(AA_X, 236, '', {});
  var badgeLargeAAA = cell(AAA_X, 236, '', {});
  cell(LBL_X, 254, 'Non-Text / UI (3:1)', {
    w: LBL_W + 20,
    align: 'left',
    notBold: true,
    size: 12
  });
  var badgeNonTextMark = cell(AA_X, 254, '', {});
  var setMark = function setMark(field, pass) {
    field.setStringValue(pass ? '✓' : '✗');
    field.setTextColor(pass ? OK_COLOR : NO_COLOR);
  };

  // --- warnings (selectable) ---
  var warnLabel = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(L.margin, topY(274, 16), innerW, 16), '', {
    size: 10,
    color: NSColor.systemOrangeColor(),
    selectable: true
  });
  content.addSubview(warnLabel);

  // --- Details: plain grey box, always visible (no heading, no toggle) ---------
  var box = NSView.alloc().initWithFrame(NSMakeRect(L.margin, topY(Y_BOX, BOX_H), innerW, BOX_H));
  box.setWantsLayer(true);
  box.layer().setBackgroundColor(NSColor.colorWithWhite_alpha_(0.5, 0.12).CGColor()); // subtle grey, theme-adaptive
  box.layer().setCornerRadius(6);
  content.addSubview(box);

  // single line inside the box: label left, value right (bottom-left origin)
  var boxRowY = Math.round((BOX_H - 14) / 2);
  box.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(12, boxRowY, innerW / 2, 14), 'Farbabstand ΔE2000', {
    size: 10,
    color: NSColor.secondaryLabelColor(),
    selectable: true
  }));
  var deltaValue = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(innerW / 2, boxRowY, innerW / 2 - 12, 14), '', {
    size: 11,
    weight: 'medium',
    align: 'right',
    selectable: true
  });
  box.addSubview(deltaValue);

  // --- swatches from selection (two rows: overrides / others) -----------------
  // Click a chip = set foreground; ⌥(Option)+Click = set background.
  var applyPick = function applyPick(entry) {
    var alt = (NSEvent.modifierFlags() & NSAlternateKeyMask) !== 0;
    var hex = entry.hex;
    if (alt) {
      state.bgHex = hex;
      bgField.setStringValue(hex);
      dismissHint(); // user used the ⌥ combo → hide the how-to hint
    } else {
      state.fgHex = hex;
      fgField.setStringValue(hex);
    }
    state.extraWarnings = [];
    render();
  };

  // NSLineBreakByTruncatingTail may not be a defined global in CocoaScript — guard it.
  var LB_TRUNC_TAIL = typeof NSLineBreakByTruncatingTail !== 'undefined' ? NSLineBreakByTruncatingTail : 4;

  // leaf swatch name (drop group path like "Topologie/…") for compact display
  var leaf = function leaf(name) {
    return name ? String(name).split('/').pop() : null;
  };
  var tipFor = function tipFor(e) {
    var origin = e.libraryName || (e.isImported ? 'Library' : e.name ? 'Lokal' : null);
    var parts = [e.hex];
    if (origin) parts.push(origin);
    parts.push(e.source);
    return "".concat(e.name || '(kein Swatch)', "\n").concat(parts.join('   |   '));
  };
  var measure = function measure(text, size) {
    var l = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(0, 0, 10, 16), text, {
      size: size
    });
    l.sizeToFit();
    return Math.ceil(l.frame().size.width);
  };
  var clickOverlay = function clickOverlay(w, h, e) {
    var hit = NSButton.alloc().initWithFrame(NSMakeRect(0, 0, w, h));
    hit.setTransparent(true);
    hit.setTitle('');
    hit.setBordered(false);
    hit.setToolTip(tipFor(e));
    hit.setCOSJSTargetFunction(function () {
      return applyPick(e);
    });
    return hit;
  };

  // OVERRIDES — grid of chips: wide color bar / name / hex, all right-aligned.
  // RECT_H/CHIP_H/GRID_COLS come from the layout plan at the top of this function.
  var RECT_H = CHIP_RECT_H;
  var CHIP_PAD = 4; // right padding for the right-aligned labels
  var GRID_GAP = 8;
  // For a non-flipped doc view, show its TOP when content overflows the viewport.
  var scrollTop = function scrollTop(scroll, docH) {
    try {
      var vh = scroll.contentView().bounds().size.height;
      if (docH > vh) {
        scroll.contentView().scrollToPoint(NSMakePoint(0, docH - vh));
        scroll.reflectScrolledClipView(scroll.contentView());
      }
    } catch (e) {}
  };
  var makeChipGrid = function makeChipGrid(frame, entries) {
    var scroll = NSScrollView.alloc().initWithFrame(frame);
    scroll.setHasVerticalScroller(true);
    scroll.setHasHorizontalScroller(false);
    scroll.setDrawsBackground(false);
    scroll.setBorderType(NSNoBorder);
    scroll.setScrollerStyle(NSScrollerStyleOverlay);
    var viewW = frame.size.width;
    // FIXED columns → uniform chip width (a clean grid, no ragged rows).
    var cols = GRID_COLS;
    var cw = Math.floor((viewW - (cols - 1) * GRID_GAP) / cols);
    var list = entries || [];
    var rows = Math.ceil(list.length / cols);
    var stride = CHIP_H + GRID_GAP;
    var docH = Math.max(frame.size.height, rows * stride + 2);
    // plain (non-flipped) doc view — NEVER a JS-backed isFlipped subclass; the
    // render loop calls isFlipped and a stale Mocha block crashes Sketch over time.
    var docView = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewW, docH));
    list.forEach(function (e, i) {
      var col = i % cols;
      var row = Math.floor(i / cols);
      var cx = col * (cw + GRID_GAP);
      var cy = docH - 2 - row * stride - CHIP_H; // top-down in bottom-left coords
      var chip = NSView.alloc().initWithFrame(NSMakeRect(cx, cy, cw, CHIP_H)); // bottom-left inside
      var rect = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeSwatch"])(NSMakeRect(0, CHIP_H - RECT_H, cw, RECT_H)); // wide color bar
      rect.layer().setCornerRadius(4);
      rect.layer().setBackgroundColor(cgFor(e.hex));
      chip.addSubview(rect);
      var nameText = leaf(e.name) || e.hex;
      var nameL = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(0, 11, cw - CHIP_PAD, 13), nameText, {
        size: 10,
        align: 'right'
      });
      nameL.setLineBreakMode(LB_TRUNC_TAIL);
      chip.addSubview(nameL);
      chip.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(0, 0, cw - CHIP_PAD, 11), e.hex, {
        size: 8,
        align: 'right',
        color: NSColor.secondaryLabelColor()
      }));
      chip.addSubview(clickOverlay(cw, CHIP_H, e));
      docView.addSubview(chip);
    });
    scroll.setDocumentView(docView);
    scrollTop(scroll, docH);
    return scroll;
  };

  // SONSTIGE — vertical scrollable list: [16 color]  Name … #HEX  (one per row).
  var makeSwatchList = function makeSwatchList(frame, entries) {
    var scroll = NSScrollView.alloc().initWithFrame(frame);
    scroll.setHasVerticalScroller(true);
    scroll.setHasHorizontalScroller(false);
    scroll.setDrawsBackground(false);
    scroll.setBorderType(NSNoBorder);
    scroll.setScrollerStyle(NSScrollerStyleOverlay);
    var viewW = frame.size.width;
    var n = (entries || []).length;
    var docH = Math.max(frame.size.height, n * LIST_ROW + 2);
    var docView = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewW, docH)); // plain, non-flipped
    (entries || []).forEach(function (e, i) {
      var row = NSView.alloc().initWithFrame(NSMakeRect(0, docH - (i + 1) * LIST_ROW, viewW, LIST_ROW)); // top-down
      var BOX = 20;
      var TXT_H = 17;
      // single-line NSTextField glyphs sit ~1px high in their box → nudge text down 1px
      var txtY = Math.round((LIST_ROW - TXT_H) / 2) - 1;
      var box = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeSwatch"])(NSMakeRect(6, (LIST_ROW - BOX) / 2, BOX, BOX));
      box.layer().setCornerRadius(4);
      box.layer().setBackgroundColor(cgFor(e.hex));
      row.addSubview(box);
      var nameText = leaf(e.name) || e.hex;
      var hexW = 74;
      var nameX = 6 + BOX + 8;
      var nameL = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(nameX, txtY, viewW - nameX - hexW - 6, TXT_H), nameText, {
        size: 12
      });
      nameL.setLineBreakMode(LB_TRUNC_TAIL);
      row.addSubview(nameL);
      row.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(viewW - hexW - 4, txtY, hexW, TXT_H), e.hex, {
        size: 10,
        align: 'right',
        color: NSColor.secondaryLabelColor()
      }));
      row.addSubview(clickOverlay(viewW, LIST_ROW, e));
      docView.addSubview(row);
    });
    scroll.setDocumentView(docView);
    scrollTop(scroll, docH);
    return scroll;
  };

  // Hint above the overrides. Auto-hides after the first ⌥+click (background pick)
  // for the current panel; reappears next open. Deliberately NOT persisted in the
  // main-thread threadDictionary — a non-native value there breaks Sketch's command
  // teardown (crashes on session cleanup).
  // info-marked hint: [ⓘ] Klick = Vordergrund · ⌥+Klick = Hintergrund (only if
  // there are swatches to click).
  var hintLabel = null;
  var hintIcon = null;
  if (hasAny) {
    hintIcon = NSImageView.alloc().initWithFrame(NSMakeRect(L.margin, topY(Y_HINT + 1, 12), 12, 12));
    var infoImg = materialIcon(ICON.info, 12);
    if (infoImg) {
      hintIcon.setImage(infoImg);
      if (hintIcon.setContentTintColor) hintIcon.setContentTintColor(NSColor.secondaryLabelColor());
    }
    content.addSubview(hintIcon);
    hintLabel = Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(L.margin + 18, topY(Y_HINT, 12), innerW - 18, 12), 'Klick = Vordergrund · ⌥+Klick = Hintergrund', {
      size: 10,
      color: NSColor.secondaryLabelColor()
    });
    content.addSubview(hintLabel);
  }
  var dismissHint = function dismissHint() {
    if (hintLabel && !hintLabel.isHidden()) {
      hintLabel.setHidden(true);
      hintIcon.setHidden(true);
    }
  };
  if (hasOver) {
    content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(L.margin, topY(Y_OVER_LABEL, 12), innerW, 12), "Overrides (".concat(collected.overrides.length, ")"), {
      size: 9,
      color: NSColor.secondaryLabelColor()
    }));
  }
  if (hasOthers) {
    content.addSubview(Object(_ui_controls__WEBPACK_IMPORTED_MODULE_1__["makeLabel"])(NSMakeRect(L.margin, topY(Y_OTHERS_LABEL, 12), innerW, 12), "Sonstige (".concat(collected.others.length, ")"), {
      size: 9,
      color: NSColor.secondaryLabelColor()
    }));
  }
  var buildRows = function buildRows() {
    if (hasOver) {
      var overFrame = NSMakeRect(L.margin, topY(Y_OVER_GRID, OVER_VP), innerW, OVER_VP);
      content.addSubview(makeChipGrid(overFrame, collected.overrides));
    }
    if (hasOthers) {
      var othersFrame = NSMakeRect(L.margin, topY(Y_OTHERS_LIST, LIST_VP), innerW, LIST_VP);
      content.addSubview(makeSwatchList(othersFrame, collected.others));
    }

    // Convenience: exactly two overrides → seed VG/HG directly (only while the pair
    // is still at defaults so a manual choice is never clobbered).
    if (collected.overrides.length === 2 && state.fgHex === '#000000FF' && state.bgHex === '#FFFFFFFF') {
      state.fgHex = collected.overrides[0].hex;
      state.bgHex = collected.overrides[1].hex;
      fgField.setStringValue(state.fgHex);
      bgField.setStringValue(state.bgHex);
      state.extraWarnings = [];
      render();
    }
  };

  // --- buttons (bottom row) ---
  var button = function button(x, w, title, fn) {
    var opts = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
    var b = NSButton.alloc().initWithFrame(NSMakeRect(x, 14, w, 28));
    b.setTitle(title);
    b.setBezelStyle(NSBezelStyleRounded);
    // Return-Kuerzel laesst AppKit den Button in der Akzentfarbe zeichnen.
    if (opts.isDefault) b.setKeyEquivalent(String.fromCharCode(13));
    b.setCOSJSTargetFunction(fn);
    content.addSubview(b);
    return b;
  };
  // Swatches themselves are the pipette trigger (no separate buttons): a
  // transparent button overlay makes each swatch clickable → opens the color
  // picker writing into that channel.
  var pipetteHint = function pipetteHint() {
    return sketch.UI.message('Pipette aktiv — Pixel anklicken.');
  };
  var pickInto = function pickInto(key, field) {
    return Object(_sampler__WEBPACK_IMPORTED_MODULE_3__["pickScreenColor"])(function (res, err) {
      if (res) {
        state[key] = res.hex;
        field.setStringValue(res.hex);
        render();
      } else if (err) sketch.UI.message('Kontrast: ' + err);
    });
  };
  var makeSwatchTrigger = function makeSwatchTrigger(sw, fn) {
    var overlay = NSButton.alloc().initWithFrame(sw.frame());
    overlay.setTransparent(true); // invisible but clickable
    overlay.setTitle('');
    overlay.setBordered(false);
    overlay.setToolTip('Klicken: Farbe pipettieren');
    overlay.setCOSJSTargetFunction(fn);
    content.addSubview(overlay);
    return overlay;
  };
  makeSwatchTrigger(swFg, function () {
    pipetteHint();
    pickInto('fgHex', fgField);
  });
  makeSwatchTrigger(swBg, function () {
    pipetteHint();
    pickInto('bgHex', bgField);
  });
  button(L.width - L.margin - 100, 100, 'Schließen', function () {
    panel.close();
    cleanupAndStop();
  }, {
    isDefault: true
  });
  function render() {
    var a = Object(_core__WEBPACK_IMPORTED_MODULE_2__["analyzePair"])(state.fgHex, state.bgHex, {
      largeText: state.largeText
    });
    swFg.layer().setBackgroundColor(cgFor(state.fgHex));
    swBg.layer().setBackgroundColor(cgFor(state.bgHex));
    if (!a) {
      state.ratioText = '';
      ratioLabel.setStringValue('—');
      layoutRatioCluster();
      [badgeNormalAA, badgeNormalAAA, badgeLargeAA, badgeLargeAAA, badgeNonTextMark].forEach(function (f) {
        return f.setStringValue('');
      });
      deltaValue.setStringValue('—');
      warnLabel.setStringValue('Ungültige Farbe (Hex prüfen)');
      return;
    }
    var w = a.wcag;
    state.ratioText = w.ratio.toFixed(2) + ':1';
    ratioLabel.setStringValue(state.ratioText);
    layoutRatioCluster();
    setMark(badgeNormalAA, w.normalAA);
    setMark(badgeNormalAAA, w.normalAAA);
    setMark(badgeLargeAA, w.largeAA);
    setMark(badgeLargeAAA, w.largeAAA);
    setMark(badgeNonTextMark, w.nonText);
    var dE = a.deltaE2000;
    var dDesc = dE < 1 ? 'kaum unterscheidbar' : dE < 2 ? 'gerade unterscheidbar' : dE < 10 ? 'deutlich verschieden' : 'stark verschieden';
    deltaValue.setStringValue("".concat(dE.toFixed(1), " \xB7 ").concat(dDesc));
    var warns = (state.extraWarnings || []).concat(a.warnings || []);
    warnLabel.setStringValue(warns.length ? '⚠ ' + warns.slice(0, 2).join('\n⚠ ') : '');
  }

  // hex fields re-render on edit
  var delegate = Object(_utils_mocha__WEBPACK_IMPORTED_MODULE_0__["MochaJSDelegate"])({
    'windowWillClose:': function windowWillClose() {
      return cleanupAndStop();
    },
    'controlTextDidEndEditing:': function controlTextDidEndEditing() {
      state.fgHex = String(fgField.stringValue());
      state.bgHex = String(bgField.stringValue());
      state.extraWarnings = []; // manual edit supersedes selection-derived notes
      render();
    }
  });
  panel.setDelegate_(delegate);
  fgField.setDelegate(delegate);
  bgField.setDelegate(delegate);
  threadDictionary[delegateKey] = delegate;
  threadDictionary[identifier] = panel;
  render();
  buildRows(); // populate the two swatch rows; seed VG/HG if exactly two overrides
  return panel;
}

/***/ }),

/***/ "./src/contrast/resolve.js":
/*!*********************************!*\
  !*** ./src/contrast/resolve.js ***!
  \*********************************/
/*! exports provided: layerColor, resolveFromSelection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layerColor", function() { return layerColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resolveFromSelection", function() { return resolveFromSelection; });
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core */ "./src/contrast/core.js");


/**
 * Sketch adapter: derive a foreground/background color pair from the current
 * selection. Pure-Sketch side (no contrast math here). v1 scope:
 *  - 1 layer  → fg = its color; bg = topmost overlapping sibling fill below it,
 *               else enclosing Artboard background.
 *  - 2 layers → front (higher z / smaller area) = fg, other = bg.
 *  - >2       → topmost two, with a warning.
 * Unsupported cases produce warnings instead of silent guesses.
 */


/** Representative color of a layer as #RRGGBBAA, or null. */
function layerColor(layer) {
  if (!layer) return null;
  try {
    if (layer.type === 'Text' && layer.style && layer.style.textColor) {
      return {
        hex: String(layer.style.textColor),
        source: 'text'
      };
    }
    var fills = layer.style && layer.style.fills || [];
    for (var i = fills.length - 1; i >= 0; i--) {
      var f = fills[i];
      if (f && f.enabled && f.fillType === 'Color' && f.color) return {
        hex: String(f.color),
        source: 'fill'
      };
    }
    var borders = layer.style && layer.style.borders || [];
    for (var _i = borders.length - 1; _i >= 0; _i--) {
      var b = borders[_i];
      if (b && b.enabled && b.color) return {
        hex: String(b.color),
        source: 'border'
      };
    }
  } catch (e) {}
  return null;
}
function textIsLarge(layer) {
  try {
    if (!layer || layer.type !== 'Text' || !layer.style) return false;
    var size = layer.style.fontSize;
    var bold = false;
    var w = layer.style.fontWeight;
    if (typeof w === 'number') bold = w >= 9; // Sketch weight scale (~0..12)
    var fam = String(layer.style.fontFamily || layer.style.fontName || '');
    if (/bold|black|heavy|semibold/i.test(fam)) bold = true;
    return Object(_core__WEBPACK_IMPORTED_MODULE_0__["isLargeText"])(typeof size === 'number' ? size : null, bold);
  } catch (e) {
    return false;
  }
}
function area(layer) {
  try {
    var f = layer.frame;
    return f ? f.width * f.height : Infinity;
  } catch (e) {
    return Infinity;
  }
}

/** Index of a layer within its parent's layers (by id), or -1. */
function zIndex(layer) {
  try {
    var siblings = layer.parent && layer.parent.layers;
    if (!siblings) return -1;
    for (var i = 0; i < siblings.length; i++) if (siblings[i].id === layer.id) return i;
  } catch (e) {}
  return -1;
}

/** Enclosing Artboard/SymbolMaster background color, or null. */
function enclosingBackground(layer) {
  try {
    var p = layer.parent;
    var guard = 0;
    while (p && guard++ < 40) {
      if ((p.type === 'Artboard' || p.type === 'SymbolMaster') && p.background) {
        if (p.background.enabled && p.background.color) {
          return {
            hex: String(p.background.color),
            source: 'artboard'
          };
        }
        return null; // background present but disabled → transparent
      }
      p = p.parent;
    }
  } catch (e) {}
  return null;
}

/** Topmost sibling drawn below `layer` whose frame contains its center and has a fill. */
function backgroundUnder(layer) {
  try {
    var siblings = layer.parent && layer.parent.layers || [];
    var myZ = zIndex(layer);
    var f = layer.frame;
    if (!f) return null;
    var cx = f.x + f.width / 2;
    var cy = f.y + f.height / 2;
    for (var i = myZ - 1; i >= 0; i--) {
      var s = siblings[i];
      var sf = s && s.frame;
      if (!sf) continue;
      var contains = cx >= sf.x && cx <= sf.x + sf.width && cy >= sf.y && cy <= sf.y + sf.height;
      if (!contains) continue;
      var col = layerColor(s);
      if (col) return {
        hex: col.hex,
        source: 'fill'
      };
    }
  } catch (e) {}
  return null;
}

/**
 * @returns {null | { fg, bg, largeText, warnings, fgName, bgName }}
 *          fg/bg = { hex, source }. null when selection yields nothing usable.
 */
function resolveFromSelection(document) {
  var warnings = [];
  var layers = [];
  try {
    layers = document.selectedLayers && document.selectedLayers.layers || [];
  } catch (e) {
    layers = [];
  }
  if (!layers.length) return null;

  // Single layer → fg + inferred background.
  if (layers.length === 1) {
    var L = layers[0];
    var _fg = layerColor(L);
    if (!_fg) {
      warnings.push('Ausgewähltes Layer hat keine lesbare Farbe — Pipette/Hex nutzen.');
      return {
        fg: null,
        bg: null,
        largeText: false,
        warnings: warnings,
        fgName: L.name,
        bgName: null
      };
    }
    var _bg = backgroundUnder(L) || enclosingBackground(L);
    if (!_bg) warnings.push('Kein Hintergrund unter dem Layer gefunden — Pipette nutzen oder HG manuell setzen.');
    return {
      fg: _fg,
      bg: _bg,
      largeText: textIsLarge(L),
      warnings: warnings,
      fgName: L.name,
      bgName: _bg ? '(Hintergrund)' : null
    };
  }

  // Two (or more) layers → front = fg.
  if (layers.length > 2) warnings.push("".concat(layers.length, " Layer ausgew\xE4hlt \u2014 die obersten zwei werden verglichen."));
  var sorted = layers.slice().sort(function (a, b) {
    var za = zIndex(a);
    var zb = zIndex(b);
    if (za !== zb && za >= 0 && zb >= 0) return zb - za; // higher z first (front)
    return area(a) - area(b); // tiebreak: smaller = foreground
  });
  var front = sorted[0];
  var back = sorted[1];
  var fg = layerColor(front);
  var bg = layerColor(back);
  if (!fg) warnings.push("Vordergrund-Layer \"".concat(front.name, "\" hat keine lesbare Farbe."));
  if (!bg) warnings.push("Hintergrund-Layer \"".concat(back.name, "\" hat keine lesbare Farbe."));
  return {
    fg: fg,
    bg: bg,
    largeText: textIsLarge(front),
    warnings: warnings,
    fgName: front.name,
    bgName: back.name
  };
}

/***/ }),

/***/ "./src/contrast/sampler.js":
/*!*********************************!*\
  !*** ./src/contrast/sampler.js ***!
  \*********************************/
/*! exports provided: pickScreenColor, stopScreenColor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pickScreenColor", function() { return pickScreenColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stopScreenColor", function() { return stopScreenColor; });
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core */ "./src/contrast/core.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! util */ "util");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_mocha__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/mocha */ "./src/utils/mocha.js");


/**
 * One-click screen eyedropper — block-free.
 *
 * NSColorSampler's native loupe has a block-only API (showSamplerWithSelectionHandler:)
 * that Sketch's CocoaScript/Mocha bridge cannot call (JS→Obj-C block bridging throws).
 * Workaround: drive the shared NSColorPanel, whose magnifier is a plain NSButton
 * (action `_magnify:`, accessibilityLabel "pick color"). We:
 *   1. wire the panel's color via target/action (changeColor:) — selector-based, Mocha-OK
 *   2. open the panel OFFSCREEN (so only the loupe shows, not the whole picker)
 *   3. performClick the magnifier button → the system loupe starts immediately
 *   4. the first changeColor: after that IS the sampled pixel → deliver once, close
 *
 * callback(result, errorMessage): result = { rgb:{r,g,b,a}, hex }.
 */


var TARGET_KEY = 'net.notbot.toolboxx.contrast.colorTarget';
var OFFSCREEN = NSMakePoint(-20000, -20000);
function safe(fn) {
  try {
    return fn();
  } catch (e) {
    return null;
  }
}
function describe(e) {
  var parts = [];
  try {
    parts.push(String(e));
  } catch (x) {}
  try {
    if (e && e.reason) parts.push('reason=' + e.reason());
  } catch (x) {}
  return parts.filter(Boolean).join(' | ');
}

function readSRGB(nsColor) {
  var c = nsColor && nsColor.colorUsingColorSpace(NSColorSpace.sRGBColorSpace());
  if (!c) return null; // pattern / unsupported color space
  var rgb = {
    r: Math.round(c.redComponent() * 255),
    g: Math.round(c.greenComponent() * 255),
    b: Math.round(c.blueComponent() * 255),
    a: c.alphaComponent()
  };
  return {
    rgb: rgb,
    hex: Object(_core__WEBPACK_IMPORTED_MODULE_0__["toHex8"])(rgb)
  };
}

// --- locate the magnifier button in the panel's view tree ---------------------

function collectButtons(view, out) {
  var subs = safe(function () {
    return Object(util__WEBPACK_IMPORTED_MODULE_1__["toArray"])(view.subviews());
  }) || [];
  subs.forEach(function (v) {
    var isBtn = safe(function () {
      return v.isKindOfClass(NSButton);
    });
    if (isBtn) out.push(v);
    collectButtons(v, out);
  });
}

/** The magnifier: action selector `_magnify:` (primary) or a11y label "pick color". */
function findLoupeButton(panel) {
  var btns = [];
  collectButtons(panel.contentView(), btns);
  return btns.find(function (b) {
    var action = safe(function () {
      return String(NSStringFromSelector(b.action()));
    }) || '';
    var a11y = safe(function () {
      return String(b.accessibilityLabel());
    }) || '';
    return action === '_magnify:' || /pick color/i.test(a11y);
  }) || null;
}
function pickScreenColor(callback) {
  try {
    var panel = NSColorPanel.sharedColorPanel();
    panel.setShowsAlpha(true);
    var armed = false; // true once the loupe is triggered
    var done = false; // one-shot guard

    var target = Object(_utils_mocha__WEBPACK_IMPORTED_MODULE_2__["MochaJSDelegate"])({
      'changeColor:': function changeColor() {
        if (!armed || done) return; // ignore initial/stray changes until the loupe fires
        done = true;
        var res = safe(function () {
          return readSRGB(NSColorPanel.sharedColorPanel().color());
        });
        stopScreenColor(); // detach + hide immediately after the pick
        if (res) callback(res);
      }
    });
    var td = NSThread.mainThread().threadDictionary();
    td[TARGET_KEY] = target;
    panel.setTarget(target);
    panel.setAction(NSSelectorFromString('changeColor:'));
    var loupe = findLoupeButton(panel);
    if (loupe) {
      // open offscreen so only the system loupe is visible, then auto-trigger it
      panel.setFrameOrigin(OFFSCREEN);
      panel.orderFront(null);
      armed = true;
      safe(function () {
        return loupe.performClick(null);
      });
    } else {
      // fallback: no magnifier found → show the picker; first change is the result
      console.log('[contrast] Lupe-Button nicht gefunden — Farbdialog manuell.');
      panel.center();
      panel.setLevel(NSFloatingWindowLevel);
      panel.makeKeyAndOrderFront(null);
      armed = true;
    }
  } catch (e) {
    console.log('[contrast] NSColorPanel-Pipette fehlgeschlagen: ' + describe(e));
    callback(null, 'Pipette (Farbdialog) fehlgeschlagen: ' + describe(e));
  }
}

/** Detach our target/action and hide the shared color panel. Safe to call twice. */
function stopScreenColor() {
  try {
    var panel = NSColorPanel.sharedColorPanel();
    panel.setTarget(null);
    panel.setAction(null);
    panel.orderOut(null);
  } catch (e) {}
  try {
    NSThread.mainThread().threadDictionary().removeObjectForKey(TARGET_KEY);
  } catch (e) {}
}

/***/ }),

/***/ "./src/ui/controls.js":
/*!****************************!*\
  !*** ./src/ui/controls.js ***!
  \****************************/
/*! exports provided: makeLabel, makeField, copyToClipboard, makeSwatch, makeCheckbox, makeRadioGroup, applyPanelChrome, addEscapeHatch, makeDefaultButton */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeLabel", function() { return makeLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeField", function() { return makeField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "copyToClipboard", function() { return copyToClipboard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeSwatch", function() { return makeSwatch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeCheckbox", function() { return makeCheckbox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeRadioGroup", function() { return makeRadioGroup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyPanelChrome", function() { return applyPanelChrome; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addEscapeHatch", function() { return addEscapeHatch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeDefaultButton", function() { return makeDefaultButton; });


/**
 * Shared native AppKit control builders (used by contrast & anonymize panels).
 * Bottom-left origin; system font / labelColor → auto light/dark.
 */
function makeLabel(frame, text) {
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var f = NSTextField.alloc().initWithFrame(frame);
  f.setEditable(false);
  f.setBordered(false);
  f.setBezeled(false);
  f.setDrawsBackground(false);
  f.setSelectable(opts.selectable || false);
  var size = opts.size || 12;
  // weight: 'medium' → the middle ground between regular and bold
  if (opts.weight === 'medium' && NSFont.systemFontOfSize_weight) {
    // NSFontWeightMedium = 0.23
    f.setFont(NSFont.systemFontOfSize_weight(size, 0.23));
  } else {
    f.setFont(opts.bold ? NSFont.boldSystemFontOfSize(size) : NSFont.systemFontOfSize(size));
  }
  if (opts.align === 'center') f.setAlignment(NSTextAlignmentCenter);else if (opts.align === 'right') f.setAlignment(NSTextAlignmentRight);
  if (opts.color) f.setTextColor(opts.color);
  f.setStringValue(text || '');
  return f;
}
function makeField(frame, text) {
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var f = NSTextField.alloc().initWithFrame(frame);
  f.setEditable(true);
  f.setBezeled(true);
  f.setBezelStyle(NSTextFieldRoundedBezel);
  f.setFont(NSFont.systemFontOfSize(11));
  if (opts.align === 'center') f.setAlignment(NSTextAlignmentCenter);
  f.setStringValue(text || '');
  return f;
}

// NOTE: no custom-subclassed views with JS-backed methods here (e.g. a flipped
// NSView whose isFlipped is a JS function). The render loop calls such methods
// outside our control and a stale Mocha block crashes Sketch over time. Lay out
// top-down with plain NSViews + inverted coordinates instead.

/** Copy a string to the general pasteboard. Returns true on success. */
function copyToClipboard(str) {
  try {
    var pb = NSPasteboard.generalPasteboard();
    pb.clearContents();
    pb.setString_forType_(String(str == null ? '' : str), NSPasteboardTypeString);
    return true;
  } catch (e) {
    return false;
  }
}
function makeSwatch(frame) {
  var v = NSView.alloc().initWithFrame(frame);
  v.setWantsLayer(true);
  v.layer().setCornerRadius(6);
  v.layer().setBorderWidth(1);
  v.layer().setBorderColor(NSColor.separatorColor().CGColor());
  return v;
}
function makeCheckbox(frame, title, checked) {
  var b = NSButton.alloc().initWithFrame(frame);
  b.setButtonType(NSButtonTypeSwitch);
  b.setTitle(title);
  b.setState(checked ? NSOnState : NSOffState);
  return b;
}

/**
 * Mutually-exclusive radio group. options: [{label, value}].
 * IMPORTANT: each group gets its OWN enclosing NSView — Cocoa groups
 * NSButtonTypeRadio buttons by superview, so groups sharing one superview would
 * act as a single group. The first option sits at parent-y `top`.
 * @returns { get(), set(value), view }
 */
function makeRadioGroup(parent, options, layout, onChange) {
  var x = layout.x,
    top = layout.top,
    rowH = layout.rowH,
    width = layout.width;
  var n = options.length;
  var height = n * rowH;
  var group = NSView.alloc().initWithFrame(NSMakeRect(x, top - (n - 1) * rowH, width, height));
  parent.addSubview(group);
  var buttons = [];
  var selected = options[0] && options[0].value;
  options.forEach(function (opt, idx) {
    var ly = height - (idx + 1) * rowH; // local y; option 0 at top
    var b = NSButton.alloc().initWithFrame(NSMakeRect(0, ly, width, rowH - 2));
    b.setButtonType(NSButtonTypeRadio);
    b.setTitle(opt.label);
    b.setState(idx === 0 ? NSOnState : NSOffState);
    b.setCOSJSTargetFunction(function () {
      selected = opt.value; // native radio handles visual exclusivity within this group
      if (onChange) onChange(opt.value);
    });
    group.addSubview(b);
    buttons.push(b);
  });
  return {
    get: function get() {
      return selected;
    },
    set: function set(v) {
      var i = options.findIndex(function (o) {
        return o.value === v;
      });
      if (i >= 0) {
        buttons[i].setState(NSOnState);
        selected = v;
      }
    },
    view: group
  };
}

// ---------------------------------------------------------------------------
// Panel-Grundausstattung — zentral, damit die Werkzeuge gleich aussehen.
// Eingeführt 260909, als der smartSelect-Umbau zeigte, dass jedes Panel diese
// Dinge einzeln nachbaute, oder eben gar nicht hatte.
// ---------------------------------------------------------------------------

/**
 * Gibt einem Panel den Material-Untergrund und eine zurückhaltende Titelleiste.
 *
 * NSVisualEffectView ist eine System-View ohne JS-implementierte Methoden; das
 * Verbot aus sketch-plugin-gotchas §1 betrifft nur eigene Subklassen mit
 * JS-backed render/layout/hitTest. Jeder Schritt ist einzeln abgesichert: eine
 * fehlende API darf niemals das Panel kosten.
 */
function applyPanelChrome(panel, log) {
  var note = function note(msg) {
    if (log) log(msg);
  };
  try {
    panel.setTitlebarAppearsTransparent(true);
    if (typeof NSWindowTitleHidden !== 'undefined') {
      panel.setTitleVisibility(NSWindowTitleHidden);
    }
  } catch (e) {
    note("Titelleisten-Stil nicht setzbar: ".concat(e));
  }
  try {
    var content = panel.contentView();
    var effect = NSVisualEffectView.alloc().initWithFrame(content.bounds());
    effect.setAutoresizingMask(18); // width | height
    if (typeof NSVisualEffectBlendingModeBehindWindow !== 'undefined') {
      effect.setBlendingMode(NSVisualEffectBlendingModeBehindWindow);
    }
    if (typeof NSVisualEffectStateActive !== 'undefined') {
      effect.setState(NSVisualEffectStateActive);
    }
    if (effect.setMaterial && typeof NSVisualEffectMaterialSidebar !== 'undefined') {
      effect.setMaterial(NSVisualEffectMaterialSidebar);
    }
    content.addSubview_positioned_relativeTo(effect, -1, null); // NSWindowBelow
  } catch (e) {
    note("NSVisualEffectView nicht verf\xFCgbar, bleibe bei windowBackgroundColor: ".concat(e));
  }
}

/**
 * Notausgang für ein bereits sichtbares Panel.
 *
 * Wirft der Inhaltsaufbau nach makeKeyAndOrderFront, aber bevor die Buttons und
 * der Delegate hängen, bleibt sonst ein Fenster ohne Schließweg stehen — real
 * passiert am 260909, wegzubekommen nur über einen eigens gebauten Command.
 * Direkt nach dem Sichtbarmachen aufrufen, vor jedem Inhalt.
 */
function addEscapeHatch(panel, log) {
  var ESC = String.fromCharCode(27);
  try {
    panel.setStyleMask(panel.styleMask() | NSWindowStyleMaskClosable);
    var btn = NSButton.alloc().initWithFrame(NSMakeRect(-100, -100, 1, 1));
    btn.setTitle('');
    btn.setKeyEquivalent(ESC);
    btn.setAction('callAction:');
    btn.setCOSJSTargetFunction(function () {
      try {
        panel.orderOut(null);
      } catch (e) {
        if (log) log("Notausgang orderOut: ".concat(e));
      }
      try {
        panel.close();
      } catch (e) {
        if (log) log("Notausgang close: ".concat(e));
      }
    });
    panel.contentView().addSubview(btn);
    return btn;
  } catch (e) {
    if (log) log("Notausgang nicht setzbar \u2014 Panel waere bei einem Fehler im Aufbau nicht schliessbar: ".concat(e));
    return null;
  }
}

/**
 * Bestätigender Button: Return-Kürzel, damit AppKit ihn in der Akzentfarbe
 * zeichnet. Ohne das wirkt jedes Panel wie ein Dialog von 2001 — im ganzen
 * Repo war vor 260909 kein einziger Default-Button gesetzt.
 */
function makeDefaultButton(frame, title, fn) {
  var b = NSButton.alloc().initWithFrame(frame);
  b.setTitle(title);
  b.setBezelStyle(NSBezelStyleRounded);
  b.setKeyEquivalent(String.fromCharCode(13)); // Return
  if (fn) b.setCOSJSTargetFunction(fn);
  return b;
}

/***/ }),

/***/ "./src/utils/mocha.js":
/*!****************************!*\
  !*** ./src/utils/mocha.js ***!
  \****************************/
/*! exports provided: MochaJSDelegate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MochaJSDelegate", function() { return MochaJSDelegate; });


/**
 * Create an NSObject delegate whose selectors are backed by JS functions.
 * Shared helper — avoids re-inlining MochaJSDelegate per command.
 * Existing inline copies (inspectSymbolOrigin.js etc.) can migrate to this later.
 */
function MochaJSDelegate(selectorHandlerDict) {
  var uniqueClassName = 'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString();
  var desc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, NSObject);
  desc.registerClass();
  Object.keys(selectorHandlerDict).forEach(function (selectorString) {
    desc.addInstanceMethodWithSelector_function_(NSSelectorFromString(selectorString), selectorHandlerDict[selectorString]);
  });
  return NSClassFromString(uniqueClassName).new();
}

/***/ }),

/***/ "./src/utils/swatchResolve.js":
/*!************************************!*\
  !*** ./src/utils/swatchResolve.js ***!
  \************************************/
/*! exports provided: rgbaToHex8, resolveNativeColor, resolveColorObject, displayName, pickSwatchCandidate, applySwatchToNativeColor, hex8ToRGBA */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rgbaToHex8", function() { return rgbaToHex8; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resolveNativeColor", function() { return resolveNativeColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resolveColorObject", function() { return resolveColorObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "displayName", function() { return displayName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pickSwatchCandidate", function() { return pickSwatchCandidate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applySwatchToNativeColor", function() { return applySwatchToNativeColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hex8ToRGBA", function() { return hex8ToRGBA; });
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js");
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! util */ "util");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_2__);


/**
 * ID-based swatch (color variable) resolution — SHARED across tools.
 *
 * WHY THIS EXISTS
 * A color that references a Sketch swatch (color variable) must be named via its
 * swatch REFERENCE, never by its RGBA value. Value→name is ambiguous (two swatches
 * can share a value) and is explicitly disallowed here. In real documents ~90% of
 * swatches come from an external Library; those appear locally as `foreignSwatches`
 * whose `localSwatch()` carries the real name + `sourceLibraryName()`.
 *
 * RESOLUTION PATH (all by identity, no color compare):
 *   MSColor.swatchID()  →  documentData.swatchWithID(id)  →  the swatch object
 *   swatch object identity matched against documentData.foreignSwatches()[].localSwatch()
 *   → if matched: imported, libraryName = foreignSwatch.sourceLibraryName()
 *   → else: local swatch
 *
 * Ported/centralized from smartSelect.js (swatchForMSColor / resolveOverrideColor).
 * Other tools (smartSelect, equalize, contrast, …) should consume THIS module
 * rather than re-implementing the lookup.
 *
 * Return shape for every entry point:
 *   { hex, rgba:{r,g,b,a}, swatchID, name, isImported, libraryName }
 *   — swatchID/name/libraryName are null when the color references no swatch.
 */


function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }


// --- native access helpers (CocoaScript props may be functions OR values) ----

// Read a CocoaScript property/method. Mocha's bound methods report typeof
// 'function' but do NOT support Function.prototype.call — invoke them directly
// as obj.name() (the proven smartSelect pattern).
function call(obj, name) {
  if (!obj) return null;
  try {
    var v = obj[name];
    return typeof v === 'function' ? obj[name]() : v;
  } catch (e) {
    return null;
  }
}
function getNativeDocumentData(nativeObj) {
  try {
    if (!nativeObj) return null;
    return call(nativeObj, 'documentData') || null;
  } catch (e) {
    return null;
  }
}
function nativeObjectIDString(nativeObj) {
  try {
    if (!nativeObj) return null;
    var v = call(nativeObj, 'objectID');
    return v == null ? null : String(v);
  } catch (e) {
    return null;
  }
}

// --- color math --------------------------------------------------------------

/** MSColor / MSImmutableColor → {r,g,b,a} in 0..1. */
function msColorToRGBA(c) {
  return {
    r: Number(call(c, 'red')) || 0,
    g: Number(call(c, 'green')) || 0,
    b: Number(call(c, 'blue')) || 0,
    a: call(c, 'alpha') == null ? 1 : Number(call(c, 'alpha'))
  };
}

/** {r,g,b,a} 0..1 → #RRGGBBAA (uppercase). */
function rgbaToHex8(rgba) {
  var h = function h(v) {
    var n = Math.max(0, Math.min(255, Math.round((v || 0) * 255)));
    return n.toString(16).toUpperCase().padStart(2, '0');
  };
  return '#' + h(rgba.r) + h(rgba.g) + h(rgba.b) + h(rgba.a == null ? 1 : rgba.a);
}

// --- swatch identity ---------------------------------------------------------

/**
 * Describe a native swatch object by IDENTITY against the document's foreign
 * (library) swatches. Returns { name, isImported, libraryName }.
 */
function describeSwatch(nativeSwatch, docData) {
  var name = String(call(nativeSwatch, 'name') || '');
  var targetId = nativeObjectIDString(nativeSwatch);
  try {
    var foreign = Object(util__WEBPACK_IMPORTED_MODULE_2__["toArray"])(call(docData, 'foreignSwatches')) || [];
    var fref = foreign.find(function (fs) {
      try {
        return nativeObjectIDString(call(fs, 'localSwatch')) === targetId;
      } catch (e) {
        return false;
      }
    });
    if (fref) {
      return {
        name: name,
        isImported: true,
        libraryName: String(call(fref, 'sourceLibraryName') || '')
      };
    }
  } catch (e) {}
  return {
    name: name,
    isImported: false,
    libraryName: null
  };
}

/**
 * Core lookup: swatchID (+ documentData) → { name, isImported, libraryName } | null.
 * `swatchWithID` resolves both local swatches and the local instances of library
 * (foreign) swatches; describeSwatch then classifies local vs. imported.
 */
function resolveSwatchByID(swatchID, docData) {
  if (!swatchID || !docData) return null;
  try {
    var nativeSwatch = typeof docData.swatchWithID === 'function' ? docData.swatchWithID(swatchID) : null;
    if (!nativeSwatch) return null;
    return describeSwatch(nativeSwatch, docData);
  } catch (e) {
    return null;
  }
}
var EMPTY_SWATCH = {
  swatchID: null,
  name: null,
  isImported: false,
  libraryName: null
};

// --- public entry points -----------------------------------------------------

/**
 * Resolve a native MSColor / MSImmutableColor.
 * @param nativeColor a Sketch native color (has red()/green()/blue()/alpha(), swatchID())
 * @param docDataOverride optional documentData if the color can't provide its own
 */
function resolveNativeColor(nativeColor, docDataOverride) {
  if (!nativeColor) return null;
  var rgba = msColorToRGBA(nativeColor);
  var base = _objectSpread({
    hex: rgbaToHex8(rgba),
    rgba: rgba
  }, EMPTY_SWATCH);
  var swatchID = null;
  try {
    swatchID = call(nativeColor, 'swatchID');
  } catch (e) {}
  if (!swatchID) return base;
  var docData = docDataOverride || getNativeDocumentData(nativeColor);
  var s = resolveSwatchByID(swatchID, docData);
  return s ? _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(swatchID)
  }, s) : _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(swatchID)
  });
}

/**
 * Resolve a plain override color object { _class:'color', red,green,blue,alpha, swatchID? }.
 * @param docData the document's documentData (required for swatch naming)
 */
function resolveColorObject(colorObj, docData) {
  if (!colorObj || _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default()(colorObj) !== 'object') return null;
  var rgba = {
    r: Number(colorObj.red) || 0,
    g: Number(colorObj.green) || 0,
    b: Number(colorObj.blue) || 0,
    a: colorObj.alpha == null ? 1 : Number(colorObj.alpha)
  };
  var base = _objectSpread({
    hex: rgbaToHex8(rgba),
    rgba: rgba
  }, EMPTY_SWATCH);
  if (!colorObj.swatchID) return base;
  var s = resolveSwatchByID(colorObj.swatchID, docData);
  return s ? _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(colorObj.swatchID)
  }, s) : _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(colorObj.swatchID)
  });
}

/** A short display label: swatch name if present, else the hex value. */
function displayName(resolved) {
  if (!resolved) return '';
  if (resolved.name) return resolved.name;
  return resolved.hex;
}

// --- name lookup: which candidate wins? --------------------------------------

/**
 * Pick one swatch among same-named candidates — PURE, no native objects.
 *
 * WHY THIS IS ITS OWN FUNCTION
 * Duplicate swatch names are the normal case, not an edge case: in the reference
 * document ALL six configured names exist in both libraries, `grau-04` locally
 * on top of that (measured 260909, see docs/review/swap-tools-review.md §7).
 * Picking `candidates[0]` therefore picked at random. Callers pass plain
 * descriptors so this rule stays unit-testable outside Sketch.
 *
 * @param candidates [{ name, isImported, libraryName, ref }] — `ref` is opaque
 * @param opts.requiredLibrary  null = the winner must be LOCAL; a name = it must
 *                              come from exactly that library (same-library rule)
 * @param opts.libraryPriority  ordered library names; earliest listed wins
 * @returns the winning candidate, or null when none qualifies
 */
function pickSwatchCandidate(candidates) {
  var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var list = Array.isArray(candidates) ? candidates.filter(Boolean) : [];
  if (!list.length) return null;
  var required = opts.requiredLibrary || null;
  var priority = Array.isArray(opts.libraryPriority) ? opts.libraryPriority : [];

  // Same-library rule: an imported colour is replaced from the SAME library,
  // a local one stays local. Mixed provenance within one selection is expected
  // (testcase 2), so this is decided per colour and never globally.
  var eligible = list.filter(function (c) {
    var lib = c && c.isImported ? c.libraryName || null : null;
    return required ? lib === required : !lib;
  });
  if (!eligible.length) return null;
  if (eligible.length === 1) return eligible[0];

  // Still ambiguous → the owner's ranking decides (260909).
  var _iterator = _createForOfIteratorHelper(priority),
    _step;
  try {
    var _loop = function _loop() {
        var wanted = _step.value;
        var hit = eligible.find(function (c) {
          return (c.libraryName || null) === wanted;
        });
        if (hit) return {
          v: hit
        };
      },
      _ret;
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      _ret = _loop();
      if (_ret) return _ret.v;
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return eligible[0];
}

/**
 * Link a native MSColor to a swatch — the WRITE counterpart to resolveNativeColor.
 *
 * Setting the swatchID keeps the colour a REFERENCE; writing raw RGBA would
 * detach it from its library and silently turn a colour variable into a literal.
 * The RGBA path is therefore a last resort, and it is reported by the return
 * value so callers can tell a real relink from a mere value copy.
 *
 * @param nativeColor MSColor (mutable — an MSImmutableColor cannot be written)
 * @param swatch      DOM swatch or native swatch object
 * @returns { ok, mode } — mode: 'swatchID' | 'rgba' | null
 */
function applySwatchToNativeColor(nativeColor, swatch) {
  if (!nativeColor || !swatch) return {
    ok: false,
    mode: null
  };
  var nativeSwatch = swatch.sketchObject || swatch;
  var swatchID = swatch.id || nativeObjectIDString(nativeSwatch);

  // setSwatchID allein setzt nur die VERKNUEPFUNG, nicht die Farbwerte: Die
  // Ebene zeigt danach auf den richtigen Swatch und sieht trotzdem aus wie
  // vorher (Owner-Befund 260910 — "die markierung steht auf der korrekten
  // nachtfarbe, aber die darstellung ist falsch, erst beim zweiten klick wird
  // sie uebernommen").
  //
  // Deshalb werden BEIDE gesetzt: erst die Werte des Ziel-Swatches, dann die
  // Verknuepfung. Reihenfolge ist wesentlich — ein Schreiben der Werte NACH
  // dem Setzen der ID kann die Bindung wieder loesen.
  if (swatchID && typeof nativeColor.setSwatchID === 'function') {
    try {
      var src = call(nativeSwatch, 'color');
      var rgba = src ? msColorToRGBA(src) : null;
      if (rgba && typeof nativeColor.setRed_green_blue_alpha === 'function') {
        nativeColor.setRed_green_blue_alpha(rgba.r, rgba.g, rgba.b, rgba.a);
      } else if (!rgba) {
        console.log("Farbwerte des Swatches \"".concat(call(nativeSwatch, 'name'), "\" nicht lesbar \u2014 setze nur die Verknuepfung"));
      }
      nativeColor.setSwatchID(swatchID);
      return {
        ok: true,
        mode: 'swatchID'
      };
    } catch (e) {
      console.log("Swatch-Verknuepfung nicht setzbar (ID ".concat(swatchID, "): ").concat(e));
    }
  }

  // Fallback: copy the value. The colour loses its swatch link — callers that
  // care must treat mode 'rgba' as "not properly relinked".
  var value = call(nativeSwatch, 'color') || (typeof swatch.color === 'string' ? swatch.color : null);
  if (value && typeof nativeColor.setRed_green_blue_alpha === 'function') {
    try {
      var _rgba = typeof value === 'string' ? hex8ToRGBA(value) : msColorToRGBA(value);
      if (_rgba) {
        nativeColor.setRed_green_blue_alpha(_rgba.r, _rgba.g, _rgba.b, _rgba.a);
        return {
          ok: true,
          mode: 'rgba'
        };
      }
      console.log("Farbwert des Swatches nicht lesbar: ".concat(String(value)));
    } catch (e) {
      console.log("Farbwert nicht auf die Farbe anwendbar: ".concat(e));
    }
  }
  console.log("Swatch liess sich weder verknuepfen noch als Wert setzen (swatchID=".concat(swatchID || '-', ")"));
  return {
    ok: false,
    mode: null
  };
}

/** '#RRGGBB' / '#RRGGBBAA' → {r,g,b,a} in 0..1, or null when unparseable. */
function hex8ToRGBA(hex) {
  var m = String(hex || '').match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i);
  if (!m) return null;
  return {
    r: parseInt(m[1], 16) / 255,
    g: parseInt(m[2], 16) / 255,
    b: parseInt(m[3], 16) / 255,
    a: m[4] ? parseInt(m[4], 16) / 255 : 1
  };
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=contrast.js.map