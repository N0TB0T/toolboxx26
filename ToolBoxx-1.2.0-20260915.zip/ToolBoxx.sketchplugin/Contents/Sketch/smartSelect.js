var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/smartSelect.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");
function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return arrayLikeToArray(r);
}
module.exports = _arrayWithoutHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var toPropertyKey = __webpack_require__(/*! ./toPropertyKey.js */ "./node_modules/@babel/runtime/helpers/toPropertyKey.js");
function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}
module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(r) {
  if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
module.exports = _iterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
module.exports = _nonIterableSpread, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles.js */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");
var iterableToArray = __webpack_require__(/*! ./iterableToArray.js */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");
var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");
var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread.js */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");
function _toConsumableArray(r) {
  return arrayWithoutHoles(r) || iterableToArray(r) || unsupportedIterableToArray(r) || nonIterableSpread();
}
module.exports = _toConsumableArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toPrimitive.js":
/*!************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toPrimitive.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/typeof.js")["default"];
function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toPropertyKey.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toPropertyKey.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/typeof.js")["default"];
var toPrimitive = __webpack_require__(/*! ./toPrimitive.js */ "./node_modules/@babel/runtime/helpers/toPrimitive.js");
function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(o) {
  "@babel/helpers - typeof";

  return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
}
module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? arrayLikeToArray(r, a) : void 0;
  }
}
module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./src/config/smartSelectConfig.js":
/*!*****************************************!*\
  !*** ./src/config/smartSelectConfig.js ***!
  \*****************************************/
/*! exports provided: smartSelectConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smartSelectConfig", function() { return smartSelectConfig; });
/**
 * Configuration for smartSelect Plugin
 * Central place for all UI dimensions, positions and styling constants
 */

var smartSelectConfig = {
  // Panel dimensions
  panel: {
    width: 1000,
    height: 650,
    minWidth: 900,
    minHeight: 450
  },
  // Radio buttons (Artboard/Document scope selector)
  // Vertikales Raster des Panels (Ursprung unten links, Hoehe 650):
  //   590 Radios · 552 Suche · 520 Ueberschriften · 492 Inhalt
  // Wer hier etwas verschiebt, verschiebt es fuer alle Elemente einer Zeile.
  rows: {
    controls: 574,
    // + 20 hoch = 594, unter der Titelleiste (Panel 650)
    search: 536,
    headings: 504,
    content: 476
  },
  radioButtons: {
    x: 32,
    y: 574,
    width: 200,
    height: 20,
    cellWidth: 100,
    cellHeight: 20,
    spacing: 10
  },
  // Checkboxes - Layer Properties (left column)
  layerProps: {
    width: 20,
    height: 20,
    startY: 476,
    rowHeight: 28,
    baseX: 32,
    indentWidth: 20,
    labelWidth: 360,
    labelSpacing: 6,
    labelOffsetY: -2,
    // vertical offset of label relative to its checkbox
    sectionTitle: {
      x: 32,
      // 15pt semibold gegen 12pt Fliesstext: eine erkennbare Hierarchie
      // statt eines Punktes Unterschied.
      fontSize: 15,
      fontWeight: true // bold
    }
  },
  // Checkboxes - Style Properties (right column)
  checkbox: {
    width: 20,
    height: 28,
    startY: 476,
    // Starting Y position for first checkbox
    rowHeight: 30,
    // Base row height; dynamic rows can exceed this
    baseX: 490,
    // Slightly further left
    indentWidth: 20,
    // Indentation for hierarchy levels
    labelWidth: 420,
    labelSpacing: 6,
    // Spacing between checkbox and label
    lineHeight: 18,
    // per text line
    rowGap: 6,
    // vertical gap between rows
    labelOffsetY: -6 // vertical offset of label relative to its checkbox
  },
  // Match mode radio buttons (for name/text matching)
  matchMode: {
    width: 18,
    height: 18,
    spacing: 10,
    // ~+5 px vs original 5
    labelWidth: 80,
    modes: ['Exact', 'Substring', 'Regex']
  },
  // Color swatches
  searchField: {
    height: 22,
    width: 340
  },
  swatch: {
    // Auf Checkbox-Masze: ein Farbfeld ist ein gleichrangiges Element in der
    // Zeile, kein Anhaengsel. Hoehe/Breite folgen checkbox.width.
    width: 14,
    height: 14,
    cornerRadius: 3,
    spacing: 6,
    // Spacing from checkbox
    offsetY: 0,
    // wird zur Laufzeit auf die Checkbox zentriert
    borderWidth: 1
  },
  // Kuerzung langer Symbol-/Layerpfade: nur das letzte Segment zeigen,
  // der volle Pfad steht im Tooltip. Umschaltbar neben Artboard/Document.
  pathDisplay: {
    modes: ['Gekürzt', 'Vollständig'],
    defaultIndex: 0,
    x: 320,
    y: 574,
    width: 260,
    height: 20,
    cellWidth: 120
  },
  // Action buttons (SELECT/CANCEL)
  buttons: {
    y: 20,
    height: 30,
    width: 100,
    select: {
      x: 20
    },
    cancel: {
      x: 140
    }
  },
  // Version
  // Kept in step with manifest.json by incrementVersion.js, so the startup log
  // line identifies WHICH build is running — a constant here made a stale
  // bundle indistinguishable from a fresh one (260908).
  version: "0.3.1033",
  // Error messages
  errorMessages: {
    noLayerSelected: "Keine Ebene ausgewählt. Bitte wählen Sie eine Ebene aus und versuchen Sie es erneut.",
    noParentArtboard: "Die ausgewählte Ebene befindet sich nicht in einem Artboard.",
    noStyleProperties: "Die ausgewählte Ebene hat keine Style-Eigenschaften (Fills/Borders).",
    generalError: "Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut."
  }
};

/***/ }),

/***/ "./src/config/uiLayout.js":
/*!********************************!*\
  !*** ./src/config/uiLayout.js ***!
  \********************************/
/*! exports provided: uiLayout */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uiLayout", function() { return uiLayout; });
// Central UI layout configuration for native panels/popups
// Keep all magic numbers (margins, offsets, sizes) here so UI tweaks are consistent.

var uiLayout = {
  missingSymbolsPopup: {
    panel: {
      width: 820,
      height: 600,
      minWidth: 820,
      minHeight: 600,
      title: 'Fehlende Symbole'
    },
    scroll: {
      bottom: 44,
      // leaves room for bottom buttons
      topPad: 10,
      insetLeft: 10,
      insetRight: 0,
      // Document view width padding to avoid clipping under the vertical scroller
      documentViewWidthPad: 12
    },
    summary: {
      // reserved height at top of the scroll content
      height: 118,
      // top padding inside scroll content to prevent header clipping
      topPad: 22,
      x: 12,
      rightPad: 24,
      title: {
        height: 18,
        fontSize: 13
      },
      line: {
        height: 18,
        fontSize: 12,
        // vertical offsets under the title
        yOffset1: 22,
        yOffset2: 44
      }
    },
    footer: {
      closeButton: {
        x: 20,
        y: 10,
        width: 220,
        height: 32,
        title: 'Schliessen'
      }
    },
    row: {
      headerHeight: 30,
      headerTopInset: 10,
      titleHeight: 20,
      titleIndent: 10,
      // columns
      leftColX: 12,
      leftColWidth: 240,
      colGap: 12,
      // buttons
      buttonHeight: 28,
      buttonGap: 8,
      buttonTopInset: 8,
      buttonIndent: 10,
      // inline fields next to buttons
      inlineFieldFontSize: 12,
      inlineFieldHeight: 28,
      inlineFieldLeftPadding: 12,
      inlineFieldYOffset: -4,
      // separator / spacing
      rowBottomPadding: 14,
      separatorHeight: 1,
      separatorInsetX: 12,
      separatorPadTop: 15,
      separatorPadBottom: 15,
      // bottom extra padding after the last row
      endPad: 24
    }
  },
  progressPanel: {
    panel: {
      width: 520,
      height: 150,
      title: 'Fortschritt'
    },
    padding: {
      x: 16,
      top: 16,
      bottom: 12,
      gap: 10
    },
    label: {
      height: 18,
      fontSize: 12
    },
    bar: {
      height: 16
    },
    cancelButton: {
      width: 100,
      height: 28,
      rightPad: 20,
      y: 12,
      title: 'Abbrechen'
    }
  },
  spotAliensPopup: {
    panel: {
      width: 820,
      height: 600,
      minWidth: 560,
      minHeight: 420,
      title: 'spotAliens'
    },
    header: {
      height: 64,
      padX: 14,
      titleHeight: 18,
      summaryHeight: 18,
      titleFontSize: 13,
      summaryFontSize: 12,
      titleTopOffset: 28,
      summaryTopOffset: 48
    },
    scroll: {
      bottomBarHeight: 54,
      documentViewRightPad: 20
    },
    row: {
      height: 44,
      padTop: 10,
      button: {
        x: 14,
        yOffset: 8,
        width: 160,
        height: 28
      },
      text: {
        x: 190,
        nameYOffset: 12,
        nameHeight: 20,
        nameFontSize: 12,
        libYOffset: 2,
        libHeight: 16,
        libFontSize: 10,
        rightPad: 20
      },
      separator: {
        x: 14,
        height: 1,
        leftRightPad: 28
      }
    },
    footer: {
      closeButton: {
        x: 14,
        y: 12,
        width: 160,
        height: 30,
        title: 'Schliessen'
      },
      selectAllButton: {
        x: 190,
        y: 12,
        width: 220,
        height: 30
      }
    }
  },
  inspectSymbolOriginPanel: {
    panel: {
      width: 920,
      height: 680,
      title: 'Inspect'
    },
    scroll: {
      bottomBarHeight: 52
    },
    footer: {
      closeButton: {
        x: 14,
        y: 12,
        width: 140,
        height: 30,
        title: 'Schliessen'
      },
      copyButton: {
        x: 170,
        y: 12,
        width: 220,
        height: 30,
        title: 'Copy to Clipboard'
      }
    },
    text: {
      fontName: 'Menlo',
      fontSize: 11
    }
  },
  // Generic dual scroll panel used by Annaliese (two columns)
  dualScrollPanel: {
    header: {
      topPad: 0
    },
    scroll: {
      top: 50,
      bottom: 50,
      gutter: 0,
      contentHeightMultiplier: 2
    }
  },
  annaliese: {
    mainPanel: {
      width: 600,
      height: 800,
      minWidth: 600,
      minHeight: 600,
      title: 'Style Vergleich',
      // Initial Y used for checkbox rendering (UI-mode). Large value means start near the top of long content.
      analysisStartY: 1520
    },
    batchOptionsPanel: {
      width: 400,
      height: 200,
      title: 'Batch-Modus Optionen',
      radio: {
        x: 20,
        y: 100,
        width: 360,
        height: 40,
        cellW: 160,
        cellH: 20,
        cellGapX: 20
      },
      buttons: {
        ok: {
          x: 20,
          y: 20,
          width: 100,
          height: 30,
          title: 'OK'
        },
        cancel: {
          x: 140,
          y: 20,
          width: 100,
          height: 30,
          title: 'CANCEL'
        }
      }
    }
  },
  equalizePanel: {
    panel: {
      width: 600,
      height: 500,
      minWidth: 600,
      minHeight: 500,
      title: 'Equalize Eigenschaften'
    },
    labels: {
      source: {
        x: 20,
        y: 435,
        width: 250,
        height: 20
      },
      target: {
        x: 330,
        y: 435,
        width: 250,
        height: 20
      }
    },
    dropdowns: {
      source: {
        x: 20,
        y: 385,
        width: 250,
        height: 20
      },
      target: {
        x: 330,
        y: 385,
        width: 250,
        height: 20
      }
    },
    buttons: {
      cancel: {
        x: 140,
        y: 20,
        width: 100,
        height: 30,
        title: 'Cancel'
      },
      ok: {
        x: 260,
        y: 20,
        width: 100,
        height: 30,
        title: 'OK',
        fontSize: 14
      },
      swap: {
        x: 200,
        y: 385,
        width: 100,
        height: 30,
        title: 'Swap'
      }
    }
  },
  morphToDialog: {
    window: {
      width: 300,
      height: 300
    },
    positions: {
      checkboxStartY: 260,
      radioButtonStartY: 200,
      checkboxX: 40,
      radioButtonX: 170,
      verticalSpacing: 30,
      verticalExtraSpacing: 0
    }
  }
};

/***/ }),

/***/ "./src/progressPanel.js":
/*!******************************!*\
  !*** ./src/progressPanel.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return createProgressPanel; });
/* harmony import */ var _config_uiLayout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./config/uiLayout */ "./src/config/uiLayout.js");
// Small native progress panel (non-webview)
// Usage:
//   const progress = createProgressPanel({ title: '...', total: 123 })
//   progress.setProgress(10, 'Doing work...')
//   if (progress.isCancelled()) ...
//   progress.close()


function createProgressPanel() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
    title = _ref.title,
    total = _ref.total,
    message = _ref.message,
    indeterminate = _ref.indeterminate;
  var L = _config_uiLayout__WEBPACK_IMPORTED_MODULE_0__["uiLayout"].progressPanel;
  var panelWidth = L.panel.width;
  var panelHeight = L.panel.height;
  var cancelled = false;
  var panel = NSPanel.alloc().init();
  panel.setFrame_display(NSMakeRect(0, 0, panelWidth, panelHeight), true);
  panel.setStyleMask(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable);
  panel.title = String(title || L.panel.title);
  panel.center();
  panel.setLevel(NSFloatingWindowLevel);
  var cleanup = function cleanup() {
    try {
      cancelled = true;
    } catch (e) {}
  };
  try {
    var delegate = MochaJSDelegate({
      'windowWillClose:': function windowWillClose() {
        cleanup();
      }
    });
    panel.setDelegate_(delegate);
  } catch (e) {}
  var contentView = panel.contentView();
  var contentH = contentView && contentView.frame ? contentView.frame().size.height : panelHeight - 28;
  var topPad = L.padding.top;
  var labelH = L.label.height;
  var barH = L.bar.height;
  var gap = L.padding.gap;
  var padX = L.padding.x;
  var labelY = Math.max(L.padding.bottom, contentH - topPad - labelH);
  var barY = Math.max(12, labelY - gap - barH);
  var label = NSTextField.alloc().initWithFrame(NSMakeRect(padX, labelY, panelWidth - padX * 2, labelH));
  label.setBezeled(false);
  label.setDrawsBackground(false);
  label.setEditable(false);
  label.setSelectable(false);
  label.setFont(NSFont.systemFontOfSize(L.label.fontSize));
  label.setStringValue(String(message || '…'));
  contentView.addSubview(label);
  var progress = NSProgressIndicator.alloc().initWithFrame(NSMakeRect(padX, barY, panelWidth - padX * 2, barH));
  var isIndeterminate = indeterminate === true || total === null || total === undefined;
  progress.setIndeterminate(!!isIndeterminate);
  if (!isIndeterminate) {
    progress.setMinValue(0);
    progress.setMaxValue(Math.max(1, Number(total || 1)));
    progress.setDoubleValue(0);
  }
  progress.setControlTint(NSDefaultControlTint);
  progress.setStyle(NSProgressIndicatorBarStyle);
  contentView.addSubview(progress);
  try {
    if (isIndeterminate && typeof progress.startAnimation === 'function') {
      progress.startAnimation(null);
    }
  } catch (e) {}
  var cancelBtn = NSButton.alloc().initWithFrame(NSMakeRect(panelWidth - L.cancelButton.rightPad - L.cancelButton.width, L.cancelButton.y, L.cancelButton.width, L.cancelButton.height));
  cancelBtn.setTitle(L.cancelButton.title);
  cancelBtn.setBezelStyle(NSBezelStyleRounded);
  cancelBtn.setCOSJSTargetFunction(function () {
    cancelled = true;
    try {
      panel.close();
    } catch (e) {}
  });
  contentView.addSubview(cancelBtn);
  try {
    panel.makeKeyAndOrderFront(null);
  } catch (e) {
    try {
      panel.orderFrontRegardless();
    } catch (e2) {}
  }
  return {
    setProgress: function setProgress(current, nextMessage) {
      try {
        if (typeof nextMessage === 'string') label.setStringValue(nextMessage);
        if (!isIndeterminate) {
          progress.setDoubleValue(Math.max(0, Number(current || 0)));
        }
        progress.displayIfNeeded();
      } catch (e) {}
    },
    isCancelled: function isCancelled() {
      return !!cancelled;
    },
    close: function close() {
      try {
        try {
          if (isIndeterminate && typeof progress.stopAnimation === 'function') {
            progress.stopAnimation(null);
          }
        } catch (e2) {}
        panel.close();
      } catch (e) {}
    }
  };
}
function MochaJSDelegate(selectorHandlerDict) {
  var uniqueClassName = 'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString();
  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, NSObject);
  delegateClassDesc.registerClass();
  Object.keys(selectorHandlerDict).forEach(function (selectorString) {
    delegateClassDesc.addInstanceMethodWithSelector_function_(NSSelectorFromString(selectorString), selectorHandlerDict[selectorString]);
  });
  return NSClassFromString(uniqueClassName).new();
}

/***/ }),

/***/ "./src/smartSelect.js":
/*!****************************!*\
  !*** ./src/smartSelect.js ***!
  \****************************/
/*! exports provided: runSmartSelect, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "runSmartSelect", function() { return runSmartSelect; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js");
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_swatchResolve__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/swatchResolve */ "./src/utils/swatchResolve.js");
/* harmony import */ var _ui_controls__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ui/controls */ "./src/ui/controls.js");


function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
var sketch = __webpack_require__(/*! sketch */ "sketch");
var _require = __webpack_require__(/*! sketch/dom */ "sketch/dom"),
  Document = _require.Document,
  Swatch = _require.Swatch;
var _require2 = __webpack_require__(/*! util */ "util"),
  toArray = _require2.toArray;
var _require3 = __webpack_require__(/*! ./config/smartSelectConfig */ "./src/config/smartSelectConfig.js"),
  smartSelectConfig = _require3.smartSelectConfig;
var createProgressPanel = __webpack_require__(/*! ./progressPanel */ "./src/progressPanel.js").default;
// Swatch naming is ID-based and lives in ONE place; see utils/swatchResolve.js.

// Panel-Grundausstattung liegt zentral, damit alle Werkzeuge gleich aussehen.

var hierarchy = {}; // Globale Definition (reset per run)
// Pfadanzeige: true = nur letztes Segment, false = voller Pfad. Umschaltbar im Panel.
var pathShortened = true;
// Alles, was das Panel an waehlbaren Eintraegen anbietet — am Ende des Aufbaus
// als Block ins Log. Der Owner markiert daran in einem Durchgang, was wegfaellt,
// statt jede Zeile abzutippen (Owner-Wunsch 260908).
var offeredEntries = [];
// Alle gezeichneten Zeilen: { id, views, text, column }. Suche und
// Pfad-Umschalter arbeiten darauf, statt das Panel neu zu bauen.
var rowRegistry = [];
var DEBUG = true; // Debug-Flag: Auf "true" setzen, um Logs zu aktivieren
var DEBUG_TEST_SWATCH = false; // Automatischer Swatch-Test beim Start

var document = null;
var layer = null;
function getNativeDocumentData(nativeObj) {
  try {
    if (!nativeObj) return null;
    var dd = nativeObj.documentData;
    // Mocha methods report typeof 'function' but do NOT support .call() —
    // invoke directly on the object (see utils/swatchResolve.js header).
    if (typeof dd === 'function') return nativeObj.documentData();
    return dd || null;
  } catch (e) {
    logDebug("\u26A0\uFE0F getNativeDocumentData: documentData nicht lesbar: ".concat(e));
    return null;
  }
}
function nativeObjectIDString(nativeObj) {
  try {
    if (!nativeObj) return null;
    var v = nativeObj.objectID;
    if (typeof v === 'function') return String(nativeObj.objectID());
    if (v !== undefined && v !== null) return String(v);
    return null;
  } catch (e) {
    logDebug("\u26A0\uFE0F nativeObjectIDString: objectID nicht lesbar: ".concat(e));
    return null;
  }
}
function logDebug(message) {
  if (DEBUG) {
    console.log(message);
  }
}
function isArtboardOrFrameLayer(layer) {
  try {
    if (!layer) return false;
    // Top-level Frames/Graphics still report as Artboard for backwards compatibility.
    if (layer.type === 'Artboard' || layer.type === sketch.Types.Artboard) return true;

    // Sketch 2025+ nested Frames/Graphics
    try {
      var dom = __webpack_require__(/*! sketch/dom */ "sketch/dom");
      var GroupBehavior = dom && dom.GroupBehavior;
      if (GroupBehavior && layer.groupBehavior) {
        return layer.groupBehavior === GroupBehavior.Frame || layer.groupBehavior === GroupBehavior.Graphic;
      }
    } catch (e) {
      logDebug("\u26A0\uFE0F isArtboardOrFrameLayer: GroupBehavior-Pruefung fehlgeschlagen fuer \"".concat(layer && layer.name, "\": ").concat(e));
    }

    // Native fallback
    var native = layer.sketchObject;
    if (native) {
      if (typeof native.isFrame === 'function') return !!native.isFrame();
      if (native.isFrame !== undefined) return !!native.isFrame;
    }
    return false;
  } catch (e) {
    logDebug("\u26A0\uFE0F isArtboardOrFrameLayer: nativer Fallback fehlgeschlagen fuer \"".concat(layer && layer.name, "\": ").concat(e));
    return false;
  }
}
function getEnclosingContainerForArtboardScope(layer) {
  try {
    if (!layer) return null;
    if (isArtboardOrFrameLayer(layer)) return layer;
    if (typeof layer.getParentArtboard === 'function') {
      var ab = layer.getParentArtboard();
      if (ab) return ab;
    }
    // Fallback: climb parents for a Frame/Graphic/Artboard
    var p = layer.parent;
    var guard = 0;
    while (p && guard++ < 60) {
      if (isArtboardOrFrameLayer(p)) return p;
      p = p.parent;
    }
    return null;
  } catch (e) {
    logDebug("\u26A0\uFE0F swatchForMSColor: Swatch-Suche fehlgeschlagen: ".concat(e));
    return null;
  }
}

// Automatischer Debug-Test für Swatch-Erkennung
function runSwatchDebugTest() {
  var _layer$style;
  if (!DEBUG_TEST_SWATCH) return;
  logDebug('=== 🧪 AUTOMATISCHER SWATCH DEBUG TEST ===');
  if (!layer || layer.type !== 'Text') {
    logDebug('⚠️  Test übersprungen: Kein Text-Layer ausgewählt');
    return;
  }
  logDebug("\uD83D\uDCDD Teste Layer: \"".concat(layer.name, "\""));
  logDebug("   textColor: ".concat((_layer$style = layer.style) === null || _layer$style === void 0 ? void 0 : _layer$style.textColor));
  try {
    var nativeStyle = layer.sketchObject.style();
    var textStyle = nativeStyle ? nativeStyle.textStyle() : null;
    if (!textStyle) {
      logDebug('❌ Kein textStyle gefunden');
      return;
    }
    var encodedAttrs = textStyle.encodedAttributes();
    if (!encodedAttrs) {
      logDebug('❌ Keine encodedAttributes gefunden');
      return;
    }
    logDebug("\u2705 encodedAttributes gefunden");
    var colorAttr = encodedAttrs.objectForKey('MSAttributedStringColorAttribute');
    if (colorAttr) {
      logDebug("\u2705 MSAttributedStringColorAttribute gefunden: ".concat(colorAttr));
      logDebug("   Class: ".concat(colorAttr.class()));
      var swatchID = colorAttr.swatchID ? colorAttr.swatchID() : null;
      if (swatchID) {
        logDebug("   \u2705\u2705\u2705 HAS SWATCH! swatchID: ".concat(swatchID));
        var docData = getNativeDocumentData(layer && layer.sketchObject);
        if (!docData || typeof docData.swatchWithID !== 'function') {
          logDebug('   ❌ documentData/swatches nicht verfügbar (API change?)');
          return;
        }
        var nativeSwatch = docData.swatchWithID(swatchID);
        var swatch = Swatch.from(nativeSwatch);
        logDebug("   \u2705\u2705\u2705 Swatch Name: ".concat(swatch.name));
      } else {
        logDebug("   \u274C KEIN SWATCH - nur direkte Farbe");
      }
    } else {
      logDebug("\u274C Kein MSAttributedStringColorAttribute gefunden");
    }
    logDebug('=== 🧪 ENDE SWATCH DEBUG TEST ===\n');
  } catch (e) {
    logDebug("\u274C Test-Fehler: ".concat(e.message));
    logDebug("   Stack: ".concat(e.stack));
  }
}

// Die Overrides-Spalte ist fest sichtbar, seit sie eine eigene Ueberschrift
// traegt. Das fruehere withOverrides-Flag steuerte nichts mehr und ist damit
// entfallen — mit ihm die Variante "Smart Select (Overrides)".
function runSmartSelect() {
  try {
    // Helper: Add section title
    var addSectionTitle = function addSectionTitle(title, x, yPos) {
      var titleLabel = NSTextField.alloc().initWithFrame(NSMakeRect(x, yPos, 350, 20));
      titleLabel.setStringValue(title);
      titleLabel.setEditable(false);
      titleLabel.setBezeled(false);
      titleLabel.setDrawsBackground(false);
      // Prevent truncation
      if (titleLabel.setLineBreakMode) titleLabel.setLineBreakMode(NSLineBreakByWordWrapping);
      if (titleLabel.cell && titleLabel.cell()) titleLabel.cell().setWraps(true);
      // Semibold statt Bold: traegt die Hierarchie, ohne zu schreien.
      var _titleSize = smartSelectConfig.layerProps.sectionTitle.fontSize;
      titleLabel.setFont(NSFont.systemFontOfSize_weight ? NSFont.systemFontOfSize_weight(_titleSize, 0.3) : NSFont.boldSystemFontOfSize(_titleSize));
      panel.contentView().addSubview(titleLabel);
    };
    var _updateChildCheckboxesFromHierarchy = function updateChildCheckboxesFromHierarchy(parentId, state) {
      logDebug("Aktualisiere Kinder von \"".concat(parentId, "\" mit Zustand: ").concat(state));
      var childIds = hierarchy[parentId];
      logDebug("Gefundene Kinder:", childIds);
      if (!Array.isArray(childIds) || childIds.length === 0) {
        logDebug("Keine g\xFCltigen Kinder f\xFCr \"".concat(parentId, "\" gefunden."));
        return;
      }
      childIds.forEach(function (childId) {
        logDebug("Aktualisiere \"".concat(childId, "\""));
        if (checkboxRefs[childId]) {
          checkboxRefs[childId].setState(state);
          _updateChildCheckboxesFromHierarchy(childId, state);
        } else {
          logDebug("Checkbox-Referenz f\xFCr \"".concat(childId, "\" nicht gefunden."));
        }
      });
    };
    var addCheckbox = function addCheckbox(title, id) {
      var indent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var color = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
      var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
      try {
        return addCheckboxInner(title, id, indent, color, options);
      } catch (e) {
        // Eine einzelne Zeile darf niemals den restlichen Baum kosten. Genau das
        // ist am 260909 passiert: ein fehlender CocoaScript-Selektor in der
        // Wert-Auszeichnung riss den kompletten Override-Baum mit, weil der
        // gesamte Panel-Aufbau in EINEM try-Block liegt.
        logDebug("\u26A0\uFE0F Zeile \"".concat(id, "\" konnte nicht gezeichnet werden, ueberspringe sie: ").concat(e));
        return null;
      }
    };
    var addCheckboxInner = function addCheckboxInner(title, id) {
      var indent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var color = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
      var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
      offeredEntries.push({
        id: id,
        indent: indent,
        title: String(title).replace(/\n/g, ' / ')
      });
      // Jede Zeile wird registriert, damit Suche und Pfad-Umschalter sie
      // in place erreichen — ein Neuaufbau des Panels ist verboten
      // (sketch-plugin-gotchas §1: eigenen Kontext nie neu spawnen).
      var _rowViews = [];
      var checkboxWidth = smartSelectConfig.checkbox.width;
      var swatchWidth = smartSelectConfig.swatch.width;
      var swatchHeight = smartSelectConfig.swatch.height;
      var spacing = smartSelectConfig.checkbox.labelSpacing;
      var indentWidth = smartSelectConfig.checkbox.indentWidth;
      var labelWidth = smartSelectConfig.checkbox.labelWidth;
      var lineHeight = smartSelectConfig.checkbox.lineHeight || 18;
      var rowGap = smartSelectConfig.checkbox.rowGap || 4;
      var baseX = smartSelectConfig.checkbox.baseX + indent * indentWidth - rightColumnXOffset;

      // Farbfeld: gleiche Kantenlaenge wie die Checkbox, auf deren Mitte
      // ausgerichtet, mit weichen Ecken. Rahmen in separatorColor statt Schwarz —
      // ein schwarzer Rand ist im Dark Mode unsichtbar.
      //
      // Es sitzt RECHTS der Checkbox, zwischen Kaestchen und Text. Links davor
      // brach es die Einrueckungsflucht: eine Zeile mit Farbe stand weiter links
      // als ihre Geschwister auf derselben Ebene.
      if (color) {
        var boxH = smartSelectConfig.checkbox.height;
        var swatchX = baseX + checkboxWidth + spacing;
        var swatchY = y + Math.round((boxH - swatchHeight) / 2);
        var swatch = NSView.alloc().initWithFrame(NSMakeRect(swatchX, swatchY, swatchWidth, swatchHeight));
        swatch.setWantsLayer(true);
        swatch.layer().setBackgroundColor(color.CGColor());
        swatch.layer().setCornerRadius(smartSelectConfig.swatch.cornerRadius || 3);
        swatch.layer().setBorderColor(NSColor.separatorColor().CGColor());
        swatch.layer().setBorderWidth(smartSelectConfig.swatch.borderWidth);
        if (options.tooltip) swatch.setToolTip(options.tooltip);
        rightColumnTarget.addSubview(swatch);
        _rowViews.push(swatch);
      }

      // Checkbox erstellen
      var boxX = baseX;
      var boxHeight = smartSelectConfig.checkbox.height;
      var box = NSButton.alloc().initWithFrame(NSMakeRect(boxX, y, checkboxWidth, boxHeight));
      box.setButtonType(NSButtonTypeSwitch);
      box.setState(NSOffState);
      box.setIdentifier(id);
      rightColumnTarget.addSubview(box);
      checkboxRefs[id] = box;

      // Label hinzufügen
      // Label ruecken, wenn ein Farbfeld dazwischensitzt.
      var labelX = box.frame().origin.x + checkboxWidth + spacing + (color ? swatchWidth + spacing : 0);
      // Dynamische Höhe je nach Zeilenumbrüchen
      var lineCount = String(title).includes("\n") ? 2 : 1;
      var labelHeight = Math.max(boxHeight, lineHeight * lineCount + (lineCount - 1) * 2);
      var labelOffsetY = smartSelectConfig.checkbox.labelOffsetY || 0;
      var label = NSTextField.alloc().initWithFrame(NSMakeRect(labelX, y + labelOffsetY, labelWidth, labelHeight));
      // Wert in Klammern und fett: Eigenschaft und Wert ohne Sonderzeichen
      // unterscheidbar. Attributierter String auf demselben Textfeld — kein
      // eigener View, keine JS-backed Render-Methode.
      if (options.valueText) {
        var plain = "".concat(title, ": ").concat(options.valueText);
        // Erst den Text setzen, DANN versuchen ihn auszuzeichnen. Schlaegt die
        // Auszeichnung fehl, steht trotzdem der richtige Text da — vorher riss
        // ein fehlender Selektor den gesamten restlichen Baum mit
        // (NSMutableAttributedString.initWithString existiert in CocoaScript
        // nicht; korrekt ist initWithString_attributes_).
        label.setStringValue(plain);
        try {
          var baseFont = NSFont.systemFontOfSize(12);
          var boldFont = NSFont.boldSystemFontOfSize(12);
          var attrs = NSDictionary.dictionaryWithObject_forKey(baseFont, NSFontAttributeName);
          var attr = NSMutableAttributedString.alloc().initWithString_attributes(plain, attrs);
          var vStart = title.length + 2; // hinter ": "

          var vLen = plain.length - vStart;
          attr.addAttribute_value_range(NSFontAttributeName, boldFont, NSMakeRange(vStart, vLen));
          label.setAttributedStringValue(attr);
        } catch (e) {
          logDebug("Wert-Auszeichnung fuer \"".concat(id, "\" nicht moeglich, bleibe bei Klartext: ").concat(e));
        }
      } else {
        label.setStringValue(title);
      }
      label.setEditable(false);
      label.setBezeled(false);
      label.setDrawsBackground(false);
      // Enable word wrapping to avoid cutting off
      if (label.setLineBreakMode) label.setLineBreakMode(NSLineBreakByWordWrapping);
      if (label.cell && label.cell()) {
        label.cell().setWraps(true);
        if (label.cell().setUsesSingleLineMode) label.cell().setUsesSingleLineMode(false);
      }
      if (options.tooltip) {
        label.setToolTip(options.tooltip);
        box.setToolTip(options.tooltip);
      }
      rightColumnTarget.addSubview(label);
      _rowViews.push(box, label);
      rowRegistry.push({
        id: id,
        views: _rowViews,
        label: label,
        fullTitle: options.fullTitle || String(title),
        shortTitle: String(title),
        text: String(title).replace(/\n/g, ' ').toLowerCase(),
        column: rightColumnTarget === panel.contentView() ? 'left' : 'right'
      });

      // Match Mode Radio Buttons + editable pattern field (for stringValue overrides)
      if (options.matchMode) {
        // Move y down past the checkbox/label row to position radio buttons
        var step0 = Math.max(boxHeight, labelHeight) + rowGap;
        y -= step0;
        var radioX = baseX + indentWidth;
        var modes = smartSelectConfig.matchMode.modes;
        var radioLabelWidth = smartSelectConfig.matchMode.labelWidth;
        var radioWidth = smartSelectConfig.matchMode.width;
        var cellWidth = radioLabelWidth + radioWidth;
        var totalWidth = modes.length * cellWidth + (modes.length - 1) * smartSelectConfig.matchMode.spacing;
        var _radioGroup = NSMatrix.alloc().initWithFrame_mode_prototype_numberOfRows_numberOfColumns(NSMakeRect(radioX, y, totalWidth, 20), NSRadioModeMatrix, NSButtonCell.alloc().init(), 1, modes.length);
        _radioGroup.setMode(NSRadioModeMatrix);
        _radioGroup.setAllowsEmptySelection(false);
        _radioGroup.setCellSize(NSMakeSize(cellWidth, 18));
        _radioGroup.setIntercellSpacing(NSMakeSize(smartSelectConfig.matchMode.spacing, 0));
        var defaultIndex = 1; // Substring
        for (var idx = 0; idx < modes.length; idx++) {
          var radioButton = _radioGroup.cells().objectAtIndex(idx);
          if (radioButton && radioButton.setTitle) radioButton.setTitle(modes[idx]);
          if (radioButton && radioButton.setButtonType) radioButton.setButtonType(NSButtonTypeRadio);
          if (radioButton && radioButton.setState) radioButton.setState(idx === defaultIndex ? NSOnState : NSOffState);
        }
        if (_radioGroup.selectCellAtRow_column) _radioGroup.selectCellAtRow_column(0, defaultIndex);
        rightColumnTarget.addSubview(_radioGroup);
        matchModeRefs[id] = _radioGroup;

        // Editable pattern text field
        y -= 20 + rowGap;
        var patternField = NSTextField.alloc().initWithFrame(NSMakeRect(radioX, y, totalWidth, 22));
        patternField.setStringValue(options.patternValue || '');
        patternField.setEditable(true);
        patternField.setBezeled(true);
        patternField.setBezelStyle(NSTextFieldRoundedBezel);
        patternField.setFont(NSFont.systemFontOfSize(12));
        patternField.setPlaceholderString('Search pattern...');
        rightColumnTarget.addSubview(patternField);
        patternFieldRefs[id] = patternField;

        // Final step for pattern field row
        y -= 22 + rowGap;
      } else {
        // Normal: advance y past the checkbox/label row
        var step = Math.max(boxHeight, labelHeight) + rowGap;
        y -= step;
      }

      // Rekursive Logik: Untergeordnete Checkboxen aktualisieren
      box.setCOSJSTargetFunction(function () {
        var state = box.state();
        _updateChildCheckboxesFromHierarchy(id, state);
      });
    }; // Function for Layer Properties checkboxes (left column)
    var addLayerPropCheckbox = function addLayerPropCheckbox(title, id) {
      var indent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      var checkboxWidth = smartSelectConfig.layerProps.width;
      var spacing = smartSelectConfig.layerProps.labelSpacing;
      var indentWidth = smartSelectConfig.layerProps.indentWidth;
      var labelWidth = smartSelectConfig.layerProps.labelWidth;
      var baseX = smartSelectConfig.layerProps.baseX + indent * indentWidth;

      // Checkbox erstellen
      var box = NSButton.alloc().initWithFrame(NSMakeRect(baseX, yLayerProps, checkboxWidth, smartSelectConfig.layerProps.height));
      box.setButtonType(NSButtonTypeSwitch);
      box.setState(NSOffState);
      box.setIdentifier(id);
      panel.contentView().addSubview(box);
      checkboxRefs[id] = box;

      // Label hinzufügen
      var labelX = box.frame().origin.x + checkboxWidth + spacing;
      var leftLabelOffsetY = smartSelectConfig.layerProps.labelOffsetY || 0;
      var label = NSTextField.alloc().initWithFrame(NSMakeRect(labelX, yLayerProps + leftLabelOffsetY, labelWidth, smartSelectConfig.layerProps.height));
      label.setStringValue(title);
      label.setEditable(false);
      label.setBezeled(false);
      label.setDrawsBackground(false);
      // Enable word wrapping to avoid cutting off
      if (label.setLineBreakMode) label.setLineBreakMode(NSLineBreakByWordWrapping);
      if (label.cell && label.cell()) {
        label.cell().setWraps(true);
        if (label.cell().setUsesSingleLineMode) label.cell().setUsesSingleLineMode(false);
      }
      panel.contentView().addSubview(label);

      // Match Mode Radio Buttons (für Name/Text)
      if (options.matchMode) {
        yLayerProps -= smartSelectConfig.layerProps.rowHeight;
        var radioX = baseX + indentWidth;
        var radioY = yLayerProps;
        var modes = smartSelectConfig.matchMode.modes;
        var radioWidth = smartSelectConfig.matchMode.width;
        var radioSpacing = smartSelectConfig.matchMode.spacing;
        var radioLabelWidth = smartSelectConfig.matchMode.labelWidth;

        // Create NSMatrix with NSButtonCell prototype to ensure cells support setButtonType
        var cellWidth = smartSelectConfig.matchMode.labelWidth + smartSelectConfig.matchMode.width;
        var totalWidth = modes.length * cellWidth + (modes.length - 1) * smartSelectConfig.matchMode.spacing;
        var _radioGroup2 = NSMatrix.alloc().initWithFrame_mode_prototype_numberOfRows_numberOfColumns(NSMakeRect(radioX, radioY, totalWidth, 20), NSRadioModeMatrix, NSButtonCell.alloc().init(), 1, modes.length);
        _radioGroup2.setMode(NSRadioModeMatrix);
        _radioGroup2.setAllowsEmptySelection(false);
        _radioGroup2.setCellSize(NSMakeSize(radioLabelWidth + radioWidth, 18));
        _radioGroup2.setIntercellSpacing(NSMakeSize(radioSpacing, 0));
        var defaultIndex = 1; // Substring
        for (var idx = 0; idx < modes.length; idx++) {
          var radioButton = _radioGroup2.cells().objectAtIndex(idx);
          if (radioButton && radioButton.setTitle) radioButton.setTitle(modes[idx]);
          if (radioButton && radioButton.setButtonType) radioButton.setButtonType(NSButtonTypeRadio);
          if (radioButton && radioButton.setState) radioButton.setState(idx === defaultIndex ? NSOnState : NSOffState);
        }
        if (_radioGroup2.selectCellAtRow_column) _radioGroup2.selectCellAtRow_column(0, defaultIndex);
        panel.contentView().addSubview(_radioGroup2);
        matchModeRefs[id] = _radioGroup2;

        // Editable pattern text field
        yLayerProps -= smartSelectConfig.layerProps.rowHeight;
        var fieldX = radioX;
        var fieldY = yLayerProps;
        var fieldWidth = totalWidth;
        var patternField = NSTextField.alloc().initWithFrame(NSMakeRect(fieldX, fieldY, fieldWidth, 22));
        patternField.setStringValue(options.patternValue || '');
        patternField.setEditable(true);
        patternField.setBezeled(true);
        patternField.setBezelStyle(NSTextFieldRoundedBezel);
        patternField.setFont(NSFont.systemFontOfSize(12));
        patternField.setPlaceholderString('Search pattern...');
        panel.contentView().addSubview(patternField);
        patternFieldRefs[id] = patternField;
      }

      // Rekursive Logik: Untergeordnete Checkboxen aktualisieren
      box.setCOSJSTargetFunction(function () {
        var state = box.state();
        _updateChildCheckboxesFromHierarchy(id, state);
      });
      yLayerProps -= smartSelectConfig.layerProps.rowHeight;
    }; // === LAYER PROPERTIES (Left Column) ===
    // Ueberschrift auf die Ueberschriftenzeile des Rasters, damit sie mit
    // "Overrides" rechts auf einer Linie steht; der Inhalt beginnt darunter.
    // Always resolve document + selection at execution time.
    document = Document.getSelectedDocument();
    layer = document && document.selectedLayers && document.selectedLayers.layers ? document.selectedLayers.layers[0] : null;
    hierarchy = {};
    console.log("\uD83D\uDCE2 Layer: ".concat(layer ? layer.name : 'null', ", type: ").concat(layer ? layer.type : '?'));

    // Automatischer Swatch-Debug-Test
    runSwatchDebugTest();

    // Null check: Layer selected
    if (!layer) {
      logDebug("Keine Ebene ausgewählt.");
      sketch.UI.message(smartSelectConfig.errorMessages.noLayerSelected);
      return;
    }

    // Note: We no longer gate the panel on style properties.
    // The panel can also be used to select by layer type, symbol name, text content, etc.
    // Style properties section will simply be empty/disabled when no styles exist.
    var hasStyleProperties = !!layer.style;
    var isSymbolInstance = layer.type === 'SymbolInstance';
    var hasTextColor = hasStyleProperties && layer.type === 'Text';
    var hasFills = hasStyleProperties && layer.style.fills && layer.style.fills.length > 0;
    var hasBorders = hasStyleProperties && layer.style.borders && layer.style.borders.length > 0;
    var hasAnyStyleProp = hasTextColor || hasFills || hasBorders;

    // For SymbolInstances: always collect overrides (shown in collapsible section)
    var overrideEntries = [];
    var overrideGroups = {}; // keyed by affectedLayer name → array of entries
    if (isSymbolInstance && layer.overrides) {
      var ovCount = layer.overrides.length;
      var ovTypes = layer.overrides.map(function (ov) {
        return ov.property;
      }).filter(function (v, i, a) {
        return a.indexOf(v) === i;
      }).join(', ');
      logDebug("\uD83D\uDD0E SymbolInstance \"".concat(layer.name, "\" hat ").concat(ovCount, " overrides. Typen: ").concat(ovTypes));
      try {
        layer.overrides.forEach(function (ov, ovIndex) {
          try {
            logDebug("  ov[".concat(ovIndex, "]: prop=\"").concat(ov.property, "\" path=\"").concat(ov.path, "\" editable=").concat(ov.editable, " isDefault=").concat(ov.isDefault, " affectedLayer=\"").concat(ov.affectedLayer ? ov.affectedLayer.name : '?', "\" value=\"").concat(String(ov.value).substring(0, 60), "\""));
            if (!ov.editable) return;
            var prop = ov.property;
            var affName = ov.affectedLayer ? ov.affectedLayer.name : '(unknown)';
            var ovPath = ov.path;
            var ovValue = ov.value;
            var isDefault = ov.isDefault;
            var entry = null;

            // === COLOR OVERRIDES (color:fill-0, color:border-0, color:text, etc.) ===
            if (prop.startsWith('color:')) {
              var resolved = resolveOverrideColor(ovValue, layer, ov);
              if (resolved.color) {
                // Titel traegt nur den Swatch-Namen; Farbwert und Herkunft
                // stehen im Tooltip, damit die Zeile einzeilig bleibt.
                var origin = resolved.swatch ? resolved.swatch.isImported() ? resolved.swatch.libraryName() : 'Lokales Farbfeld' : 'Kein Farbfeld — freie Farbe';
                var displayName = resolved.swatch ? shortenPath(resolved.swatch.name) : resolved.hex;
                var tooltip = [resolved.swatch ? resolved.swatch.name : 'Freie Farbe', resolved.hex, origin, "Eigenschaft: ".concat(prop)].join('\n');
                entry = {
                  prop: prop,
                  affName: affName,
                  path: ovPath,
                  value: ovValue,
                  isDefault: isDefault,
                  displayName: displayName,
                  tooltip: tooltip,
                  type: 'overrideColor',
                  color: resolved.color,
                  swatch: resolved.swatch,
                  hexValue: resolved.hex
                };
              } else {
                // Unresolvable color — show raw value
                var displayVal = String(ovValue).substring(0, 40);
                entry = {
                  prop: prop,
                  affName: affName,
                  path: ovPath,
                  value: ovValue,
                  isDefault: isDefault,
                  displayName: propertyLabel(prop),
                  valueText: valueLabel(prop, displayVal)
                };
              }
            }
            // === LAYER STYLE ===
            else if (prop === 'layerStyle') {
              var styleName = ovValue || '';
              try {
                var docNative = document.sketchObject;
                var docData = docNative && docNative.documentData ? typeof docNative.documentData === 'function' ? docNative.documentData() : docNative.documentData : null;
                if (docData && ovValue) {
                  var stylesContainer = typeof docData.layerStyles === 'function' ? docData.layerStyles() : docData.layerStyles;
                  var nativeSharedStyles = stylesContainer && stylesContainer.sharedStyles ? typeof stylesContainer.sharedStyles === 'function' ? stylesContainer.sharedStyles() : stylesContainer.sharedStyles : [];
                  var list = toArray(nativeSharedStyles) || [];
                  var match = list.find(function (ss) {
                    try {
                      var id = ss.objectID ? typeof ss.objectID === 'function' ? ss.objectID() : ss.objectID : null;
                      return String(id) === String(ovValue);
                    } catch (e) {
                      logDebug("\u26A0\uFE0F layerStyle: SharedStyle-Vergleich fehlgeschlagen: ".concat(e));
                      return false;
                    }
                  });
                  if (match) {
                    styleName = match.name ? typeof match.name === 'function' ? match.name() : match.name : ovValue;
                  }
                }
              } catch (e) {
                logDebug("\u26A0\uFE0F layerStyle-Override: SharedStyle-Namen nicht aufloesbar (value=".concat(String(ovValue).substring(0, 40), "): ").concat(e));
              }
              entry = {
                prop: prop,
                affName: affName,
                path: ovPath,
                value: ovValue,
                isDefault: isDefault,
                displayName: 'Style',
                valueText: shortenPath(styleName),
                tooltip: "Layer-Stil\n".concat(styleName)
              };
            }
            // === TEXT STYLE ===
            else if (prop === 'textStyle') {
              var _styleName = ovValue || '';
              try {
                var _docNative = document.sketchObject;
                var _docData = _docNative && _docNative.documentData ? typeof _docNative.documentData === 'function' ? _docNative.documentData() : _docNative.documentData : null;
                if (_docData && ovValue) {
                  var _stylesContainer = typeof _docData.layerTextStyles === 'function' ? _docData.layerTextStyles() : _docData.layerTextStyles;
                  var _nativeSharedStyles = _stylesContainer && _stylesContainer.sharedStyles ? typeof _stylesContainer.sharedStyles === 'function' ? _stylesContainer.sharedStyles() : _stylesContainer.sharedStyles : [];
                  var _list = toArray(_nativeSharedStyles) || [];
                  var _match = _list.find(function (ss) {
                    try {
                      var id = ss.objectID ? typeof ss.objectID === 'function' ? ss.objectID() : ss.objectID : null;
                      return String(id) === String(ovValue);
                    } catch (e) {
                      logDebug("\u26A0\uFE0F textStyle: SharedStyle-Vergleich fehlgeschlagen: ".concat(e));
                      return false;
                    }
                  });
                  if (_match) {
                    _styleName = _match.name ? typeof _match.name === 'function' ? _match.name() : _match.name : ovValue;
                  }
                }
              } catch (e) {
                logDebug("\u26A0\uFE0F textStyle-Override: SharedStyle-Namen nicht aufloesbar (value=".concat(String(ovValue).substring(0, 40), "): ").concat(e));
              }
              entry = {
                prop: prop,
                affName: affName,
                path: ovPath,
                value: ovValue,
                isDefault: isDefault,
                displayName: 'Text Style',
                valueText: shortenPath(_styleName),
                tooltip: "Text-Stil\n".concat(_styleName)
              };
            }
            // === SYMBOL ID ===
            else if (prop === 'symbolID') {
              var symName = ovValue || '';
              try {
                var master = document.getSymbolMasterWithID(ovValue);
                if (master) symName = master.name;
              } catch (e) {
                logDebug("\u26A0\uFE0F symbolID-Override: Master nicht gefunden fuer ID ".concat(ovValue, ": ").concat(e));
              }
              entry = {
                prop: prop,
                affName: affName,
                path: ovPath,
                value: ovValue,
                isDefault: isDefault,
                displayName: 'Symbol',
                valueText: shortenPath(symName),
                tooltip: "Symbol\n".concat(symName)
              };
            }
            // === STRING VALUE ===
            else if (prop === 'stringValue') {
              var _displayVal = ovValue && ovValue.length > 25 ? ovValue.substring(0, 25) + '…' : ovValue || '';
              entry = {
                prop: prop,
                affName: affName,
                path: ovPath,
                value: ovValue,
                isDefault: isDefault,
                displayName: 'Text',
                valueText: _displayVal
              };
            }
            // === IMAGE ===
            else if (prop === 'image') {
              entry = {
                prop: prop,
                affName: affName,
                path: ovPath,
                value: ovValue,
                isDefault: isDefault,
                displayName: "Image"
              };
            }
            // === CATCH-ALL ===
            else {
              var _displayVal2 = ovValue && String(ovValue).length > 30 ? String(ovValue).substring(0, 30) + '…' : String(ovValue || '');
              entry = {
                prop: prop,
                affName: affName,
                path: ovPath,
                value: ovValue,
                isDefault: isDefault,
                displayName: propertyLabel(prop),
                valueText: valueLabel(prop, _displayVal2)
              };
            }
            if (entry) {
              overrideEntries.push(entry);
              if (!overrideGroups[affName]) overrideGroups[affName] = [];
              overrideGroups[affName].push(entry);
              logDebug("    \u2192 entry added: \"".concat(entry.displayName, "\" for \"").concat(affName, "\""));
            }
          } catch (e) {
            logDebug("\u26A0\uFE0F Override uebersprungen: prop=\"".concat(ov && ov.property, "\" auf Layer \"").concat(layer && layer.name, "\": ").concat(e));
          }
        });
      } catch (e) {
        logDebug("Fehler beim Lesen der Overrides: ".concat(e.message));
      }
      logDebug("\uD83D\uDCCA overrideEntries: ".concat(overrideEntries.length, ", overrideGroups: ").concat(Object.keys(overrideGroups).length, " groups: [").concat(Object.keys(overrideGroups).join(', '), "]"));
    }

    // Keep the script alive only once we actually show UI.
    try {
      COScript.currentCOScript().setShouldKeepAround_(true);
    } catch (e) {
      logDebug("\u26A0\uFE0F setShouldKeepAround(true) fehlgeschlagen - Panel koennte vorzeitig sterben: ".concat(e));
    }
    var threadDictionary = NSThread.mainThread().threadDictionary();
    var identifier = 'net.notbot.toolboxx.smartSelect';
    var delegateKey = "".concat(identifier, ".delegate");
    if (threadDictionary[identifier]) {
      try {
        threadDictionary[identifier].close();
      } catch (e) {
        logDebug("Vorheriges Panel liess sich nicht schliessen: ".concat(e));
      }
      try {
        threadDictionary.removeObjectForKey(identifier);
      } catch (e) {
        logDebug("Panel-Referenz nicht entfernbar: ".concat(e));
      }
      try {
        threadDictionary.removeObjectForKey(delegateKey);
      } catch (e) {
        logDebug("\u26A0\uFE0F Swatch-Aufloesung (Farbvergleich) fehlgeschlagen: ".concat(e));
      }
    }
    var version = smartSelectConfig.version;
    logDebug("Smart Select gestartet \u2014 Version ".concat(version));

    // === Panel Setup ===
    var panel = NSPanel.alloc().init();
    panel.setFrame_display(NSMakeRect(0, 0, smartSelectConfig.panel.width, smartSelectConfig.panel.height), true);
    panel.setStyleMask(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable);
    panel.setBackgroundColor(NSColor.windowBackgroundColor());
    panel.title = "Smart Select";
    panel.center();
    panel.makeKeyAndOrderFront(null);
    panel.setLevel(NSFloatingWindowLevel);
    panel.minSize = NSMakeSize(smartSelectConfig.panel.minWidth, smartSelectConfig.panel.minHeight);
    logDebug("[PluginUI] Panel wurde angezeigt.");

    // Materialuntergrund und Notausgang, BEVOR Inhalt gezeichnet wird: ein
    // sichtbares Fenster muss ab der ersten Sekunde schliessbar sein.
    Object(_ui_controls__WEBPACK_IMPORTED_MODULE_3__["applyPanelChrome"])(panel, logDebug);
    Object(_ui_controls__WEBPACK_IMPORTED_MODULE_3__["addEscapeHatch"])(panel, logDebug);
    try {
      var delegate = MochaJSDelegate({
        'windowWillClose:': function windowWillClose() {
          try {
            threadDictionary.removeObjectForKey(identifier);
          } catch (e) {
            logDebug("Panel-Referenz nicht entfernbar: ".concat(e));
          }
          try {
            threadDictionary.removeObjectForKey(delegateKey);
          } catch (e) {
            logDebug("Delegate-Referenz nicht entfernbar: ".concat(e));
          }
          try {
            COScript.currentCOScript().setShouldKeepAround_(false);
          } catch (e) {
            logDebug("setShouldKeepAround(false) fehlgeschlagen: ".concat(e));
          }
          logDebug("[PluginUI] Panel geschlossen.");
        }
      });
      panel.setDelegate_(delegate);
      // Keep a strong reference so the delegate won't be GC'ed.
      threadDictionary[delegateKey] = delegate;
    } catch (e) {
      logDebug("Fenster-Delegate nicht setzbar \u2014 Panel meldet sein Schliessen nicht: ".concat(e));
    }
    try {
      var _delegate = MochaJSDelegate({
        'windowWillClose:': function windowWillClose() {
          try {
            threadDictionary.removeObjectForKey(identifier);
          } catch (e) {
            logDebug("Panel-Referenz nicht entfernbar: ".concat(e));
          }
          try {
            threadDictionary.removeObjectForKey(delegateKey);
          } catch (e) {
            logDebug("Delegate-Referenz nicht entfernbar: ".concat(e));
          }
          try {
            COScript.currentCOScript().setShouldKeepAround_(false);
          } catch (e) {
            logDebug("setShouldKeepAround(false) fehlgeschlagen: ".concat(e));
          }
          logDebug("[PluginUI] Panel geschlossen.");
        }
      });
      panel.setDelegate_(_delegate);
      // Keep a strong reference so the delegate won't be GC'ed.
      threadDictionary[delegateKey] = _delegate;
    } catch (e) {
      logDebug("\u26A0\uFE0F threadDictionary-Delegate konnte nicht gesetzt werden: ".concat(e));
      // best effort
    }

    // Keep a strong reference to avoid multiple windows and allow cleanup.
    try {
      threadDictionary[identifier] = panel;
    } catch (e) {
      logDebug("\u26A0\uFE0F Style-Eigenschaften nicht lesbar fuer \"".concat(layer && layer.name, "\": ").concat(e));
    }

    // Radiobuttons für Artboard und Document
    var radioGroup = NSMatrix.alloc().initWithFrame_mode_prototype_numberOfRows_numberOfColumns(NSMakeRect(smartSelectConfig.radioButtons.x, smartSelectConfig.radioButtons.y, smartSelectConfig.radioButtons.width, smartSelectConfig.radioButtons.height), NSRadioModeMatrix,
    // Radiobutton-Modus
    NSButtonCell.alloc().init(), 1,
    // Eine Zeile
    2 // Zwei Spalten (Artboard und Document)
    );

    // Größe und Abstand der Radiobuttons
    radioGroup.setCellSize(NSMakeSize(smartSelectConfig.radioButtons.cellWidth, smartSelectConfig.radioButtons.cellHeight));
    radioGroup.setIntercellSpacing(NSMakeSize(smartSelectConfig.radioButtons.spacing, 0));
    radioGroup.setAllowsEmptySelection(false); // Keine leere Auswahl erlaubt

    // Radiobuttons erstellen
    var artboardButton = radioGroup.cells().objectAtIndex(0);
    artboardButton.setTitle("Artboard");
    artboardButton.setButtonType(NSButtonTypeRadio); // Radiobutton-Typ
    artboardButton.setState(NSOnState); // Vorauswahl

    var documentButton = radioGroup.cells().objectAtIndex(1);
    documentButton.setTitle("Document");
    documentButton.setButtonType(NSButtonTypeRadio); // Radiobutton-Typ

    // Radiobuttons zur Ansicht hinzufügen
    panel.contentView().addSubview(radioGroup);

    // === Pfadanzeige: Gekürzt / Vollständig ===
    // Auf gleicher Hoehe wie Artboard/Document, weil beides denselben Rang hat:
    // was durchsucht wird (Scope) und wie es dargestellt wird.
    var pathCfg = smartSelectConfig.pathDisplay;
    var pathGroup = NSMatrix.alloc().initWithFrame_mode_prototype_numberOfRows_numberOfColumns(NSMakeRect(pathCfg.x, pathCfg.y, pathCfg.width, 20), NSRadioModeMatrix, NSButtonCell.alloc().init(), 1, pathCfg.modes.length);
    pathGroup.setMode(NSRadioModeMatrix);
    pathGroup.setAllowsEmptySelection(false);
    pathGroup.setCellSize(NSMakeSize(pathCfg.cellWidth, 18));
    for (var i = 0; i < pathCfg.modes.length; i++) {
      var cell = pathGroup.cells().objectAtIndex(i);
      cell.setTitle(pathCfg.modes[i]);
      cell.setButtonType(NSButtonTypeRadio);
      if (i === pathCfg.defaultIndex) cell.setState(NSOnState);
    }
    panel.contentView().addSubview(pathGroup);
    pathGroup.setTarget(pathGroup);
    pathGroup.setAction('callAction:');
    pathGroup.setCOSJSTargetFunction(function () {
      // In place umbeschriften — das Panel wird NICHT neu gebaut.
      pathShortened = pathGroup.selectedColumn() === 0;
      rowRegistry.forEach(function (r) {
        if (!r.label || r.fullTitle === r.shortTitle) return;
        try {
          r.label.setStringValue(pathShortened ? r.shortTitle : r.fullTitle);
        } catch (e) {
          logDebug("Pfadanzeige: Zeile \"".concat(r.id, "\" nicht umbeschriftbar: ").concat(e));
        }
      });
    });
    offeredEntries = [];
    rowRegistry = [];

    // === Suche: je ein Feld pro Spalte ===
    // Filtert die vorhandenen Zeilen, statt neu zu zeichnen: nicht passende
    // Zeilen werden versteckt, ihre Y-Position bleibt. Das ist die konservative
    // Variante — ein Reflow wuerde bedeuten, das Panel neu aufzubauen.
    var applyFilter = function applyFilter(column, needle) {
      var q = String(needle || '').trim().toLowerCase();
      rowRegistry.filter(function (r) {
        return r.column === column;
      }).forEach(function (r) {
        var show = !q || r.text.indexOf(q) !== -1;
        r.views.forEach(function (v) {
          try {
            v.setHidden(!show);
          } catch (e) {
            logDebug("Filter: Zeile \"".concat(r.id, "\" nicht schaltbar: ").concat(e));
          }
        });
      });
    };
    var makeSearchField = function makeSearchField(x, yPos, width, placeholder, column) {
      var f = NSTextField.alloc().initWithFrame(NSMakeRect(x, yPos, width, smartSelectConfig.searchField.height));
      f.setEditable(true);
      f.setBezeled(true);
      f.setBezelStyle(NSTextFieldRoundedBezel);
      f.setFont(NSFont.systemFontOfSize(12));
      if (f.cell && f.cell() && f.cell().setPlaceholderString) {
        f.cell().setPlaceholderString(placeholder);
      }
      f.setTarget(f);
      f.setAction('callAction:');
      f.setCOSJSTargetFunction(function () {
        return applyFilter(column, f.stringValue());
      });
      panel.contentView().addSubview(f);
      return f;
    };
    var _searchY = smartSelectConfig.rows.search;
    var _searchW = smartSelectConfig.searchField.width;
    var leftSearch = makeSearchField(smartSelectConfig.layerProps.baseX, _searchY, _searchW, 'Layer Properties durchsuchen', 'left');
    var rightSearch = makeSearchField(smartSelectConfig.checkbox.baseX, _searchY, _searchW, 'Overrides durchsuchen', 'right');

    // === Checkbox UI ===
    var y = smartSelectConfig.checkbox.startY;
    var yLayerProps = smartSelectConfig.layerProps.startY;
    var checkboxRefs = {};
    var matchModeRefs = {}; // Speichert Radio-Button-Gruppen für Match-Modi
    var patternFieldRefs = {}; // Speichert editierbare Textfelder für Match-Pattern

    // Right column scroll container (set up before right column content)
    var rightColumnTarget = panel.contentView();
    var rightColumnXOffset = 0;
    addSectionTitle("Layer Properties", smartSelectConfig.layerProps.sectionTitle.x, smartSelectConfig.rows.headings);
    yLayerProps = smartSelectConfig.rows.content;
    var layerPropsRootId = "layer-props-root";
    addLayerPropCheckbox("Layer Properties", layerPropsRootId, 0);
    hierarchy[layerPropsRootId] = [];

    // Layer Name with match modes
    var layerNameId = "layer-name";
    addLayerPropCheckbox("Name: \"".concat(layer.name, "\""), layerNameId, 1, {
      matchMode: true,
      patternValue: layer.name
    });
    hierarchy[layerPropsRootId].push(layerNameId);
    hierarchy[layerNameId] = {
      value: layer.name,
      type: 'layerName'
    };

    // Layer Type
    var layerTypeId = "layer-type";
    addLayerPropCheckbox("Type: ".concat(layer.type), layerTypeId, 1);
    hierarchy[layerPropsRootId].push(layerTypeId);
    hierarchy[layerTypeId] = {
      value: layer.type,
      type: 'layerType'
    };

    // Symbol (only for SymbolInstance)
    if (layer.type === 'SymbolInstance') {
      var symbolName = 'Unknown Symbol';
      var symbolMasterId = null;
      try {
        var so = layer.sketchObject;
        var rawId = so.symbolID;
        symbolMasterId = String(typeof rawId === 'function' ? so.symbolID() : rawId);
      } catch (e) {
        logDebug("\u26A0\uFE0F symbolID nativ nicht lesbar fuer \"".concat(layer && layer.name, "\": ").concat(e));
      }
      try {
        if (layer.master && layer.master.name) symbolName = layer.master.name;
      } catch (e) {
        logDebug("\u26A0\uFE0F Master-Name nicht lesbar fuer \"".concat(layer && layer.name, "\": ").concat(e));
      }
      var symbolId = "layer-symbol";
      addLayerPropCheckbox("Symbol: \"".concat(symbolName, "\""), symbolId, 1);
      hierarchy[layerPropsRootId].push(symbolId);
      hierarchy[symbolId] = {
        value: symbolName,
        masterId: symbolMasterId,
        type: 'symbolName'
      };
    }

    // Text Content (only for Text layers)
    if (layer.type === 'Text') {
      var textContent = layer.text || '';
      var textContentId = "layer-text-content";
      var displayText = textContent.length > 30 ? textContent.substring(0, 30) + '...' : textContent;
      addLayerPropCheckbox("Text: \"".concat(displayText, "\""), textContentId, 1, {
        matchMode: true,
        patternValue: layer.text || ''
      });
      hierarchy[layerPropsRootId].push(textContentId);
      hierarchy[textContentId] = {
        value: textContent,
        type: 'textContent'
      };
    }

    // === STYLE PROPERTIES & OVERRIDES (Right Column — scrollable, collapsible) ===
    var hasOverrides = isSymbolInstance && Object.keys(overrideGroups).length > 0;
    var rightColumnLabel = hasAnyStyleProp && hasOverrides ? "Style & Overrides" : hasOverrides ? "Overrides" : "Style Properties";

    // Ueberschrift statt Aufklapp-Button: die rechte Spalte ist der linken
    // gleichrangig, nicht ein aufklappbares Extra. Damit entfaellt auch der
    // Unterschied zwischen "Smart Select" und "Smart Select (Overrides)" — beide
    // zeigen dasselbe.
    var rightTitleLabel = NSTextField.alloc().initWithFrame(NSMakeRect(smartSelectConfig.checkbox.baseX, smartSelectConfig.rows.headings, 300, 22));
    rightTitleLabel.setStringValue(rightColumnLabel);
    rightTitleLabel.setEditable(false);
    rightTitleLabel.setBordered(false);
    rightTitleLabel.setBezeled(false);
    rightTitleLabel.setDrawsBackground(false);
    rightTitleLabel.setTextColor(NSColor.labelColor());
    var _rightTitleSize = smartSelectConfig.layerProps.sectionTitle.fontSize;
    rightTitleLabel.setFont(NSFont.systemFontOfSize_weight ? NSFont.systemFontOfSize_weight(_rightTitleSize, 0.3) : NSFont.boldSystemFontOfSize(_rightTitleSize));
    panel.contentView().addSubview(rightTitleLabel);

    // Create scrollable container for right column
    var rightScrollX = smartSelectConfig.checkbox.baseX - 10;
    var rightScrollY = smartSelectConfig.buttons.y + smartSelectConfig.buttons.height + 10;
    var rightScrollW = smartSelectConfig.panel.width - rightScrollX - 10;
    var rightScrollH = smartSelectConfig.checkbox.startY - rightScrollY;
    var rightScrollView = NSScrollView.alloc().initWithFrame(NSMakeRect(rightScrollX, rightScrollY, rightScrollW, rightScrollH));
    rightScrollView.setHasVerticalScroller(true);
    rightScrollView.setHasHorizontalScroller(false);
    rightScrollView.setBorderType(NSNoBorder);
    rightScrollView.setDrawsBackground(false);
    var rightDocViewHeight = 3000;
    var rightDocView = NSView.alloc().initWithFrame(NSMakeRect(0, 0, rightScrollW, rightDocViewHeight));
    rightScrollView.setDocumentView(rightDocView);
    panel.contentView().addSubview(rightScrollView);

    // Route addCheckbox to the scroll view's document view
    rightColumnTarget = rightDocView;
    rightColumnXOffset = rightScrollX;
    y = rightDocViewHeight - 40; // start near top of document view (enough margin for element height)

    if (hasAnyStyleProp) {
      // === Dynamische Checkboxen basierend auf der Auswahl ===
      var layerTitle = "Style of: ".concat(layer.name);
      // Der Layertitel ist oft ein langer Symbolpfad — gekuerzt anzeigen, voll im
      // Tooltip und ueber den Umschalter erreichbar.
      addCheckbox(shortenPath(layerTitle), "layer-title", 0, null, {
        tooltip: String(layerTitle),
        fullTitle: String(layerTitle)
      });
      hierarchy["layer-title"] = [];

      // Check if layer is a text layer
      var isTextLayer = layer.type === 'Text';
      logDebug("Layer-Typ: ".concat(layer.type, ", isTextLayer: ").concat(isTextLayer));

      // Appearance (Shared Layer Style) detection for any layer type
      try {
        var appearanceId = "appearance";
        var nativeLayer = layer.sketchObject; // property, not callable
        var sharedStyleId = null;
        if (nativeLayer && nativeLayer.sharedStyleID) {
          sharedStyleId = typeof nativeLayer.sharedStyleID === 'function' ? nativeLayer.sharedStyleID() : nativeLayer.sharedStyleID;
        }
        var styleName = null;
        if (sharedStyleId) {
          try {
            var docNative = document.sketchObject;
            var docData = docNative && docNative.documentData ? typeof docNative.documentData === 'function' ? docNative.documentData() : docNative.documentData : null;
            if (docData && docData.layerStyles) {
              var stylesContainer = typeof docData.layerStyles === 'function' ? docData.layerStyles() : docData.layerStyles;
              var nativeSharedStyles = stylesContainer && stylesContainer.sharedStyles ? typeof stylesContainer.sharedStyles === 'function' ? stylesContainer.sharedStyles() : stylesContainer.sharedStyles : [];
              var list = toArray(nativeSharedStyles) || [];
              var match = list.find(function (ss) {
                try {
                  var id = ss.objectID ? typeof ss.objectID === 'function' ? ss.objectID() : ss.objectID : null;
                  return String(id) === String(sharedStyleId);
                } catch (e) {
                  logDebug("\u26A0\uFE0F SharedStyle-Vergleich fehlgeschlagen: ".concat(e));
                  return false;
                }
              });
              if (match) {
                styleName = match.name ? typeof match.name === 'function' ? match.name() : match.name : null;
              }

              // Fallback: check foreign layer styles
              if (!styleName && docData.foreignLayerStyles) {
                try {
                  var foreign = typeof docData.foreignLayerStyles === 'function' ? docData.foreignLayerStyles() : docData.foreignLayerStyles;
                  var foreignList = toArray(foreign) || [];
                  foreignList.forEach(function (fs) {
                    try {
                      var localSharedStyle = fs.localSharedStyle && fs.localSharedStyle();
                      var id = localSharedStyle && localSharedStyle.objectID ? typeof localSharedStyle.objectID === 'function' ? localSharedStyle.objectID() : localSharedStyle.objectID : null;
                      if (String(id) === String(sharedStyleId)) {
                        styleName = localSharedStyle && localSharedStyle.name ? typeof localSharedStyle.name === 'function' ? localSharedStyle.name() : localSharedStyle.name : styleName;
                      }
                    } catch (e) {
                      logDebug("\u26A0\uFE0F SharedStyle-ID-Vergleich fehlgeschlagen: ".concat(e));
                    }
                  });
                } catch (e) {
                  logDebug("\u26A0\uFE0F SharedStyle-Liste nicht durchlaufbar: ".concat(e));
                }
              }
            }
          } catch (e) {
            logDebug("Fehler beim Lesen der Appearance: ".concat(e.message));
          }
        }
        var appearanceTitle = sharedStyleId ? "Appearance: ".concat(styleName || '(Unbenannt)', "\n(").concat(sharedStyleId, ")") : 'Appearance: none';
        addCheckbox(appearanceTitle, appearanceId, 1);
        hierarchy["layer-title"].push(appearanceId);
        hierarchy[appearanceId] = {
          type: 'appearance',
          styleId: sharedStyleId || null,
          styleName: styleName || null
        };
      } catch (error) {
        logDebug("Fehler beim Erfassen der Appearance: ".concat(error.message));
      }

      // Text Color (nur für Text-Layer)
      if (isTextLayer) {
        try {
          logDebug("Text-Layer erkannt: ".concat(layer.name));
          var textColorHex = layer.style.textColor;
          // Fallback: textColor über native API holen, falls DOM-Property leer
          if (!textColorHex) {
            try {
              var ns = layer.sketchObject.style();
              var ts = ns ? ns.textStyle() : null;
              if (ts) {
                var ea = ts.encodedAttributes();
                if (ea) {
                  var ca = ea.objectForKey('MSAttributedStringColorAttribute');
                  if (ca) {
                    var r = Math.round(ca.red() * 255);
                    var g = Math.round(ca.green() * 255);
                    var b = Math.round(ca.blue() * 255);
                    var a = Math.round(ca.alpha() * 255);
                    textColorHex = '#' + [r, g, b, a].map(function (v) {
                      return v.toString(16).padStart(2, '0');
                    }).join('');
                    logDebug("textColor via native API: ".concat(textColorHex));
                  }
                }
              }
            } catch (e) {
              logDebug("Native textColor fallback fehlgeschlagen: ".concat(e.message));
            }
          }
          logDebug("textColor (Hex): ".concat(textColorHex));
          if (textColorHex) {
            var textColorId = "textColor";
            addCheckbox("Text Color", textColorId, 1);
            hierarchy["layer-title"].push(textColorId);
            hierarchy[textColorId] = [];

            // Parse Hex-String zu RGBA-Werten
            var hexMatch = textColorHex.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i);
            if (hexMatch) {
              var _r = parseInt(hexMatch[1], 16) / 255;
              var _g = parseInt(hexMatch[2], 16) / 255;
              var _b = parseInt(hexMatch[3], 16) / 255;
              var _a = hexMatch[4] ? parseInt(hexMatch[4], 16) / 255 : 1;
              logDebug("Parsed RGB: ".concat(_r, ", ").concat(_g, ", ").concat(_b, ", ").concat(_a));

              // Prüfe ob der Layer tatsächlich einen Swatch verwendet
              // (nicht nur ob ein Swatch mit der Farbe existiert!)
              var layerSwatchID = null;
              var layerSwatchName = null;
              try {
                var nativeStyle = layer.sketchObject.style();
                var textStyle = nativeStyle ? nativeStyle.textStyle() : null;
                if (textStyle) {
                  var encodedAttrs = textStyle.encodedAttributes();
                  if (encodedAttrs) {
                    var colorAttr = encodedAttrs.objectForKey('MSAttributedStringColorAttribute');
                    if (colorAttr) {
                      layerSwatchID = colorAttr.swatchID ? colorAttr.swatchID() : null;
                      if (layerSwatchID) {
                        var _docData2 = getNativeDocumentData(layer && layer.sketchObject);
                        var nativeSwatch = _docData2 && typeof _docData2.swatchWithID === 'function' ? _docData2.swatchWithID(layerSwatchID) : null;
                        if (!nativeSwatch) {
                          logDebug("Swatch mit ID ".concat(layerSwatchID, " nicht im Dokument gefunden \u2013 ignoriere Swatch"));
                          layerSwatchID = null;
                        } else {
                          var swatch = Swatch.from(nativeSwatch);
                          layerSwatchName = swatch.name;
                          logDebug("Layer verwendet Swatch: ".concat(layerSwatchName, " (").concat(layerSwatchID, ")"));
                        }
                      }
                    }
                  }
                }
              } catch (e) {
                logDebug("Fehler beim Lesen der Swatch-Info: ".concat(e.message));
              }
              var displayHex = textColorHex.substring(0, 7).toLowerCase(); // Ohne Alpha
              var displayHexUpper = displayHex.toUpperCase();

              // Wenn Layer tatsächlich einen Swatch verwendet: Swatch-Name UND Farbwert als separate Checkboxen
              if (layerSwatchName) {
                // Checkbox für Swatch-Name
                var swatchTitle = "Swatch: ".concat(layerSwatchName);
                addCheckbox(swatchTitle, "".concat(textColorId, "-swatch"), 2, NSColor.colorWithRed_green_blue_alpha(_r, _g, _b, _a));
                hierarchy["".concat(textColorId, "-swatch")] = {
                  swatchName: layerSwatchName,
                  type: 'swatch'
                };
                hierarchy[textColorId].push("".concat(textColorId, "-swatch"));

                // Checkbox für Farbwert
                var colorTitle = "Color: ".concat(displayHexUpper);
                addCheckbox(colorTitle, "".concat(textColorId, "-color"), 2, NSColor.colorWithRed_green_blue_alpha(_r, _g, _b, _a));
                hierarchy["".concat(textColorId, "-color")] = {
                  hexValue: displayHex,
                  type: 'color'
                };
                hierarchy[textColorId].push("".concat(textColorId, "-color"));
                logDebug("Text Color mit Swatch: ".concat(swatchTitle, " + ").concat(colorTitle));
              } else {
                // Nur Farbwert-Checkbox wenn kein Swatch
                var _colorTitle = "Color: ".concat(displayHexUpper);
                addCheckbox(_colorTitle, "".concat(textColorId, "-color"), 2, NSColor.colorWithRed_green_blue_alpha(_r, _g, _b, _a));
                hierarchy["".concat(textColorId, "-color")] = {
                  hexValue: displayHex,
                  type: 'color'
                };
                hierarchy[textColorId].push("".concat(textColorId, "-color"));
                logDebug("Text Color ohne Swatch: ".concat(_colorTitle));
              }
            } else {
              logDebug("Konnte Hex-Farbe nicht parsen: ".concat(textColorHex));
            }
          } else {
            logDebug("Keine textColor vorhanden");
          }
        } catch (error) {
          logDebug("Fehler beim Verarbeiten der Textfarbe: ".concat(error.message));
          logDebug("Error stack: ".concat(error.stack));
        }
      }

      // Fills (nur für Nicht-Text-Layer)
      if (!isTextLayer) {
        var fillsId = "fills";
        addCheckbox("Fills", fillsId, 1);
        hierarchy["layer-title"].push(fillsId);
        hierarchy[fillsId] = [];

        // Null check for fills
        if (layer.style.fills && Array.isArray(layer.style.fills)) {
          layer.style.fills.forEach(function (fill, index) {
            try {
              var fillId = "fill".concat(index);
              addCheckbox("Fill ".concat(index), fillId, 2);
              hierarchy[fillsId].push(fillId);
              hierarchy[fillId] = [];
              var fillColor = fill.sketchObject.color();
              if (!fillColor) {
                logDebug("Fill ".concat(index, " hat keine Farbe."));
                return;
              }
              var fillHex = rgbToHex(fillColor.red(), fillColor.green(), fillColor.blue());
              var fillSwatch = swatchForMSColor(fillColor);
              var fillTitle = fillSwatch ? "Color: ".concat(fillSwatch.name, "\n(").concat(fillHex, ", ").concat(fillSwatch.isImported() ? fillSwatch.libraryName() : "Lokal", ")") : "Color: ".concat(fillHex);
              addCheckbox(fillTitle, "".concat(fillId, "-color"), 3, NSColor.colorWithRed_green_blue_alpha(fillColor.red(), fillColor.green(), fillColor.blue(), fillColor.alpha()));
              hierarchy["".concat(fillId, "-color")] = {
                swatch: fillSwatch,
                color: fillColor
              };
              hierarchy[fillId].push("".concat(fillId, "-color"));
            } catch (error) {
              logDebug("Fehler beim Verarbeiten von Fill ".concat(index, ": ").concat(error.message));
            }
          });
        }
      }

      // Borders (nur für Nicht-Text-Layer)
      if (!isTextLayer) {
        var bordersId = "borders";
        addCheckbox("Borders", bordersId, 1);
        hierarchy["layer-title"].push(bordersId);
        hierarchy[bordersId] = [];

        // Null check for borders
        if (layer.style.borders && Array.isArray(layer.style.borders)) {
          layer.style.borders.forEach(function (border, index) {
            try {
              var _layer$style$borderOp;
              var borderId = "border".concat(index);
              addCheckbox("Border ".concat(index), borderId, 2);
              hierarchy[bordersId].push(borderId);
              hierarchy[borderId] = [];
              var borderColor = border.sketchObject.color();
              if (!borderColor) {
                logDebug("Border ".concat(index, " hat keine Farbe."));
                return;
              }
              var borderHex = rgbToHex(borderColor.red(), borderColor.green(), borderColor.blue());
              var borderSwatch = swatchForMSColor(borderColor);
              var borderTitle = borderSwatch ? "Color: ".concat(borderSwatch.name, "\n(").concat(borderHex, ", ").concat(borderSwatch.isImported() ? borderSwatch.libraryName() : "Lokal", ")") : "Color: ".concat(borderHex);
              addCheckbox(borderTitle, "".concat(borderId, "-color"), 3, NSColor.colorWithRed_green_blue_alpha(borderColor.red(), borderColor.green(), borderColor.blue(), borderColor.alpha()));
              hierarchy["".concat(borderId, "-color")] = {
                swatch: borderSwatch,
                color: borderColor
              };
              hierarchy[borderId].push("".concat(borderId, "-color"));
              var lineThickness = border.thickness || 0;
              addCheckbox("Width: ".concat(lineThickness, "px"), "".concat(borderId, "-thickness"), 3);
              hierarchy["".concat(borderId, "-thickness")] = {
                thickness: lineThickness
              };
              hierarchy[borderId].push("".concat(borderId, "-thickness"));
              var dashPattern = ((_layer$style$borderOp = layer.style.borderOptions) === null || _layer$style$borderOp === void 0 ? void 0 : _layer$style$borderOp.dashPattern) || [];
              addCheckbox("Dash: [".concat(dashPattern.join(", "), "]"), "".concat(borderId, "-dash"), 3);
              hierarchy["".concat(borderId, "-dash")] = {
                dashPattern: dashPattern
              };
              hierarchy[borderId].push("".concat(borderId, "-dash"));
            } catch (error) {
              logDebug("Fehler beim Verarbeiten von Border ".concat(index, ": ").concat(error.message));
            }
          });
        }
      } // end if (!isTextLayer)
    } // end if (hasAnyStyleProp)

    // For SymbolInstances: show Overrides grouped by sub-layer
    var groupNames = Object.keys(overrideGroups);
    if (isSymbolInstance && groupNames.length > 0) {
      if (!hasAnyStyleProp) {
        // Need to initialise hierarchy key since style section was skipped
        hierarchy["layer-title"] = [];
      }
      // === Gebuendelte Sicht: Farben und Texte ===
      // Dieselben Eintraege wie im Baum, nur nach Art gruppiert. Wer alle
      // Farbwerte eines Symbols sucht, soll sie nicht aus vier Ebenen
      // zusammenklauben muessen.
      var allEntries = groupNames.reduce(function (acc, g) {
        return acc.concat(overrideGroups[g]);
      }, []);
      var colorEntries = allEntries.filter(function (e) {
        return e.type === 'overrideColor';
      });
      var textEntries = allEntries.filter(function (e) {
        return e.prop === 'stringValue';
      });
      var bundleIdx = 0;
      var addBundle = function addBundle(label, entries, idPrefix) {
        if (entries.length === 0) return;
        var rootId = "".concat(idPrefix, "-root");
        addCheckbox("".concat(label, " (").concat(entries.length, ")"), rootId, 0);
        hierarchy["layer-title"].push(rootId);
        hierarchy[rootId] = [];
        entries.forEach(function (entry) {
          var bId = "".concat(idPrefix, "-").concat(bundleIdx++);
          var nsColor = null;
          if (entry.type === 'overrideColor' && entry.color) {
            nsColor = NSColor.colorWithRed_green_blue_alpha(entry.color.red, entry.color.green, entry.color.blue, entry.color.alpha);
          }
          // Herkunft vor Element: aus welcher Library ein Farbfeld stammt, ist
          // wichtiger als auf welchem Layer es sitzt — das Element steht im
          // Tooltip. Bei Texten gibt es keine Herkunft, dort bleibt der Layer.
          var originText = entry.type === 'overrideColor' && entry.swatch ? entry.swatch.isImported() ? entry.swatch.libraryName() : 'Lokal' : shortenPath(entry.affName);
          var title = "".concat(entry.displayName, "  \xB7  ").concat(originText);
          addCheckbox(title + (entry.isDefault === false ? '  (geändert)' : ''), bId, 2, nsColor, {
            tooltip: [entry.tooltip, "Element: ".concat(entry.affName)].filter(Boolean).join('\n'),
            fullTitle: "".concat(entry.displayName, "  \xB7  ").concat(originText)
          });
          hierarchy[rootId].push(bId);
          hierarchy[bId] = entry.type === 'overrideColor' ? {
            swatch: entry.swatch,
            color: entry.color,
            isOverride: true,
            overrideProp: entry.prop,
            overridePath: entry.path,
            affectedLayerName: entry.affName,
            hexValue: entry.hexValue
          } : {
            isOverride: true,
            overrideProp: entry.prop,
            overridePath: entry.path,
            affectedLayerName: entry.affName,
            value: entry.value
          };
        });
      };
      addBundle('Farben', colorEntries, 'bundle-color');
      addBundle('Texte', textEntries, 'bundle-text');

      // Luft zwischen den Buendeln und dem vollstaendigen Baum: zwei getrennte
      // Sichten auf dieselben Daten, das soll man sehen.
      if (colorEntries.length || textEntries.length) {
        y -= smartSelectConfig.checkbox.rowHeight;
      }
      var overridesRootId = "overrides-root";
      addCheckbox("Alle Overrides nach Ebene", overridesRootId, 0);
      hierarchy["layer-title"].push(overridesRootId);
      hierarchy[overridesRootId] = [];
      var ovIdx = 0;
      groupNames.forEach(function (groupName, gIdx) {
        var groupId = "ov-group-".concat(gIdx);
        addCheckbox(shortenPath(groupName), groupId, 1, null, {
          tooltip: String(groupName),
          fullTitle: String(groupName)
        });
        hierarchy[overridesRootId].push(groupId);
        hierarchy[groupId] = [];
        overrideGroups[groupName].forEach(function (entry) {
          var ovId = "override-".concat(ovIdx);
          // For color overrides: show swatch rectangle
          var nsColor = null;
          if (entry.type === 'overrideColor' && entry.color) {
            nsColor = NSColor.colorWithRed_green_blue_alpha(entry.color.red, entry.color.green, entry.color.blue, entry.color.alpha);
          }
          // stringValue overrides get matchMode radio buttons + editable pattern field
          var isStringOverride = entry.prop === 'stringValue';
          // isDefault === true heisst: Sketch bietet den Override-Punkt an, er
          // wurde aber nie gesetzt. Nur ein tatsaechlich abweichender Wert wird
          // markiert — gemessen 260908: von 25 Override-Punkten war genau einer
          // wirklich ueberschrieben.
          addCheckbox(entry.displayName + (entry.isDefault === false ? '  (geändert)' : ''), ovId, 2, nsColor, isStringOverride ? {
            matchMode: true,
            patternValue: entry.value || '',
            tooltip: entry.tooltip,
            valueText: entry.valueText
          } : {
            tooltip: entry.tooltip,
            valueText: entry.valueText
          });
          hierarchy[groupId].push(ovId);
          if (entry.type === 'overrideColor') {
            hierarchy[ovId] = {
              type: 'overrideColor',
              prop: entry.prop,
              path: entry.path,
              value: entry.value,
              affName: entry.affName,
              swatch: entry.swatch,
              color: entry.color,
              hexValue: entry.hexValue
            };
          } else if (isStringOverride) {
            hierarchy[ovId] = {
              type: 'overrideString',
              prop: entry.prop,
              path: entry.path,
              value: entry.value,
              affName: entry.affName
            };
          } else {
            hierarchy[ovId] = {
              type: 'override',
              prop: entry.prop,
              path: entry.path,
              value: entry.value,
              affName: entry.affName
            };
          }
          ovIdx++;
        });
      });
    } else if (!hasAnyStyleProp && groupNames.length === 0) {
      // No style properties and no overrides — show hint
      hierarchy["layer-title"] = [];
      var noStyleLabel = NSTextField.alloc().initWithFrame(NSMakeRect(smartSelectConfig.checkbox.baseX - rightColumnXOffset, y, 260, 18));
      noStyleLabel.setBezeled(false);
      noStyleLabel.setDrawsBackground(false);
      noStyleLabel.setEditable(false);
      noStyleLabel.setSelectable(false);
      noStyleLabel.setTextColor(NSColor.secondaryLabelColor());
      noStyleLabel.setStringValue("(no style properties)");
      rightColumnTarget.addSubview(noStyleLabel);
    }

    // Angebotene Eintraege als Block ins Log — Vorlage zum Aussortieren.
    {
      logDebug('--- ANGEBOTENE EINTRAEGE (zum Aussortieren markieren) ---');
      offeredEntries.forEach(function (e) {
        logDebug("[ ] ".concat('  '.repeat(e.indent)).concat(e.title, "   <").concat(e.id, ">"));
      });
      logDebug("--- ENDE (".concat(offeredEntries.length, " Eintraege) ---"));
    }

    // Finalize scrollable right column: resize document view and scroll to top
    {
      var contentUsed = rightDocViewHeight - 40 - y + 20;
      var finalHeight = Math.max(rightScrollH, contentUsed);
      var yShift = rightDocViewHeight - finalHeight;
      if (yShift !== 0) {
        var subs = rightDocView.subviews();
        for (var _i = 0; _i < subs.count(); _i++) {
          var sv = subs.objectAtIndex(_i);
          var f = sv.frame();
          sv.setFrameOrigin(NSMakePoint(f.origin.x, f.origin.y - yShift));
        }
      }
      rightDocView.setFrameSize(NSMakeSize(rightScrollW, finalHeight));
      // Scroll to top
      var clipView = rightScrollView.contentView();
      clipView.scrollToPoint(NSMakePoint(0, Math.max(0, finalHeight - rightScrollH)));
      rightScrollView.reflectScrolledClipView(clipView);
    }

    // Collapse/expand logic for right column
    // Die rechte Spalte ist immer sichtbar — kein Auf- und Zuklappen mehr.
    rightScrollView.setHidden(false);

    // === Buttons "SELECT" und "CANCEL" ===
    var selectButton = NSButton.alloc().initWithFrame(NSMakeRect(smartSelectConfig.buttons.select.x, smartSelectConfig.buttons.y, smartSelectConfig.buttons.width, smartSelectConfig.buttons.height));
    // Title Case + Return-Kuerzel: AppKit zeichnet den Default-Button dann in
    // der Systemakzentfarbe. Ohne das wirkt jedes Panel wie ein Dialog von 2001.
    selectButton.setTitle("Auswählen");
    selectButton.setKeyEquivalent("\r");
    selectButton.setBezelStyle(NSRoundedBezelStyle);
    selectButton.setAction("callAction:");
    selectButton.setCOSJSTargetFunction(function () {
      try {
        var _processBatch = function processBatch() {
          if (progress.isCancelled()) {
            sketch.UI.message('Abgebrochen');
            try {
              progress.close();
            } catch (e) {
              logDebug("\u26A0\uFE0F Progress-Panel liess sich nach Abbruch nicht schliessen: ".concat(e));
            }
            try {
              COScript.currentCOScript().setShouldKeepAround_(false);
            } catch (e) {
              logDebug("\u26A0\uFE0F setShouldKeepAround(false) nach Abbruch fehlgeschlagen: ".concat(e));
            }
            return;
          }
          var BATCH_NODES = 250;
          var steps = 0;
          while (stack.length && steps++ < BATCH_NODES) {
            var candidate = stack.pop();
            processed += 1;
            try {
              var hit = findMatchingLayers([candidate], selectedProperties, matchModes, {
                skipChildren: true,
                patternOverrides: patternOverrides
              });
              if (hit && hit.length) matchingLayers.push(candidate);
            } catch (e) {
              logDebug("\u26A0\uFE0F Matching fehlgeschlagen fuer Kandidat \"".concat(candidate && candidate.name, "\": ").concat(e));
            }
            try {
              if (candidate && candidate.layers && Array.isArray(candidate.layers) && candidate.layers.length > 0) {
                for (var _i2 = candidate.layers.length - 1; _i2 >= 0; _i2--) {
                  stack.push(candidate.layers[_i2]);
                }
              }
            } catch (e) {
              logDebug("\u26A0\uFE0F Kinder von \"".concat(candidate && candidate.name, "\" nicht durchlaufbar: ").concat(e));
            }
          }
          try {
            progress.setProgress(null, "Scanne\u2026 ".concat(processed, " Layer | Treffer: ").concat(matchingLayers.length));
          } catch (e) {
            logDebug("\u26A0\uFE0F Progress-Text nicht aktualisierbar: ".concat(e));
          }
          if (stack.length) {
            defer(_processBatch);
            return;
          }
          try {
            progress.close();
          } catch (e) {
            logDebug("\u26A0\uFE0F Progress-Panel liess sich nicht schliessen: ".concat(e));
          }
          try {
            var currentPage = document.sketchObject.currentPage();
            currentPage.changeSelectionBySelectingLayers(matchingLayers.map(function (l) {
              return l.sketchObject;
            }));
          } catch (e) {
            logDebug("\u26A0\uFE0F Selektion konnte nicht gesetzt werden (".concat(matchingLayers.length, " Treffer): ").concat(e));
          }
          try {
            panel.close();
          } catch (e) {
            logDebug("\u26A0\uFE0F Panel liess sich nicht schliessen: ".concat(e));
          }
          try {
            COScript.currentCOScript().setShouldKeepAround_(false);
          } catch (e) {
            logDebug("\u26A0\uFE0F setShouldKeepAround(false) fehlgeschlagen: ".concat(e));
          }
        };
        var selectedScope = artboardButton.state() === NSOnState ? "Artboard" : "Document";
        logDebug("SELECT gedr\xFCckt. Auswahlbereich: ".concat(selectedScope));

        // Aktivierte Checkboxen extrahieren
        var selectedProperties = Object.keys(checkboxRefs).filter(function (id) {
          return checkboxRefs[id].state() === NSOnState;
        });
        logDebug("Ausgew\xE4hlte Eigenschaften: ".concat(JSON.stringify(selectedProperties)));

        // Match-Modi für Name/Text auslesen
        var matchModes = {};
        Object.keys(matchModeRefs).forEach(function (id) {
          if (selectedProperties.includes(id)) {
            var _radioGroup3 = matchModeRefs[id];
            var selectedIndex = _radioGroup3.selectedCell() ? _radioGroup3.cells().indexOfObject(_radioGroup3.selectedCell()) : 1;
            matchModes[id] = smartSelectConfig.matchMode.modes[selectedIndex].toLowerCase();
            logDebug("Match-Modus f\xFCr ".concat(id, ": ").concat(matchModes[id]));
          }
        });

        // Pattern-Overrides aus editierbaren Textfeldern auslesen
        var patternOverrides = {};
        Object.keys(patternFieldRefs).forEach(function (id) {
          if (selectedProperties.includes(id)) {
            var field = patternFieldRefs[id];
            patternOverrides[id] = String(field.stringValue());
            logDebug("Pattern-Override f\xFCr ".concat(id, ": \"").concat(patternOverrides[id], "\""));
          }
        });
        var searchRoots;
        if (selectedScope === "Artboard") {
          var container = getEnclosingContainerForArtboardScope(layer);
          if (!container) {
            sketch.UI.message(smartSelectConfig.errorMessages.noParentArtboard);
            logDebug("Kein Parent Artboard/Frame gefunden.");
            return;
          }
          searchRoots = container.layers;
        } else {
          searchRoots = document.pages.flatMap(function (page) {
            return page.layers;
          });
        }
        var progress = createProgressPanel({
          title: 'Smart Select',
          indeterminate: true,
          message: 'Suche…'
        });
        var defer = function defer(fn) {
          try {
            if (typeof setTimeout === 'function') {
              setTimeout(fn, 0);
              return;
            }
          } catch (e) {
            logDebug("\u26A0\uFE0F setTimeout nicht verfuegbar - laufe synchron weiter: ".concat(e));
          }
          fn();
        };
        var matchingLayers = [];
        var stack = (searchRoots || []).slice().reverse();
        var processed = 0;
        defer(_processBatch);
      } catch (error) {
        logDebug("Fehler bei SELECT: ".concat(error.message));
        sketch.UI.message(smartSelectConfig.errorMessages.generalError);
      }
    });
    panel.contentView().addSubview(selectButton);
    var cancelButton = NSButton.alloc().initWithFrame(NSMakeRect(smartSelectConfig.buttons.cancel.x, smartSelectConfig.buttons.y, smartSelectConfig.buttons.width, smartSelectConfig.buttons.height));
    cancelButton.setTitle("Abbrechen");
    cancelButton.setKeyEquivalent("\x1B"); // Esc
    cancelButton.setBezelStyle(NSRoundedBezelStyle);
    cancelButton.setAction("callAction:");
    cancelButton.setCOSJSTargetFunction(function () {
      panel.close();
      logDebug("CANCEL gedrückt. Fenster geschlossen.");
      try {
        COScript.currentCOScript().setShouldKeepAround_(false);
      } catch (e) {
        logDebug("\u26A0\uFE0F setShouldKeepAround(false) nach CANCEL fehlgeschlagen: ".concat(e));
      }
    });
    panel.contentView().addSubview(cancelButton);
  } catch (error) {
    logDebug("Kritischer Fehler: ".concat(error.message));
    sketch.UI.message(smartSelectConfig.errorMessages.generalError);
    COScript.currentCOScript().setShouldKeepAround_(false);
  }
}
function MochaJSDelegate(selectorHandlerDict) {
  var uniqueClassName = 'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString();
  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, NSObject);
  delegateClassDesc.registerClass();
  Object.keys(selectorHandlerDict).forEach(function (selectorString) {
    delegateClassDesc.addInstanceMethodWithSelector_function_(NSSelectorFromString(selectorString), selectorHandlerDict[selectorString]);
  });
  return NSClassFromString(uniqueClassName).new();
}
function rgbToHex(r, g, b) {
  return "#" + [r, g, b].map(function (value) {
    var hex = Math.round(value * 255).toString(16).toUpperCase(); // Großbuchstaben erzwingen
    return hex.length === 1 ? "0" + hex : hex;
  }).join("");
}
// Funktion zur Verarbeitung von MSColor und Swatches
function swatchForMSColor(nativeColor) {
  // Delegates to the shared resolver so there is exactly one swatch lookup in
  // the codebase. Keeps this function's original shape (name as a property,
  // isImported()/libraryName() as methods) because callers rely on it.
  try {
    var resolved = Object(_utils_swatchResolve__WEBPACK_IMPORTED_MODULE_2__["resolveNativeColor"])(nativeColor);
    if (!resolved || !resolved.name) return null;
    return {
      name: resolved.name,
      isImported: function isImported() {
        return !!resolved.isImported;
      },
      libraryName: function libraryName() {
        return resolved.libraryName;
      }
    };
  } catch (e) {
    logDebug("\u26A0\uFE0F swatchForMSColor: Aufloesung fehlgeschlagen: ".concat(e));
    return null;
  }
}

/**
 * Resolve an override color value into { color: {red,green,blue,alpha}, swatch, hex }.
 *
 * The native override value is asked FIRST, because the JS API drops the swatch
 * binding: measured in Sketch 2026.1.2 (260908), `ov.value` for a colour
 * override bound to the library swatch "SP_380kV" is the bare string
 * "#d46dedff", while `ov.sketchObject.value()` is an MSImmutableColor that does
 * carry swatchID. Reading only the JS value cannot name a swatch at all — not
 * because the binding is missing, but because that layer of the API discards it.
 *
 * The four string/object formats below remain as the fallback for values that
 * reach us without a native object.
 */
/**
 * Long symbol and layer paths ("B_UI/general/Button/websdk_arrowbutton") are
 * shown by their last segment only; the full path lives in the tooltip. The
 * user can switch this off with the Gekürzt/Vollständig control.
 */
/**
 * Sketch's raw override property names are API vocabulary: "opacity:fill-0",
 * "preservesSpaceWhenHidden". Six of the eleven seen on one test symbol carry a
 * colon of their own, which is also why the name has to be translated before a
 * colon can separate it from its value.
 *
 * A lookup table would be wrong here: Sketch adds override points with every
 * release and the names are documented nowhere, so any list is incomplete the
 * day it is written — and a half-translated panel reads worse than an
 * untranslated one. The STRUCTURE does the work instead:
 *
 *   <what>:<where>-<index>   ->  "<What> <Where> <index+1>"
 *   camelCaseName            ->  "Camel Case Name"
 *
 * WORDS below only refines frequent terms. Anything unknown still comes out
 * structured and capitalised, never raw with a colon in it.
 */
var PROPERTY_WORDS = {
  color: 'Farbe',
  opacity: 'Deckkraft',
  blendMode: 'Füllmethode',
  fill: 'Fläche',
  border: 'Kontur',
  text: 'Text',
  shadow: 'Schatten',
  innerShadow: 'Innerer Schatten'
};
var PROPERTY_FIXED = {
  isVisible: 'Sichtbar',
  preservesSpaceWhenHidden: 'Platz bleibt erhalten',
  verticalSizing: 'Vertikal',
  horizontalSizing: 'Horizontal',
  symbolID: 'Symbol',
  stringValue: 'Text',
  layerStyle: 'Ebenenstil',
  textStyle: 'Textstil'
};

/** "someName" -> "Some Name"; unbekannte Woerter bleiben erkennbar. */
function humanizeToken(token) {
  var t = String(token || '');
  if (PROPERTY_WORDS[t]) return PROPERTY_WORDS[t];
  var spaced = t.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ').trim();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}
function propertyLabel(prop) {
  var p = String(prop || '');
  if (PROPERTY_FIXED[p]) return PROPERTY_FIXED[p];

  // Strukturell: "was:worauf-index", beliebig viele Doppelpunkt-Segmente.
  if (p.indexOf(':') !== -1) {
    return p.split(':').map(function (seg) {
      var m = seg.match(/^(.*?)-(\d+)$/);
      if (m) return "".concat(humanizeToken(m[1]), " ").concat(parseInt(m[2], 10) + 1);
      // Ein Segment, das NUR eine Zahl ist, ist ebenfalls ein Index
      // ("shadow:0" = erster Schatten) — nullbasiert wie die anderen.
      if (/^\d+$/.test(seg)) return String(parseInt(seg, 10) + 1);
      return humanizeToken(seg);
    }).join(' ');
  }
  var m = p.match(/^(.*?)-(\d+)$/);
  if (m) return "".concat(humanizeToken(m[1]), " ").concat(parseInt(m[2], 10) + 1);
  return humanizeToken(p);
}

/**
 * Values as Sketch reports them are raw too: sizing modes are numbers, booleans
 * are 0/1, opacity is a fraction. Shown as they are, a row says nothing.
 */
function valueLabel(prop, value) {
  var p = String(prop || '');
  var v = String(value == null ? '' : value);
  if (p === 'isVisible' || p === 'preservesSpaceWhenHidden') {
    return v === '1' ? 'Ja' : v === '0' ? 'Nein' : v;
  }
  if (p === 'verticalSizing' || p === 'horizontalSizing') {
    // sketch/dom exposes these as FlexSizing (Fixed/Fit/Fill/Relative). The
    // numeric order is NOT documented, so it is read from the enum instead of
    // hardcoded — an invented mapping would label layers wrongly and look
    // authoritative doing it.
    try {
      var _require4 = __webpack_require__(/*! sketch/dom */ "sketch/dom"),
        FlexSizing = _require4.FlexSizing;
      if (FlexSizing) {
        var names = {
          Fixed: 'Fest',
          Fit: 'Inhalt',
          Fill: 'Füllen',
          Relative: 'Relativ'
        };
        for (var _i3 = 0, _Object$keys = Object.keys(FlexSizing); _i3 < _Object$keys.length; _i3++) {
          var key = _Object$keys[_i3];
          if (String(FlexSizing[key]) === v) return names[key] || key;
        }
      }
    } catch (e) {
      logDebug("FlexSizing nicht lesbar, zeige Rohwert \"".concat(v, "\": ").concat(e));
    }
    return v;
  }
  if (p.indexOf('opacity:') === 0) {
    var n = parseFloat(v);
    return isNaN(n) ? v : "".concat(Math.round(n * 100), " %");
  }
  if (p.indexOf('blendMode:') === 0) {
    return v === '0' ? 'Normal' : v;
  }
  return v;
}
function shortenPath(value) {
  var str = String(value == null ? '' : value);
  if (!pathShortened) return str;
  var parts = str.split('/');
  return parts.length > 1 ? parts[parts.length - 1] : str;
}
function resolveOverrideColor(overrideValue, symbolInstance, override) {
  var color = null;
  var swatch = null;
  var hex = null;

  // Native first — the only path that can see a swatch reference.
  try {
    var nativeOv = override && override.sketchObject;
    var nativeColor = nativeOv && typeof nativeOv.value === 'function' ? nativeOv.value() : null;
    if (!nativeColor) {
      logDebug("\u21A9\uFE0E kein natives Override-Objekt f\xFCr prop=\"".concat(override && override.property, "\": sketchObject=").concat(!!nativeOv, " value-typ=").concat(nativeOv ? _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_1___default()(nativeOv.value) : '-', " \u2014 nutze Wertformate"));
    }
    if (nativeColor) {
      // documentData must be passed in: an MSImmutableColor does not carry one,
      // so resolveNativeColor's own lookup would come up empty and the swatch
      // would stay unnamed even though its swatchID is right there.
      var docData = document && document.sketchObject ? document.sketchObject.documentData() : null;
      var resolved = Object(_utils_swatchResolve__WEBPACK_IMPORTED_MODULE_2__["resolveNativeColor"])(nativeColor, docData);
      if (resolved) {
        color = {
          red: resolved.rgba.r,
          green: resolved.rgba.g,
          blue: resolved.rgba.b,
          alpha: resolved.rgba.a
        };
        if (resolved.name) {
          swatch = {
            name: resolved.name,
            isImported: function isImported() {
              return !!resolved.isImported;
            },
            libraryName: function libraryName() {
              return resolved.libraryName;
            }
          };
          logDebug("   \u2705 Swatch \xFCber native swatchID: \"".concat(resolved.name, "\"").concat(resolved.isImported ? " (Library: ".concat(resolved.libraryName, ")") : ' (lokal)'));
        }
        hex = rgbToHex(color.red, color.green, color.blue);
        return {
          color: color,
          swatch: swatch,
          hex: hex
        };
      }
    }
  } catch (e) {
    logDebug("\u26A0\uFE0F Nativer Override-Farbzugriff fehlgeschlagen f\xFCr prop=\"".concat(override && override.property, "\": ").concat(e, " \u2014 falle auf Wertformate zur\xFCck"));
  }
  try {
    // Pattern 1: Direct color object { _class: "color", swatchID: ... }
    if (overrideValue && _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_1___default()(overrideValue) === 'object' && overrideValue._class === 'color') {
      color = {
        red: overrideValue.red || 0,
        green: overrideValue.green || 0,
        blue: overrideValue.blue || 0,
        alpha: overrideValue.alpha != null ? overrideValue.alpha : 1
      };
      if (overrideValue.swatchID) {
        try {
          var _docData3 = document.sketchObject.documentData();
          // Local swatches
          var localSwatches = _docData3.documentSwatches();
          for (var i = 0; i < localSwatches.count(); i++) {
            var ns = localSwatches.objectAtIndex(i);
            if (ns.objectID().isEqualToString(overrideValue.swatchID)) {
              var sc = ns.color();
              swatch = {
                name: String(ns.name()),
                isImported: function isImported() {
                  return false;
                },
                libraryName: function libraryName() {
                  return 'Lokal';
                }
              };
              color = {
                red: sc.red(),
                green: sc.green(),
                blue: sc.blue(),
                alpha: sc.alpha()
              };
              break;
            }
          }
          // Foreign swatches
          if (!swatch) {
            var foreignSwatches = _docData3.foreignSwatches();
            var _loop = function _loop() {
              var fs = foreignSwatches.objectAtIndex(_i4);
              var ls = fs.localSwatch();
              if (ls.objectID().isEqualToString(overrideValue.swatchID)) {
                var _sc = ls.color();
                var libName = String(fs.sourceLibraryName());
                swatch = {
                  name: String(ls.name()),
                  isImported: function isImported() {
                    return true;
                  },
                  libraryName: function libraryName() {
                    return libName;
                  }
                };
                color = {
                  red: _sc.red(),
                  green: _sc.green(),
                  blue: _sc.blue(),
                  alpha: _sc.alpha()
                };
                return 1; // break
              }
            };
            for (var _i4 = 0; _i4 < foreignSwatches.count(); _i4++) {
              if (_loop()) break;
            }
          }
        } catch (e) {
          logDebug("resolveOverrideColor swatchID error: ".concat(e));
        }
      }
      if (!swatch) {
        swatch = _findSwatchByColorMatch(color.red, color.green, color.blue, color.alpha);
      }
    }
    // Pattern 2: RGBA string "(r:1.000000 g:0.254902 b:0.047059 a:1.000000)"
    else if (typeof overrideValue === 'string' && overrideValue.match(/^\(r:[\d.]+\s+g:[\d.]+\s+b:[\d.]+\s+a:[\d.]+\)$/)) {
      var m = overrideValue.match(/\(r:([\d.]+)\s+g:([\d.]+)\s+b:([\d.]+)\s+a:([\d.]+)\)/);
      if (m) {
        color = {
          red: parseFloat(m[1]),
          green: parseFloat(m[2]),
          blue: parseFloat(m[3]),
          alpha: parseFloat(m[4])
        };
        swatch = _findSwatchByColorMatch(color.red, color.green, color.blue, color.alpha);
      }
    }
    // Pattern 3: MSImmutableColor string "<MSImmutableColor: 0x...>"
    else if (typeof overrideValue === 'string' && overrideValue.match(/^<MSImmutableColor:/)) {
      // Try native override value access
      try {
        var nativeOverrides = symbolInstance.sketchObject.availableOverrides();
        if (nativeOverrides) {
          for (var _i5 = 0; _i5 < Math.min(nativeOverrides.count(), 50); _i5++) {
            var candidate = nativeOverrides.objectAtIndex(_i5);
            if (candidate.overrideName && candidate.overrideName() === override.property) {
              var nv = candidate.value();
              if (nv && nv.red) {
                var r = typeof nv.red === 'function' ? nv.red() : nv.red;
                var g = typeof nv.green === 'function' ? nv.green() : nv.green;
                var b = typeof nv.blue === 'function' ? nv.blue() : nv.blue;
                var a = nv.alpha ? typeof nv.alpha === 'function' ? nv.alpha() : nv.alpha : 1.0;
                color = {
                  red: r,
                  green: g,
                  blue: b,
                  alpha: a
                };
                swatch = swatchForMSColor(nv) || _findSwatchByColorMatch(r, g, b, a);
              }
              break;
            }
          }
        }
      } catch (e) {
        logDebug("resolveOverrideColor native access error: ".concat(e));
      }

      // Fallback: look up from symbol master layer
      if (!color && symbolInstance.master) {
        try {
          var _findLayer = function findLayer(l, id, depth) {
            if (depth > 10) return null;
            if (l.id === id) return l;
            if (l.layers) {
              var _iterator = _createForOfIteratorHelper(l.layers),
                _step;
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var sub = _step.value;
                  var f = _findLayer(sub, id, depth + 1);
                  if (f) return f;
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            }
            return null;
          };
          var targetId = override.path;
          var targetLayer = _findLayer(symbolInstance.master, targetId, 0);
          if (targetLayer) {
            var _targetLayer$style, _targetLayer$style2;
            var _nativeColor = null;
            if (override.property === 'color:fill-0' && (_targetLayer$style = targetLayer.style) !== null && _targetLayer$style !== void 0 && (_targetLayer$style = _targetLayer$style.fills) !== null && _targetLayer$style !== void 0 && _targetLayer$style[0]) {
              var _targetLayer$style$fi;
              _nativeColor = (_targetLayer$style$fi = targetLayer.style.fills[0]) === null || _targetLayer$style$fi === void 0 || (_targetLayer$style$fi = _targetLayer$style$fi.sketchObject) === null || _targetLayer$style$fi === void 0 ? void 0 : _targetLayer$style$fi.color();
            } else if (override.property === 'color:border-0' && (_targetLayer$style2 = targetLayer.style) !== null && _targetLayer$style2 !== void 0 && (_targetLayer$style2 = _targetLayer$style2.borders) !== null && _targetLayer$style2 !== void 0 && _targetLayer$style2[0]) {
              var _targetLayer$style$bo;
              _nativeColor = (_targetLayer$style$bo = targetLayer.style.borders[0]) === null || _targetLayer$style$bo === void 0 || (_targetLayer$style$bo = _targetLayer$style$bo.sketchObject) === null || _targetLayer$style$bo === void 0 ? void 0 : _targetLayer$style$bo.color();
            }
            if (_nativeColor) {
              var _r2 = typeof _nativeColor.red === 'function' ? _nativeColor.red() : _nativeColor.red;
              var _g2 = typeof _nativeColor.green === 'function' ? _nativeColor.green() : _nativeColor.green;
              var _b2 = typeof _nativeColor.blue === 'function' ? _nativeColor.blue() : _nativeColor.blue;
              var _a2 = _nativeColor.alpha ? typeof _nativeColor.alpha === 'function' ? _nativeColor.alpha() : _nativeColor.alpha : 1;
              color = {
                red: _r2 || 0,
                green: _g2 || 0,
                blue: _b2 || 0,
                alpha: _a2 || 1
              };
              swatch = swatchForMSColor(_nativeColor) || _findSwatchByColorMatch(color.red, color.green, color.blue, color.alpha);
            }
          }
        } catch (e) {
          logDebug("resolveOverrideColor master fallback error: ".concat(e));
        }
      }
    }
    // Pattern 4: Hex string "#RRGGBB" or "#RRGGBBAA".
    // Measured (Sketch 2026.1.2, 260908): the JS API hands colour overrides over
    // as 8-digit hex — "#d46dedff". The old pattern anchored on exactly 6 digits,
    // so every real colour override fell through all four patterns and resolved
    // to null. That is the "override colours are missing" bug.
    else if (typeof overrideValue === 'string' && overrideValue.match(/^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$/)) {
      var h = overrideValue;
      color = {
        red: parseInt(h.substr(1, 2), 16) / 255,
        green: parseInt(h.substr(3, 2), 16) / 255,
        blue: parseInt(h.substr(5, 2), 16) / 255,
        alpha: h.length === 9 ? parseInt(h.substr(7, 2), 16) / 255 : 1
      };
      swatch = _findSwatchByColorMatch(color.red, color.green, color.blue, color.alpha);
    }
    if (color) {
      hex = rgbToHex(color.red, color.green, color.blue);
    }
  } catch (e) {
    logDebug("resolveOverrideColor error: ".concat(e));
  }
  return {
    color: color,
    swatch: swatch,
    hex: hex
  };
}

/** Find swatch by color-matching across document + foreign swatches (tolerance 0.001) */
function _findSwatchByColorMatch(r, g, b, a) {
  // Deliberately does NOT match by colour value any more.
  //
  // Naming a swatch from its RGBA is a guess: two swatches can carry the same
  // value, and a free colour that happens to equal one would be labelled as if
  // it referenced it. Smart Select then SELECTS by that guessed name (see the
  // override comparison further down), so a wrong guess silently changes what
  // the user gets. Swatches are resolved by identity only — see
  // utils/swatchResolve.js, which states the same rule at the top.
  //
  // A colour that carries no swatchID simply has no swatch. That is a fact
  // about the colour, not a lookup failure.
  logDebug("\u21A9\uFE0E kein swatchID an dieser Farbe (rgba=".concat(r, ",").concat(g, ",").concat(b, ",").concat(a, ") \u2014 keine Swatch-Zuordnung, Farbvergleich ist bewusst nicht erlaubt"));
  return null;
}
function findMatchingLayers(layers, selectedProperties) {
  var matchModes = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var opts = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
  var matchingLayers = [];
  var patternOverrides = opts.patternOverrides || {};
  if (!layers || !Array.isArray(layers)) {
    logDebug("findMatchingLayers: Keine gültigen Layer übergeben.");
    return matchingLayers;
  }
  layers.forEach(function (layer) {
    try {
      logDebug("\uD83D\uDD0D Pr\xFCfe Layer: \"".concat(layer.name, "\" (Typ: ").concat(layer.type, ")"));
      var matches = true;

      // Überprüfen, ob der Layer die ausgewählten Eigenschaften erfüllt
      logDebug("  Starte Property-Pr\xFCfung f\xFCr \"".concat(layer.name, "\", Properties: ").concat(JSON.stringify(selectedProperties)));
      selectedProperties.forEach(function (propertyId) {
        if (!matches) {
          logDebug("  Abbruch wegen matches=false");
          return; // Abbrechen, wenn bereits nicht übereinstimmend
        }
        logDebug("  Pr\xFCfe Property: ".concat(propertyId, " f\xFCr Layer \"").concat(layer.name, "\""));
        var property = hierarchy[propertyId];

        // Überspringe übergeordnete Ebenen wie "borders", "fills", "layer-title", "layer-props-root"
        if (!property || Array.isArray(property)) {
          logDebug("  Property ".concat(propertyId, " \xFCbersprungen (kein Property-Objekt oder Array)"));
          return; // Keine Eigenschaften zu vergleichen
        }

        // === LAYER PROPERTIES ===
        if (property.type === 'layerName') {
          var mode = matchModes[propertyId] || 'substring';
          var pattern = patternOverrides[propertyId] !== undefined ? patternOverrides[propertyId] : property.value;
          var layerName = layer.name;
          logDebug("  Layer Name Check: \"".concat(layerName, "\" vs pattern \"").concat(pattern, "\" (mode: ").concat(mode, ")"));
          if (mode === 'exact') {
            if (layerName !== pattern) {
              matches = false;
              logDebug("  \u274C Exact match failed");
            }
          } else if (mode === 'substring') {
            if (!layerName.includes(pattern)) {
              matches = false;
              logDebug("  \u274C Substring match failed");
            }
          } else if (mode === 'regex') {
            try {
              var regex = new RegExp(pattern);
              if (!regex.test(layerName)) {
                matches = false;
                logDebug("  \u274C Regex match failed");
              }
            } catch (e) {
              logDebug("  \u274C Invalid regex: ".concat(e.message));
              matches = false;
            }
          }
        } else if (property.type === 'layerType') {
          if (layer.type !== property.value) {
            matches = false;
            logDebug("  \u274C Layer Type: ".concat(layer.type, " !== ").concat(property.value));
          }
        } else if (property.type === 'symbolName') {
          if (layer.type !== 'SymbolInstance') {
            matches = false;
            logDebug("  \u274C Not a SymbolInstance");
          } else if (property.masterId) {
            // Compare by native symbolID (reliable, no master resolution needed)
            var candidateMasterId = null;
            try {
              var so = layer.sketchObject;
              var rawId = so.symbolID;
              candidateMasterId = String(typeof rawId === 'function' ? so.symbolID() : rawId);
            } catch (e) {
              logDebug("\u26A0\uFE0F symbolID des Kandidaten nicht lesbar fuer \"".concat(layer && layer.name, "\": ").concat(e));
            }
            if (candidateMasterId !== property.masterId) {
              matches = false;
              logDebug("  \u274C Symbol ID: \"".concat(candidateMasterId, "\" !== \"").concat(property.masterId, "\""));
            }
          } else {
            // Fallback: compare by master name
            var symbolName = '';
            try {
              symbolName = layer.master && layer.master.name || '';
            } catch (e) {
              logDebug("\u26A0\uFE0F Master-Name des Kandidaten nicht lesbar: ".concat(e));
            }
            if (symbolName !== property.value) {
              matches = false;
              logDebug("  \u274C Symbol Name: \"".concat(symbolName, "\" !== \"").concat(property.value, "\""));
            }
          }
        } else if (property.type === 'textContent') {
          var _mode = matchModes[propertyId] || 'substring';
          var _pattern = patternOverrides[propertyId] !== undefined ? patternOverrides[propertyId] : property.value;
          var textContent = layer.type === 'Text' ? layer.text || '' : '';
          logDebug("  Text Content Check: \"".concat(textContent, "\" vs pattern \"").concat(_pattern, "\" (mode: ").concat(_mode, ")"));
          if (_mode === 'exact') {
            if (textContent !== _pattern) {
              matches = false;
              logDebug("  \u274C Exact match failed");
            }
          } else if (_mode === 'substring') {
            if (!textContent.includes(_pattern)) {
              matches = false;
              logDebug("  \u274C Substring match failed");
            }
          } else if (_mode === 'regex') {
            try {
              var _regex = new RegExp(_pattern);
              if (!_regex.test(textContent)) {
                matches = false;
                logDebug("  \u274C Regex match failed");
              }
            } catch (e) {
              logDebug("  \u274C Invalid regex: ".concat(e.message));
              matches = false;
            }
          }
        } else if (property.type === 'overrideColor') {
          // === OVERRIDE COLOR MATCHING ===
          if (layer.type !== 'SymbolInstance' || !layer.overrides) {
            matches = false;
            logDebug("  \u274C Not a SymbolInstance or no overrides");
            return;
          }
          var candidateOv = layer.overrides.find(function (ov) {
            return ov.path === property.path;
          });
          if (!candidateOv) {
            matches = false;
            logDebug("  \u274C Override path \"".concat(property.path, "\" not found"));
            return;
          }
          // Resolve the candidate's color and compare
          var candidateResolved = resolveOverrideColor(candidateOv.value, layer, candidateOv);
          if (!candidateResolved.color || !property.color) {
            // Fallback to string comparison
            if (String(candidateOv.value) !== String(property.value)) {
              matches = false;
              logDebug("  \u274C Override color fallback string mismatch");
            }
          } else if (property.swatch && candidateResolved.swatch) {
            // Compare by swatch name
            if (property.swatch.name !== candidateResolved.swatch.name) {
              matches = false;
              logDebug("  \u274C Override swatch name mismatch: \"".concat(candidateResolved.swatch.name, "\" !== \"").concat(property.swatch.name, "\""));
            }
          } else {
            // Compare by hex value
            if (property.hexValue !== candidateResolved.hex) {
              matches = false;
              logDebug("  \u274C Override color hex mismatch: \"".concat(candidateResolved.hex, "\" !== \"").concat(property.hexValue, "\""));
            }
          }
        } else if (property.type === 'overrideString') {
          // === STRING OVERRIDE MATCHING (with matchMode support) ===
          if (layer.type !== 'SymbolInstance' || !layer.overrides) {
            matches = false;
            logDebug("  \u274C Not a SymbolInstance or no overrides");
            return;
          }
          var _candidateOv = layer.overrides.find(function (ov) {
            return ov.path === property.path;
          });
          if (!_candidateOv) {
            matches = false;
            logDebug("  \u274C Override path \"".concat(property.path, "\" not found"));
            return;
          }
          var _mode2 = matchModes[propertyId] || 'substring';
          var _pattern2 = patternOverrides[propertyId] !== undefined ? patternOverrides[propertyId] : property.value;
          var candidateVal = String(_candidateOv.value || '');
          logDebug("  String Override Check: \"".concat(candidateVal, "\" vs pattern \"").concat(_pattern2, "\" (mode: ").concat(_mode2, ")"));
          if (_mode2 === 'exact') {
            if (candidateVal !== _pattern2) {
              matches = false;
              logDebug("  \u274C Exact match failed");
            }
          } else if (_mode2 === 'substring') {
            if (!candidateVal.includes(_pattern2)) {
              matches = false;
              logDebug("  \u274C Substring match failed");
            }
          } else if (_mode2 === 'regex') {
            try {
              var _regex2 = new RegExp(_pattern2);
              if (!_regex2.test(candidateVal)) {
                matches = false;
                logDebug("  \u274C Regex match failed");
              }
            } catch (e) {
              logDebug("  \u274C Invalid regex: ".concat(e.message));
              matches = false;
            }
          }
        } else if (property.type === 'override') {
          // === OVERRIDE MATCHING ===
          if (layer.type !== 'SymbolInstance' || !layer.overrides) {
            matches = false;
            logDebug("  \u274C Not a SymbolInstance or no overrides");
            return;
          }
          // Find the override with the same path in the candidate layer
          var _candidateOv2 = layer.overrides.find(function (ov) {
            return ov.path === property.path;
          });
          if (!_candidateOv2) {
            matches = false;
            logDebug("  \u274C Override path \"".concat(property.path, "\" not found"));
            return;
          }
          // Compare override values
          var _candidateVal = _candidateOv2.value;
          if (String(_candidateVal) !== String(property.value)) {
            matches = false;
            logDebug("  \u274C Override value mismatch: \"".concat(_candidateVal, "\" !== \"").concat(property.value, "\""));
          }
        } else if (propertyId.startsWith("fill")) {
          var _fill$sketchObject;
          // === STYLE PROPERTIES: Fills ===
          // Check if layer has style
          if (!layer.style) {
            matches = false;
            logDebug("  \u274C Layer has no style for fill check");
            return;
          }

          // Fill-Color-Vergleich
          var fillIndexMatch = propertyId.match(/fill(\d+)/);
          if (!fillIndexMatch) {
            matches = false;
            return;
          }
          var fillIndex = parseInt(fillIndexMatch[1], 10);
          if (isNaN(fillIndex) || !layer.style.fills || !layer.style.fills[fillIndex]) {
            matches = false;
            return;
          }
          var fill = layer.style.fills[fillIndex];
          var fillColor = (_fill$sketchObject = fill.sketchObject) === null || _fill$sketchObject === void 0 ? void 0 : _fill$sketchObject.color();
          if (!fillColor) {
            matches = false;
            return;
          }
          var layerSwatch = swatchForMSColor(fillColor);
          if (property.swatch) {
            if (!layerSwatch || layerSwatch.name !== property.swatch.name) {
              matches = false;
            }
          } else if (property.color) {
            if (fillColor.red() !== property.color.red() || fillColor.green() !== property.color.green() || fillColor.blue() !== property.color.blue()) {
              matches = false;
            }
          }
        } else if (propertyId.startsWith("textColor")) {
          // === STYLE PROPERTIES: Text Color ===
          // Check if layer has style
          if (!layer.style) {
            matches = false;
            logDebug("  \u274C Layer has no style for textColor check");
            return;
          }

          // Text-Color-Vergleich
          var layerTextColorHex = layer.style.textColor;
          if (!layerTextColorHex) {
            matches = false;
            return;
          }

          // Hole Swatch-Information über encodedAttributes
          var layerSwatchID = null;
          var layerSwatchName = null;
          try {
            var nativeStyle = layer.sketchObject.style();
            var textStyle = nativeStyle ? nativeStyle.textStyle() : null;
            if (textStyle) {
              var encodedAttrs = textStyle.encodedAttributes();
              if (encodedAttrs) {
                var colorAttr = encodedAttrs.objectForKey('MSAttributedStringColorAttribute');
                if (colorAttr) {
                  layerSwatchID = colorAttr.swatchID ? colorAttr.swatchID() : null;
                  if (layerSwatchID) {
                    var docData = getNativeDocumentData(layer && layer.sketchObject);
                    var nativeSwatch = docData && typeof docData.swatchWithID === 'function' ? docData.swatchWithID(layerSwatchID) : null;
                    if (!nativeSwatch) {
                      layerSwatchID = null;
                    } else {
                      var swatch = Swatch.from(nativeSwatch);
                      layerSwatchName = swatch.name;
                    }
                  }
                }
              }
            }
          } catch (e) {
            logDebug("Fehler beim Lesen der Swatch-Info: ".concat(e.message));
          }

          // Extrahiere Hex ohne Alpha für Farbvergleich
          var layerHex = layerTextColorHex.substring(0, 7).toLowerCase();

          // Unterscheide zwischen Swatch-Vergleich und Color-Vergleich
          if (property.type === 'swatch') {
            // Nur Swatch-Name vergleichen
            if (!layerSwatchName || layerSwatchName !== property.swatchName) {
              matches = false;
              logDebug("Text Swatch stimmt nicht \xFCberein: ".concat(layerSwatchName || "kein Swatch", " !== ").concat(property.swatchName));
            }
          } else if (property.type === 'color') {
            // Nur Hex-Wert vergleichen (egal ob Swatch oder nicht)
            if (layerHex !== property.hexValue) {
              matches = false;
              logDebug("Textfarbe (Hex) stimmt nicht \xFCberein: ".concat(layerHex, " !== ").concat(property.hexValue));
            }
          }
        } else if (propertyId.startsWith("border")) {
          // === STYLE PROPERTIES: Borders ===
          // Check if layer has style
          if (!layer.style) {
            matches = false;
            logDebug("  \u274C Layer has no style for border check");
            return;
          }

          // Border-Vergleich
          var borderIndexMatch = propertyId.match(/border(\d+)/);
          if (!borderIndexMatch) {
            matches = false;
            return;
          }
          var borderIndex = parseInt(borderIndexMatch[1], 10);
          logDebug("Border-Index: ".concat(borderIndex, " in layer: ").concat(layer.name));
          if (isNaN(borderIndex) || !layer.style.borders || !layer.style.borders[borderIndex]) {
            matches = false;
            logDebug("Border ".concat(borderIndex, " nicht gefunden."));
            return;
          }
          var border = layer.style.borders[borderIndex];
          logDebug("Possible Border ".concat(borderIndex, " found:"), border);
          if (propertyId.endsWith("color")) {
            var _border$sketchObject;
            var borderColor = (_border$sketchObject = border.sketchObject) === null || _border$sketchObject === void 0 ? void 0 : _border$sketchObject.color();
            if (!borderColor) {
              matches = false;
              return;
            }
            var _layerSwatch = swatchForMSColor(borderColor);

            // Swatch-Vergleich
            if (property.swatch) {
              if (!_layerSwatch || _layerSwatch.name !== property.swatch.name) {
                matches = false;
                logDebug("Swatch stimmt nicht \xFCberein: ".concat(_layerSwatch ? _layerSwatch.name : "kein Swatch gefunden"));
              }
            } else if (property.color) {
              // Farbvergleich mit Hex-Werten
              var _layerHex = rgbToHex(borderColor.red(), borderColor.green(), borderColor.blue());
              var propertyHex = rgbToHex(property.color.red(), property.color.green(), property.color.blue());
              if (_layerHex !== propertyHex) {
                matches = false;
                logDebug("Farbe stimmt nicht \xFCberein: ".concat(_layerHex, " !== ").concat(propertyHex));
              }
            }
          } else if (propertyId.endsWith("thickness")) {
            var layerThickness = border.thickness || 0;
            if (layerThickness !== property.thickness) {
              matches = false;
              logDebug("Linienst\xE4rke stimmt nicht \xFCberein: ".concat(layerThickness));
            }
          } else if (propertyId.endsWith("dash")) {
            var _layer$style$borderOp2;
            var layerDashPattern = ((_layer$style$borderOp2 = layer.style.borderOptions) === null || _layer$style$borderOp2 === void 0 ? void 0 : _layer$style$borderOp2.dashPattern) || [];
            if (!Array.isArray(layerDashPattern) || !Array.isArray(property.dashPattern)) {
              matches = false;
              logDebug("Dash Pattern ist kein Array: ".concat(layerDashPattern));
            } else if (layerDashPattern.length !== property.dashPattern.length) {
              matches = false;
              logDebug("Dash Pattern-L\xE4ngen stimmen nicht \xFCberein: ".concat(layerDashPattern.length, " !== ").concat(property.dashPattern.length));
            } else {
              for (var i = 0; i < layerDashPattern.length; i++) {
                if (layerDashPattern[i] !== property.dashPattern[i]) {
                  matches = false;
                  logDebug("Dash Pattern-Werte stimmen nicht \xFCberein: ".concat(layerDashPattern[i], " !== ").concat(property.dashPattern[i]));
                  break;
                }
              }
            }
          }
        }
        // === STYLE PROPERTIES: Appearance (Shared Layer Style) ===
        else if (property.type === 'appearance') {
          var nativeLayer = layer.sketchObject;
          var candidateStyleId = null;
          if (nativeLayer && nativeLayer.sharedStyleID) {
            candidateStyleId = typeof nativeLayer.sharedStyleID === 'function' ? nativeLayer.sharedStyleID() : nativeLayer.sharedStyleID;
          }
          if (property.styleId) {
            if (String(candidateStyleId || '') !== String(property.styleId)) {
              matches = false;
              logDebug("  \u274C Appearance StyleID ungleich: ".concat(candidateStyleId, " !== ").concat(property.styleId));
            }
          } else if (property.styleName) {
            // Resolve name for candidate if needed
            var candidateName = null;
            try {
              var docNative = document.sketchObject;
              var _docData4 = docNative && docNative.documentData ? typeof docNative.documentData === 'function' ? docNative.documentData() : docNative.documentData : null;
              if (_docData4 && _docData4.layerStyles) {
                var stylesContainer = typeof _docData4.layerStyles === 'function' ? _docData4.layerStyles() : _docData4.layerStyles;
                var nativeSharedStyles = stylesContainer && stylesContainer.sharedStyles ? typeof stylesContainer.sharedStyles === 'function' ? stylesContainer.sharedStyles() : stylesContainer.sharedStyles : [];
                var list = toArray(nativeSharedStyles) || [];
                var matchSS = list.find(function (ss) {
                  try {
                    var id = ss.objectID ? typeof ss.objectID === 'function' ? ss.objectID() : ss.objectID : null;
                    return String(id) === String(candidateStyleId);
                  } catch (e) {
                    logDebug("\u26A0\uFE0F SharedStyle-Vergleich des Kandidaten fehlgeschlagen: ".concat(e));
                    return false;
                  }
                });
                if (matchSS) {
                  candidateName = matchSS.name ? typeof matchSS.name === 'function' ? matchSS.name() : matchSS.name : null;
                }
              }
            } catch (e) {
              logDebug("\u26A0\uFE0F SharedStyle-Name des Kandidaten nicht aufloesbar: ".concat(e));
            }
            if ((candidateName || '') !== (property.styleName || '')) {
              matches = false;
              logDebug("  \u274C Appearance Name ungleich: ".concat(candidateName || '', " !== ").concat(property.styleName || ''));
            }
          }
        }
      });
      if (matches) {
        matchingLayers.push(layer);
        logDebug("\u2705 Layer \"".concat(layer.name, "\" matcht alle Eigenschaften!"));
      } else {
        logDebug("\u274C Layer \"".concat(layer.name, "\" matcht NICHT."));
      }

      // Rekursiv in Gruppen suchen
      if (!opts.skipChildren && layer.layers && Array.isArray(layer.layers) && layer.layers.length > 0) {
        logDebug("\uD83D\uDD04 Rekursive Suche in Kindern von \"".concat(layer.name, "\" (").concat(layer.layers.length, " Kinder)"));
        var childMatches = findMatchingLayers(layer.layers, selectedProperties, matchModes, opts);
        if (childMatches.length > 0) {
          logDebug("  Gefundene Kinder: ".concat(childMatches.map(function (c) {
            return c.name;
          }).join(", ")));
        }
        matchingLayers.push.apply(matchingLayers, _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(childMatches));
      }
    } catch (error) {
      logDebug("Fehler beim Verarbeiten von Layer ".concat(layer.name, ": ").concat(error.message));
    }
  });
  return matchingLayers;
}

// Default export: Smart Select without overrides (original fast version)
/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  runSmartSelect(false);
});

/***/ }),

/***/ "./src/ui/controls.js":
/*!****************************!*\
  !*** ./src/ui/controls.js ***!
  \****************************/
/*! exports provided: makeLabel, makeField, copyToClipboard, makeSwatch, makeCheckbox, makeRadioGroup, applyPanelChrome, addEscapeHatch, makeDefaultButton */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeLabel", function() { return makeLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeField", function() { return makeField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "copyToClipboard", function() { return copyToClipboard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeSwatch", function() { return makeSwatch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeCheckbox", function() { return makeCheckbox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeRadioGroup", function() { return makeRadioGroup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyPanelChrome", function() { return applyPanelChrome; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addEscapeHatch", function() { return addEscapeHatch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeDefaultButton", function() { return makeDefaultButton; });


/**
 * Shared native AppKit control builders (used by contrast & anonymize panels).
 * Bottom-left origin; system font / labelColor → auto light/dark.
 */
function makeLabel(frame, text) {
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var f = NSTextField.alloc().initWithFrame(frame);
  f.setEditable(false);
  f.setBordered(false);
  f.setBezeled(false);
  f.setDrawsBackground(false);
  f.setSelectable(opts.selectable || false);
  var size = opts.size || 12;
  // weight: 'medium' → the middle ground between regular and bold
  if (opts.weight === 'medium' && NSFont.systemFontOfSize_weight) {
    // NSFontWeightMedium = 0.23
    f.setFont(NSFont.systemFontOfSize_weight(size, 0.23));
  } else {
    f.setFont(opts.bold ? NSFont.boldSystemFontOfSize(size) : NSFont.systemFontOfSize(size));
  }
  if (opts.align === 'center') f.setAlignment(NSTextAlignmentCenter);else if (opts.align === 'right') f.setAlignment(NSTextAlignmentRight);
  if (opts.color) f.setTextColor(opts.color);
  f.setStringValue(text || '');
  return f;
}
function makeField(frame, text) {
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var f = NSTextField.alloc().initWithFrame(frame);
  f.setEditable(true);
  f.setBezeled(true);
  f.setBezelStyle(NSTextFieldRoundedBezel);
  f.setFont(NSFont.systemFontOfSize(11));
  if (opts.align === 'center') f.setAlignment(NSTextAlignmentCenter);
  f.setStringValue(text || '');
  return f;
}

// NOTE: no custom-subclassed views with JS-backed methods here (e.g. a flipped
// NSView whose isFlipped is a JS function). The render loop calls such methods
// outside our control and a stale Mocha block crashes Sketch over time. Lay out
// top-down with plain NSViews + inverted coordinates instead.

/** Copy a string to the general pasteboard. Returns true on success. */
function copyToClipboard(str) {
  try {
    var pb = NSPasteboard.generalPasteboard();
    pb.clearContents();
    pb.setString_forType_(String(str == null ? '' : str), NSPasteboardTypeString);
    return true;
  } catch (e) {
    return false;
  }
}
function makeSwatch(frame) {
  var v = NSView.alloc().initWithFrame(frame);
  v.setWantsLayer(true);
  v.layer().setCornerRadius(6);
  v.layer().setBorderWidth(1);
  v.layer().setBorderColor(NSColor.separatorColor().CGColor());
  return v;
}
function makeCheckbox(frame, title, checked) {
  var b = NSButton.alloc().initWithFrame(frame);
  b.setButtonType(NSButtonTypeSwitch);
  b.setTitle(title);
  b.setState(checked ? NSOnState : NSOffState);
  return b;
}

/**
 * Mutually-exclusive radio group. options: [{label, value}].
 * IMPORTANT: each group gets its OWN enclosing NSView — Cocoa groups
 * NSButtonTypeRadio buttons by superview, so groups sharing one superview would
 * act as a single group. The first option sits at parent-y `top`.
 * @returns { get(), set(value), view }
 */
function makeRadioGroup(parent, options, layout, onChange) {
  var x = layout.x,
    top = layout.top,
    rowH = layout.rowH,
    width = layout.width;
  var n = options.length;
  var height = n * rowH;
  var group = NSView.alloc().initWithFrame(NSMakeRect(x, top - (n - 1) * rowH, width, height));
  parent.addSubview(group);
  var buttons = [];
  var selected = options[0] && options[0].value;
  options.forEach(function (opt, idx) {
    var ly = height - (idx + 1) * rowH; // local y; option 0 at top
    var b = NSButton.alloc().initWithFrame(NSMakeRect(0, ly, width, rowH - 2));
    b.setButtonType(NSButtonTypeRadio);
    b.setTitle(opt.label);
    b.setState(idx === 0 ? NSOnState : NSOffState);
    b.setCOSJSTargetFunction(function () {
      selected = opt.value; // native radio handles visual exclusivity within this group
      if (onChange) onChange(opt.value);
    });
    group.addSubview(b);
    buttons.push(b);
  });
  return {
    get: function get() {
      return selected;
    },
    set: function set(v) {
      var i = options.findIndex(function (o) {
        return o.value === v;
      });
      if (i >= 0) {
        buttons[i].setState(NSOnState);
        selected = v;
      }
    },
    view: group
  };
}

// ---------------------------------------------------------------------------
// Panel-Grundausstattung — zentral, damit die Werkzeuge gleich aussehen.
// Eingeführt 260909, als der smartSelect-Umbau zeigte, dass jedes Panel diese
// Dinge einzeln nachbaute, oder eben gar nicht hatte.
// ---------------------------------------------------------------------------

/**
 * Gibt einem Panel den Material-Untergrund und eine zurückhaltende Titelleiste.
 *
 * NSVisualEffectView ist eine System-View ohne JS-implementierte Methoden; das
 * Verbot aus sketch-plugin-gotchas §1 betrifft nur eigene Subklassen mit
 * JS-backed render/layout/hitTest. Jeder Schritt ist einzeln abgesichert: eine
 * fehlende API darf niemals das Panel kosten.
 */
function applyPanelChrome(panel, log) {
  var note = function note(msg) {
    if (log) log(msg);
  };
  try {
    panel.setTitlebarAppearsTransparent(true);
    if (typeof NSWindowTitleHidden !== 'undefined') {
      panel.setTitleVisibility(NSWindowTitleHidden);
    }
  } catch (e) {
    note("Titelleisten-Stil nicht setzbar: ".concat(e));
  }
  try {
    var content = panel.contentView();
    var effect = NSVisualEffectView.alloc().initWithFrame(content.bounds());
    effect.setAutoresizingMask(18); // width | height
    if (typeof NSVisualEffectBlendingModeBehindWindow !== 'undefined') {
      effect.setBlendingMode(NSVisualEffectBlendingModeBehindWindow);
    }
    if (typeof NSVisualEffectStateActive !== 'undefined') {
      effect.setState(NSVisualEffectStateActive);
    }
    if (effect.setMaterial && typeof NSVisualEffectMaterialSidebar !== 'undefined') {
      effect.setMaterial(NSVisualEffectMaterialSidebar);
    }
    content.addSubview_positioned_relativeTo(effect, -1, null); // NSWindowBelow
  } catch (e) {
    note("NSVisualEffectView nicht verf\xFCgbar, bleibe bei windowBackgroundColor: ".concat(e));
  }
}

/**
 * Notausgang für ein bereits sichtbares Panel.
 *
 * Wirft der Inhaltsaufbau nach makeKeyAndOrderFront, aber bevor die Buttons und
 * der Delegate hängen, bleibt sonst ein Fenster ohne Schließweg stehen — real
 * passiert am 260909, wegzubekommen nur über einen eigens gebauten Command.
 * Direkt nach dem Sichtbarmachen aufrufen, vor jedem Inhalt.
 */
function addEscapeHatch(panel, log) {
  var ESC = String.fromCharCode(27);
  try {
    panel.setStyleMask(panel.styleMask() | NSWindowStyleMaskClosable);
    var btn = NSButton.alloc().initWithFrame(NSMakeRect(-100, -100, 1, 1));
    btn.setTitle('');
    btn.setKeyEquivalent(ESC);
    btn.setAction('callAction:');
    btn.setCOSJSTargetFunction(function () {
      try {
        panel.orderOut(null);
      } catch (e) {
        if (log) log("Notausgang orderOut: ".concat(e));
      }
      try {
        panel.close();
      } catch (e) {
        if (log) log("Notausgang close: ".concat(e));
      }
    });
    panel.contentView().addSubview(btn);
    return btn;
  } catch (e) {
    if (log) log("Notausgang nicht setzbar \u2014 Panel waere bei einem Fehler im Aufbau nicht schliessbar: ".concat(e));
    return null;
  }
}

/**
 * Bestätigender Button: Return-Kürzel, damit AppKit ihn in der Akzentfarbe
 * zeichnet. Ohne das wirkt jedes Panel wie ein Dialog von 2001 — im ganzen
 * Repo war vor 260909 kein einziger Default-Button gesetzt.
 */
function makeDefaultButton(frame, title, fn) {
  var b = NSButton.alloc().initWithFrame(frame);
  b.setTitle(title);
  b.setBezelStyle(NSBezelStyleRounded);
  b.setKeyEquivalent(String.fromCharCode(13)); // Return
  if (fn) b.setCOSJSTargetFunction(fn);
  return b;
}

/***/ }),

/***/ "./src/utils/swatchResolve.js":
/*!************************************!*\
  !*** ./src/utils/swatchResolve.js ***!
  \************************************/
/*! exports provided: rgbaToHex8, resolveNativeColor, resolveColorObject, displayName, pickSwatchCandidate, applySwatchToNativeColor, hex8ToRGBA */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rgbaToHex8", function() { return rgbaToHex8; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resolveNativeColor", function() { return resolveNativeColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resolveColorObject", function() { return resolveColorObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "displayName", function() { return displayName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pickSwatchCandidate", function() { return pickSwatchCandidate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applySwatchToNativeColor", function() { return applySwatchToNativeColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hex8ToRGBA", function() { return hex8ToRGBA; });
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js");
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! util */ "util");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_2__);


/**
 * ID-based swatch (color variable) resolution — SHARED across tools.
 *
 * WHY THIS EXISTS
 * A color that references a Sketch swatch (color variable) must be named via its
 * swatch REFERENCE, never by its RGBA value. Value→name is ambiguous (two swatches
 * can share a value) and is explicitly disallowed here. In real documents ~90% of
 * swatches come from an external Library; those appear locally as `foreignSwatches`
 * whose `localSwatch()` carries the real name + `sourceLibraryName()`.
 *
 * RESOLUTION PATH (all by identity, no color compare):
 *   MSColor.swatchID()  →  documentData.swatchWithID(id)  →  the swatch object
 *   swatch object identity matched against documentData.foreignSwatches()[].localSwatch()
 *   → if matched: imported, libraryName = foreignSwatch.sourceLibraryName()
 *   → else: local swatch
 *
 * Ported/centralized from smartSelect.js (swatchForMSColor / resolveOverrideColor).
 * Other tools (smartSelect, equalize, contrast, …) should consume THIS module
 * rather than re-implementing the lookup.
 *
 * Return shape for every entry point:
 *   { hex, rgba:{r,g,b,a}, swatchID, name, isImported, libraryName }
 *   — swatchID/name/libraryName are null when the color references no swatch.
 */


function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }


// --- native access helpers (CocoaScript props may be functions OR values) ----

// Read a CocoaScript property/method. Mocha's bound methods report typeof
// 'function' but do NOT support Function.prototype.call — invoke them directly
// as obj.name() (the proven smartSelect pattern).
function call(obj, name) {
  if (!obj) return null;
  try {
    var v = obj[name];
    return typeof v === 'function' ? obj[name]() : v;
  } catch (e) {
    return null;
  }
}
function getNativeDocumentData(nativeObj) {
  try {
    if (!nativeObj) return null;
    return call(nativeObj, 'documentData') || null;
  } catch (e) {
    return null;
  }
}
function nativeObjectIDString(nativeObj) {
  try {
    if (!nativeObj) return null;
    var v = call(nativeObj, 'objectID');
    return v == null ? null : String(v);
  } catch (e) {
    return null;
  }
}

// --- color math --------------------------------------------------------------

/** MSColor / MSImmutableColor → {r,g,b,a} in 0..1. */
function msColorToRGBA(c) {
  return {
    r: Number(call(c, 'red')) || 0,
    g: Number(call(c, 'green')) || 0,
    b: Number(call(c, 'blue')) || 0,
    a: call(c, 'alpha') == null ? 1 : Number(call(c, 'alpha'))
  };
}

/** {r,g,b,a} 0..1 → #RRGGBBAA (uppercase). */
function rgbaToHex8(rgba) {
  var h = function h(v) {
    var n = Math.max(0, Math.min(255, Math.round((v || 0) * 255)));
    return n.toString(16).toUpperCase().padStart(2, '0');
  };
  return '#' + h(rgba.r) + h(rgba.g) + h(rgba.b) + h(rgba.a == null ? 1 : rgba.a);
}

// --- swatch identity ---------------------------------------------------------

/**
 * Describe a native swatch object by IDENTITY against the document's foreign
 * (library) swatches. Returns { name, isImported, libraryName }.
 */
function describeSwatch(nativeSwatch, docData) {
  var name = String(call(nativeSwatch, 'name') || '');
  var targetId = nativeObjectIDString(nativeSwatch);
  try {
    var foreign = Object(util__WEBPACK_IMPORTED_MODULE_2__["toArray"])(call(docData, 'foreignSwatches')) || [];
    var fref = foreign.find(function (fs) {
      try {
        return nativeObjectIDString(call(fs, 'localSwatch')) === targetId;
      } catch (e) {
        return false;
      }
    });
    if (fref) {
      return {
        name: name,
        isImported: true,
        libraryName: String(call(fref, 'sourceLibraryName') || '')
      };
    }
  } catch (e) {}
  return {
    name: name,
    isImported: false,
    libraryName: null
  };
}

/**
 * Core lookup: swatchID (+ documentData) → { name, isImported, libraryName } | null.
 * `swatchWithID` resolves both local swatches and the local instances of library
 * (foreign) swatches; describeSwatch then classifies local vs. imported.
 */
function resolveSwatchByID(swatchID, docData) {
  if (!swatchID || !docData) return null;
  try {
    var nativeSwatch = typeof docData.swatchWithID === 'function' ? docData.swatchWithID(swatchID) : null;
    if (!nativeSwatch) return null;
    return describeSwatch(nativeSwatch, docData);
  } catch (e) {
    return null;
  }
}
var EMPTY_SWATCH = {
  swatchID: null,
  name: null,
  isImported: false,
  libraryName: null
};

// --- public entry points -----------------------------------------------------

/**
 * Resolve a native MSColor / MSImmutableColor.
 * @param nativeColor a Sketch native color (has red()/green()/blue()/alpha(), swatchID())
 * @param docDataOverride optional documentData if the color can't provide its own
 */
function resolveNativeColor(nativeColor, docDataOverride) {
  if (!nativeColor) return null;
  var rgba = msColorToRGBA(nativeColor);
  var base = _objectSpread({
    hex: rgbaToHex8(rgba),
    rgba: rgba
  }, EMPTY_SWATCH);
  var swatchID = null;
  try {
    swatchID = call(nativeColor, 'swatchID');
  } catch (e) {}
  if (!swatchID) return base;
  var docData = docDataOverride || getNativeDocumentData(nativeColor);
  var s = resolveSwatchByID(swatchID, docData);
  return s ? _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(swatchID)
  }, s) : _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(swatchID)
  });
}

/**
 * Resolve a plain override color object { _class:'color', red,green,blue,alpha, swatchID? }.
 * @param docData the document's documentData (required for swatch naming)
 */
function resolveColorObject(colorObj, docData) {
  if (!colorObj || _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default()(colorObj) !== 'object') return null;
  var rgba = {
    r: Number(colorObj.red) || 0,
    g: Number(colorObj.green) || 0,
    b: Number(colorObj.blue) || 0,
    a: colorObj.alpha == null ? 1 : Number(colorObj.alpha)
  };
  var base = _objectSpread({
    hex: rgbaToHex8(rgba),
    rgba: rgba
  }, EMPTY_SWATCH);
  if (!colorObj.swatchID) return base;
  var s = resolveSwatchByID(colorObj.swatchID, docData);
  return s ? _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(colorObj.swatchID)
  }, s) : _objectSpread(_objectSpread({}, base), {}, {
    swatchID: String(colorObj.swatchID)
  });
}

/** A short display label: swatch name if present, else the hex value. */
function displayName(resolved) {
  if (!resolved) return '';
  if (resolved.name) return resolved.name;
  return resolved.hex;
}

// --- name lookup: which candidate wins? --------------------------------------

/**
 * Pick one swatch among same-named candidates — PURE, no native objects.
 *
 * WHY THIS IS ITS OWN FUNCTION
 * Duplicate swatch names are the normal case, not an edge case: in the reference
 * document ALL six configured names exist in both libraries, `grau-04` locally
 * on top of that (measured 260909, see docs/review/swap-tools-review.md §7).
 * Picking `candidates[0]` therefore picked at random. Callers pass plain
 * descriptors so this rule stays unit-testable outside Sketch.
 *
 * @param candidates [{ name, isImported, libraryName, ref }] — `ref` is opaque
 * @param opts.requiredLibrary  null = the winner must be LOCAL; a name = it must
 *                              come from exactly that library (same-library rule)
 * @param opts.libraryPriority  ordered library names; earliest listed wins
 * @returns the winning candidate, or null when none qualifies
 */
function pickSwatchCandidate(candidates) {
  var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var list = Array.isArray(candidates) ? candidates.filter(Boolean) : [];
  if (!list.length) return null;
  var required = opts.requiredLibrary || null;
  var priority = Array.isArray(opts.libraryPriority) ? opts.libraryPriority : [];

  // Same-library rule: an imported colour is replaced from the SAME library,
  // a local one stays local. Mixed provenance within one selection is expected
  // (testcase 2), so this is decided per colour and never globally.
  var eligible = list.filter(function (c) {
    var lib = c && c.isImported ? c.libraryName || null : null;
    return required ? lib === required : !lib;
  });
  if (!eligible.length) return null;
  if (eligible.length === 1) return eligible[0];

  // Still ambiguous → the owner's ranking decides (260909).
  var _iterator = _createForOfIteratorHelper(priority),
    _step;
  try {
    var _loop = function _loop() {
        var wanted = _step.value;
        var hit = eligible.find(function (c) {
          return (c.libraryName || null) === wanted;
        });
        if (hit) return {
          v: hit
        };
      },
      _ret;
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      _ret = _loop();
      if (_ret) return _ret.v;
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return eligible[0];
}

/**
 * Link a native MSColor to a swatch — the WRITE counterpart to resolveNativeColor.
 *
 * Setting the swatchID keeps the colour a REFERENCE; writing raw RGBA would
 * detach it from its library and silently turn a colour variable into a literal.
 * The RGBA path is therefore a last resort, and it is reported by the return
 * value so callers can tell a real relink from a mere value copy.
 *
 * @param nativeColor MSColor (mutable — an MSImmutableColor cannot be written)
 * @param swatch      DOM swatch or native swatch object
 * @returns { ok, mode } — mode: 'swatchID' | 'rgba' | null
 */
function applySwatchToNativeColor(nativeColor, swatch) {
  if (!nativeColor || !swatch) return {
    ok: false,
    mode: null
  };
  var nativeSwatch = swatch.sketchObject || swatch;
  var swatchID = swatch.id || nativeObjectIDString(nativeSwatch);

  // setSwatchID allein setzt nur die VERKNUEPFUNG, nicht die Farbwerte: Die
  // Ebene zeigt danach auf den richtigen Swatch und sieht trotzdem aus wie
  // vorher (Owner-Befund 260910 — "die markierung steht auf der korrekten
  // nachtfarbe, aber die darstellung ist falsch, erst beim zweiten klick wird
  // sie uebernommen").
  //
  // Deshalb werden BEIDE gesetzt: erst die Werte des Ziel-Swatches, dann die
  // Verknuepfung. Reihenfolge ist wesentlich — ein Schreiben der Werte NACH
  // dem Setzen der ID kann die Bindung wieder loesen.
  if (swatchID && typeof nativeColor.setSwatchID === 'function') {
    try {
      var src = call(nativeSwatch, 'color');
      var rgba = src ? msColorToRGBA(src) : null;
      if (rgba && typeof nativeColor.setRed_green_blue_alpha === 'function') {
        nativeColor.setRed_green_blue_alpha(rgba.r, rgba.g, rgba.b, rgba.a);
      } else if (!rgba) {
        console.log("Farbwerte des Swatches \"".concat(call(nativeSwatch, 'name'), "\" nicht lesbar \u2014 setze nur die Verknuepfung"));
      }
      nativeColor.setSwatchID(swatchID);
      return {
        ok: true,
        mode: 'swatchID'
      };
    } catch (e) {
      console.log("Swatch-Verknuepfung nicht setzbar (ID ".concat(swatchID, "): ").concat(e));
    }
  }

  // Fallback: copy the value. The colour loses its swatch link — callers that
  // care must treat mode 'rgba' as "not properly relinked".
  var value = call(nativeSwatch, 'color') || (typeof swatch.color === 'string' ? swatch.color : null);
  if (value && typeof nativeColor.setRed_green_blue_alpha === 'function') {
    try {
      var _rgba = typeof value === 'string' ? hex8ToRGBA(value) : msColorToRGBA(value);
      if (_rgba) {
        nativeColor.setRed_green_blue_alpha(_rgba.r, _rgba.g, _rgba.b, _rgba.a);
        return {
          ok: true,
          mode: 'rgba'
        };
      }
      console.log("Farbwert des Swatches nicht lesbar: ".concat(String(value)));
    } catch (e) {
      console.log("Farbwert nicht auf die Farbe anwendbar: ".concat(e));
    }
  }
  console.log("Swatch liess sich weder verknuepfen noch als Wert setzen (swatchID=".concat(swatchID || '-', ")"));
  return {
    ok: false,
    mode: null
  };
}

/** '#RRGGBB' / '#RRGGBBAA' → {r,g,b,a} in 0..1, or null when unparseable. */
function hex8ToRGBA(hex) {
  var m = String(hex || '').match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i);
  if (!m) return null;
  return {
    r: parseInt(m[1], 16) / 255,
    g: parseInt(m[2], 16) / 255,
    b: parseInt(m[3], 16) / 255,
    a: m[4] ? parseInt(m[4], 16) / 255 : 1
  };
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=smartSelect.js.map